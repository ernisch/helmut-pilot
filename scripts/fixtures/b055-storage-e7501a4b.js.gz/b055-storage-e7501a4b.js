const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { v1Sources } = require("./sources");
const { isTerminalUnderstandingStatus } = require("./pending-terminal");
// Kanonische Klassifizierung real/synthetisch (Verdraengungsschutz der realen Mandate).
const mandatsklasse = require("./mandatsklasse");
// W-2 fuer llmUsage: Projektion Blob -> relationale Zeile (Default AUS).
const {
  llmUsageRelationalEnabled,
  llmUsageToRelationalRow,
  relationalRowToLlmUsage
} = require("./llm-usage-relational");
// K2 (eine Mandatswahrheit): die Lebenszyklus-Projektion relationaler Profilzeilen ist
// GEMEINSAM mit dem Nachweis-CLI (tenant-context ist pur, kein Require-Zyklus: es laedt
// storage nur lazy innerhalb von listActiveTenantIds).
const { relationalesProfilLebenszyklus } = require("./tenant-context");
// SR §37 (Vorfall 04.09.2026): die wirksame crawlRuns-Aufbewahrung und der
// Speicherziel-Bericht. Reine Logik, kein Require-Zyklus — das Modul laedt nur
// `production-schreibgate` und niemals storage.js.
const VORFLUG = require("./speicherpfad-vorflug");
const authStoreCas = require("./auth-store-cas");

const dataDir = path.join(__dirname, "..", "..", ".helmut-data");
const dataFile = path.join(dataDir, "store.json");
const supabaseStoreId = process.env.HELMUT_SUPABASE_STORE_ID || "main";

function defaultStore() {
  return {
    sources: v1Sources,
    profiles: {},
    rawItems: [],
    briefings: [],
    crawlRuns: [],
    tasks: [],
    interactions: [],
    topicMemory: [],
    mandateProfiles: {},
    politicalItems: [],
    personalizedRecommendations: [],
    dailyTasks: [],
    communicationDrafts: [],
    userNotes: [],
    priorityChanges: [],
    lageChecks: [],
    pushSubscriptions: [],
    pushEvents: [],
    pipelineDebugReports: [],
    // Auth-Schicht (MVP): bewusst im JSON-Store gekapselt, damit ein spaeterer
    // relationaler Umzug ein Drop-in-Swap bleibt. Identitaet/Rollen/Mandantentrennung
    // werden ausschliesslich serverseitig aus diesen Collections abgeleitet.
    users: [],
    sessions: [],
    assignments: [],
    dailyInputs: [],
    auditEvents: [],
    systemErrors: [],
    adminSettings: {}
  };
}

function useSupabase() {
  return (
    String(process.env.HELMUT_STORAGE_BACKEND || "").trim().toLowerCase() === "supabase" &&
    Boolean(process.env.SUPABASE_URL) &&
    Boolean(supabaseServiceRoleKey())
  );
}

function getStorageStatus() {
  const backend = useSupabase() ? "supabase" : "local";
  return {
    backend,
    supabaseConfigured: Boolean(process.env.SUPABASE_URL && supabaseServiceRoleKey()),
    storeId: supabaseStoreId
  };
}

async function getStoreSummary(politicianId) {
  const [store, pStore] = await Promise.all([
    readStore("main"),
    politicianId ? readStore(pKey(politicianId)) : Promise.resolve(defaultPoliticianStore())
  ]);
  const activeSources = (store.sources || []).filter((source) => source.active !== false);
  const rawItems = store.rawItems || [];
  const latestRawItem = sortByDate(rawItems, "retrievedAt", "publishedAt")[0] || null;
  // Briefings: zuerst im Politiker-Store suchen, dann Main-Store als Fallback
  const allBriefings = [...(pStore.briefings || []), ...(store.briefings || [])];
  const latestBriefing = allBriefings.find((briefing) => !politicianId || briefing.politicianId === politicianId) || null;
  const allTasks = [...(pStore.tasks || []), ...(store.tasks || [])];
  const allLageChecks = [...(pStore.lageChecks || []), ...(store.lageChecks || [])];
  const allPushEvents = [...(pStore.pushEvents || []), ...(store.pushEvents || [])];
  const recommendations = [...(pStore.personalizedRecommendations || []), ...(store.personalizedRecommendations || [])].filter((entry) => !politicianId || entry.user_id === politicianId);
  const tasks = allTasks.filter((task) => !politicianId || task.politicianId === politicianId);
  const notes = [...(pStore.userNotes || []), ...(store.userNotes || [])].filter((note) => !politicianId || note.user_id === politicianId);
  const latestPushEvent = allPushEvents.find((event) => !politicianId || event.politicianId === politicianId) || null;
  const since24h = Date.now() - 24 * 60 * 60 * 1000;

  return {
    backend: getStorageStatus().backend,
    storeId: supabaseStoreId,
    sources: {
      total: (store.sources || []).length,
      active: activeSources.length
    },
    rawItems: {
      total: rawItems.length,
      last24h: rawItems.filter((item) => new Date(item.retrievedAt || item.publishedAt || 0).getTime() >= since24h).length,
      directLinks: rawItems.filter((item) => articleUrlQuality(item.url) === "direct").length,
      missingLinks: rawItems.filter((item) => articleUrlQuality(item.url) !== "direct").length,
      latestAt: latestRawItem?.retrievedAt || latestRawItem?.publishedAt || null
    },
    briefings: {
      total: allBriefings.filter((briefing) => !politicianId || briefing.politicianId === politicianId).length,
      latestId: latestBriefing?.id || null,
      latestStatus: latestBriefing?.status || null,
      latestGeneratedAt: latestBriefing?.generatedAt || latestBriefing?.date || null
    },
    crawlRuns: {
      total: (store.crawlRuns || []).length,
      latestAt: store.crawlRuns?.[0]?.createdAt || null
    },
    lageChecks: {
      total: allLageChecks.filter((check) => !politicianId || check.politicianId === politicianId).length,
      latestAt: allLageChecks.find((check) => !politicianId || check.politicianId === politicianId)?.checkedAt || null,
      latestStatus: allLageChecks.find((check) => !politicianId || check.politicianId === politicianId)?.status || null
    },
    push: {
      subscriptions: [...(pStore.pushSubscriptions || []), ...(store.pushSubscriptions || [])].filter((subscription) => !politicianId || subscription.politicianId === politicianId).length,
      latestEventAt: latestPushEvent?.createdAt || null,
      latestReason: latestPushEvent?.reason || "",
      latestDelivered: latestPushEvent?.delivered || 0
    },
    recommendations: {
      total: recommendations.length,
      active: recommendations.filter((entry) => !["done", "ignored"].includes(entry.status)).length
    },
    tasks: {
      total: tasks.length,
      open: tasks.filter((task) => task.status !== "done").length
    },
    notes: {
      total: notes.length
    },
    debugReports: {
      total: [...(pStore.pipelineDebugReports || []), ...(store.pipelineDebugReports || [])].filter((report) => !politicianId || report.politicianId === politicianId).length,
      latestAt: [...(pStore.pipelineDebugReports || []), ...(store.pipelineDebugReports || [])].find((report) => !politicianId || report.politicianId === politicianId)?.createdAt || null
    }
  };
}

// Cache pro Store-Key. readStore/writeStore akzeptieren einen optionalen storeKey:
// - "main" (default): geteilte Daten (sources, rawItems, crawlRuns, profiles)
// - "p-{politicianId}": isolierter Politiker-Store (briefings, tasks, ...)
// Per HELMUT_STORE_CACHE_MS=0 deaktivierbar.
const storeCacheTtlMs = Number(process.env.HELMUT_STORE_CACHE_MS || 10000);
const storeCacheMap = new Map(); // storeKey → { data, at }
const storeVersions = new Map();
const storeWriteQueues = new Map();
const STORE_SNAPSHOT = Symbol("store-snapshot");

function storeSnapshot(store, storeKey, version, remote = null) {
  Object.defineProperty(store, STORE_SNAPSHOT, {
    value: Object.freeze({ storeKey, version, remote }), enumerable: true
  });
  return store;
}

function advanceStoreVersion(storeKey) {
  const version = (storeVersions.get(storeKey) || 0) + 1;
  storeVersions.set(storeKey, version);
  return version;
}

async function readStore(storeKey = "main", { fresh = false } = {}) {
  const version = storeVersions.get(storeKey) || 0;
  const cached = storeCacheMap.get(storeKey);
  if (!fresh && storeCacheTtlMs > 0 && cached && Date.now() - cached.at < storeCacheTtlMs) {
    return storeSnapshot(structuredClone(cached.data), storeKey, version, cached.remote);
  }
  const { data: store, remote = null } = useSupabase()
    ? await readSupabaseStore(storeKey) : { data: readLocalStore(storeKey) };
  // Aufrufer veraendern ihren Lesestand vor dem Schreiben. Der Cache darf weder
  // diese Zwischenstaende noch eine fehlgeschlagene Aenderung veroeffentlichen.
  // Ein alter GET kann NACH einem Write fertig werden: er ersetzt keinen neueren
  // Cachestand und behaelt fuer einen spaeteren Write seine alte Lesemarke.
  if (version === (storeVersions.get(storeKey) || 0)) {
    storeCacheMap.set(storeKey, { data: structuredClone(store), at: Date.now(), remote });
  }
  return storeSnapshot(store, storeKey, version, remote);
}

async function writeStore(store, storeKey = "main") {
  const snapshot = store[STORE_SNAPSHOT];
  // Auch waehrend des HTTP Writes darf der Aufrufer den spaeter bestaetigten
  // Cachestand nicht mehr veraendern. Die Lesemarke bleibt separat erhalten.
  const submitted = structuredClone(store);
  const run = async () => {
    // Die Cachekopie darf nicht zwei gleichzeitige Writes derselben Instanz
    // legitimieren. Gegen andere Instanzen prueft writeSupabaseStore zusaetzlich
    // die unveraenderliche Revision genau dieses Lesestands in der Datenbank.
    if (snapshot && (snapshot.storeKey !== storeKey || snapshot.version !== (storeVersions.get(storeKey) || 0))) {
      const error = new Error("Datenspeicher wurde zwischenzeitlich geaendert. Bitte neu laden.");
      error.code = "STORE_WRITE_CONFLICT";
      error.statusCode = 409;
      throw error;
    }
    try {
      const isMain = storeKey === "main";
      const normalized = isMain ? compactStore(normalizeStore(submitted)) : compactPoliticianStore(normalizePoliticianStore(submitted));
      let remote = null;
      if (useSupabase()) remote = await writeSupabaseStore(normalized, storeKey, snapshot?.remote);
      else writeLocalStore(normalized, storeKey);
      const version = advanceStoreVersion(storeKey);
      storeCacheMap.set(storeKey, { data: structuredClone(normalized), at: Date.now(), remote });
      // normalizeStore kopiert Symbole, normalizePoliticianStore nicht. Beide
      // Rueckgaben erhalten eine neue Marke erst nach bestaetigtem Schreiben.
      delete normalized[STORE_SNAPSHOT];
      return storeSnapshot(normalized, storeKey, version, remote);
    } catch (error) {
      // Bei verlorener Antwort kann der Write gespeichert sein. Auch gleichzeitig
      // geladene Staende werden ungueltig, nicht nur der sichtbare Cacheeintrag.
      advanceStoreVersion(storeKey);
      storeCacheMap.delete(storeKey);
      throw error;
    }
  };
  const result = (storeWriteQueues.get(storeKey) || Promise.resolve()).then(run, run);
  const settled = result.catch(() => {});
  storeWriteQueues.set(storeKey, settled);
  settled.then(() => { if (storeWriteQueues.get(storeKey) === settled) storeWriteQueues.delete(storeKey); });
  return result;
}

function readLocalStore(storeKey = "main") {
  const file = storeKey === "main" ? dataFile : path.join(dataDir, `${storeKey}.json`);
  if (!fs.existsSync(file)) return storeKey === "main" ? defaultStore() : defaultPoliticianStore();
  try {
    const raw = JSON.parse(fs.readFileSync(file, "utf8"));
    return storeKey === "main" ? normalizeStore(raw) : normalizePoliticianStore(raw);
  } catch (error) {
    console.error("Helmut storage read failed", storeKey, error);
    return storeKey === "main" ? defaultStore() : defaultPoliticianStore();
  }
}

function writeLocalStore(store, storeKey = "main") {
  fs.mkdirSync(dataDir, { recursive: true });
  const file = storeKey === "main" ? dataFile : path.join(dataDir, `${storeKey}.json`);
  fs.writeFileSync(file, JSON.stringify(store, null, 2));
}

// --- Fairnesszustand der Mehrmandanten-Crons (OP-25) -------------------------
// EIGENE Zeile im bereits existierenden helmut_store: `<storeId>-cron-fairness`.
// KEINE neue Tabelle, KEINE Migration, KEINE RLS-Aenderung noetig — die Policy auf
// helmut_store matcht ausschliesslich das Praefix `main-p-`; jede andere Zeile ist
// fuer nicht-service_role-Rollen implizit gesperrt (20260712_tenant_rls_policies).
//
// WARUM EINE EIGENE ZEILE: der Auth-/Main-Blob wird von vielen Schreibern ersetzt
// (Befund W-2: Last-Write-Wins verliert parallele Eintraege OHNE Fehler). Eine
// dedizierte Zeile hat genau EINEN Schreiber (diesen hier) und traegt ~4 KB statt
// 1,24 MB — der Fairnesszustand kostet den Cron damit fast keine Zeit.
//
// BEWUSST OHNE readStore/writeStore: deren normalizeStore/compactStore-Schema
// (main bzw. p-<mandant>) wuerde die Scheduler-Felder verwerfen; und der
// 10-s-Cache von readStore darf hier NICHT greifen (der Zustand muss vor jedem
// Schreiben frisch gelesen werden, damit die Verschmelzung monoton bleibt).
//
// DSGVO: ausschliesslich pseudonyme Mandatskennung, Zeitstempel, Zaehler,
// Statuswort. Keine Inhalte, keine Roh-Fehlertexte, keine PII.
//
// SCHREIBWEISE (Befund F-CAS, 2026-08-02): der Zeileninhalt wird NUR NOCH
// BEDINGT ersetzt (Compare-and-Set ueber `data.rev`). Grund ist ein in
// Production belegter verlorener Schreibvorgang: Lesen -> Verschmelzen ->
// Schreiben ist fuer sich NICHT atomar. Zwei ueberlappende Crons (ein nach
// seinem aeusseren Zeitlimit intern weiterlaufender `crawl` und der regulaere
// `morning-briefing`) haben dieselbe Zeile bearbeitet; der zweite Schreiber
// stuetzte sich auf einen Lesestand von VOR dem Abschluss des ersten und hat
// diesen Abschluss beim Zurueckschreiben geloescht — ohne Fehler, ohne Signal.
// Die monotone Verschmelzung in cron-fairness.mergeState schuetzt davor NICHT:
// sie ist monoton gegenueber dem gelesenen Stand, nicht gegenueber einem
// Schreibvorgang, den dieser Prozess nie gesehen hat.
const CRON_FAIRNESS_STORE_SUFFIX = "cron-fairness";

function cronFairnessRowId() {
  return `${supabaseStoreId}-${CRON_FAIRNESS_STORE_SUFFIX}`;
}

// Fortschreibungszaehler der ZEILE (nicht des Fairnessinhalts). Er ist die
// Bedingung des Compare-and-Set und waechst mit jedem erfolgreichen Schreiben
// um genau 1. `null` = kein oder kein deutbarer Wert (Altbestand oder ein
// Codestand ohne CAS) — dann wird gegen "Feld fehlt" verglichen.
function revOf(raw) {
  const n = raw && typeof raw === "object" ? Number(raw.rev) : NaN;
  return Number.isFinite(n) && n >= 0 ? Math.floor(n) : null;
}

function cronFairnessLocalFile() {
  return path.join(dataDir, `${CRON_FAIRNESS_STORE_SUFFIX}.json`);
}

// Wirft NIE: ein nicht lesbarer Zustand ist ein Fairness-, kein Ausfallproblem.
// Der Aufrufer erkennt den Unterschied an `{ ok:false }` und meldet ihn sichtbar.
// `deps.request` ist injizierbar (Tests) — genau wie bei acquirePipelineLockAtomic.
async function readCronFairnessState(deps = {}) {
  const { normalizeState, stateVersion } = require("./cron-fairness");
  const request = deps.request || supabaseRequest;
  try {
    if (useSupabase()) {
      const rows = await request(
        `/rest/v1/helmut_store?id=eq.${encodeURIComponent(cronFairnessRowId())}&select=data`
      );
      const row = Array.isArray(rows) ? rows[0] : null;
      const roh = (row && row.data) || {};
      return { ok: true, state: normalizeState(roh), existiert: Boolean(row), version: stateVersion(roh), rev: revOf(roh) };
    }
    const file = cronFairnessLocalFile();
    if (!fs.existsSync(file)) return { ok: true, state: normalizeState({}), existiert: false, version: null, rev: null };
    const roh = JSON.parse(fs.readFileSync(file, "utf8"));
    return { ok: true, state: normalizeState(roh), existiert: true, version: stateVersion(roh), rev: revOf(roh) };
  } catch (error) {
    return { ok: false, state: normalizeState({}), existiert: null, fehler: String((error && error.message) || "unbekannt").slice(0, 200) };
  }
}

// Der BEDINGTE Schreibvorgang. Er ersetzt den Zeileninhalt nur dann, wenn die
// Zeile seit dem Lesen unveraendert ist — sonst meldet er einen Konflikt und
// der Aufrufer liest neu und verschmilzt seinen Patch erneut. Damit kann ein
// Schreibvorgang, den dieser Prozess nie gesehen hat, nicht mehr verloren gehen.
//
// Postgres serialisiert konkurrierende UPDATEs derselben Zeile ueber den
// Row-Lock; die WHERE-Bedingung wird danach gegen den NEUEN Stand geprueft.
// Trifft sie nicht mehr zu, aendert das UPDATE 0 Zeilen — genau das ist das
// Konfliktsignal. Kein Lock, keine Transaktion, keine Migration, kein RPC.
async function schreibeCronFairnessZeile(request, daten, { existiert, rev }) {
  const id = cronFairnessRowId();
  if (!existiert) {
    // Einfuegen OHNE `merge-duplicates`: legt ein anderer Lauf die Zeile in
    // derselben Sekunde an, muss das ein sichtbarer Konflikt (409) sein und
    // kein stilles Ueberschreiben seines Standes.
    try {
      await request("/rest/v1/helmut_store", {
        method: "POST",
        headers: { Prefer: "return=minimal" },
        body: JSON.stringify({ id, data: daten })
      });
      return true;
    } catch (error) {
      if (/\b409\b|duplicate key/i.test(String((error && error.message) || ""))) return false;
      throw error;
    }
  }
  // `data->>rev` als Bedingung; `->>`-Pfeile prozentkodiert, damit sie keine
  // Frageneigenheit eines Zwischenstuecks treffen. Ohne Zaehler in der Zeile
  // (Altbestand) wird gegen "Feld fehlt" verglichen.
  const bedingung = rev === null ? "data-%3E%3Erev=is.null" : `data-%3E%3Erev=eq.${rev}`;
  const zeilen = await request(
    `/rest/v1/helmut_store?id=eq.${encodeURIComponent(id)}&${bedingung}&select=id`,
    {
      method: "PATCH",
      // Ohne Rueckgabe waere ein Treffer nicht von einem Nicht-Treffer zu
      // unterscheiden — die Rueckgabe IST das Ergebnis des Vergleichs.
      headers: { Prefer: "return=representation" },
      body: JSON.stringify({ data: daten })
    }
  );
  return Array.isArray(zeilen) && zeilen.length > 0;
}

// Lokaler Dateimodus (Entwicklung/Tests, kein Production-Pfad): dieselbe
// Bedingung, synchron geprueft. Node ist je Prozess einfaedig — zwischen
// Pruefung und Schreiben liegt hier kein await.
function schreibeCronFairnessDatei(daten, { rev }) {
  const file = cronFairnessLocalFile();
  const jetzt = fs.existsSync(file) ? revOf(JSON.parse(fs.readFileSync(file, "utf8"))) : null;
  if (jetzt !== rev) return false;
  fs.mkdirSync(dataDir, { recursive: true });
  fs.writeFileSync(file, JSON.stringify(daten, null, 2));
  return true;
}

// Verschmilzt einen Patch monoton in den FRISCH gelesenen Zustand und schreibt ihn
// zurueck. Wirft NIE.
//
// DREI SCHRANKEN gegen Datenverlust:
//  (1) Lesefehler -> KEIN Schreiben. Der Patch traegt nur EIN Mandat; ein leerer
//      Lesestand wuerde die Eintraege ALLER anderen Mandate ueberschreiben. Ein
//      verlorener Versuchsvermerk ist harmlos, ein geloeschter Zustand nicht.
//  (2) NEUERE Schemaversion in der Zeile -> KEIN Schreiben. Waehrend eines Rollouts
//      koennen zwei Codestaende laufen; der aeltere darf den neueren nicht plattmachen.
//  (3) `pruefen: true` (nur beim Registrieren eines Versuchs) -> nach dem Schreiben
//      wird zurueckgelesen. Fehlt der eigene Eintrag, hat ein ueberlappender Lauf ihn
//      ueberschrieben: begrenzte Wiederholung statt stillem Verlust. Beim ABSCHLUSS
//      entfaellt die Gegenpruefung bewusst — sie ist seit (4) nicht mehr noetig.
//  (4) COMPARE-AND-SET (Befund F-CAS): der Zeileninhalt wird nur ersetzt, wenn die
//      Zeile seit dem Lesen unveraendert ist. Andernfalls Konflikt -> neu lesen,
//      Patch erneut verschmelzen, erneut versuchen. Das ist die eigentliche
//      Absicherung: (1)-(3) schuetzen gegen das Schreiben auf einen NICHT gelesenen
//      Stand, (4) gegen das Schreiben auf einen INZWISCHEN VERALTETEN Stand.
//      Erst damit gilt: ein erfolgreicher Schreibvorgang bedeutet, dass die Zeile
//      GENAU den zurueckgegebenen `state` traegt.
async function saveCronFairnessState(patch, { nowMs = Date.now(), pruefen = false, maxVersuche = 3, deps = {} } = {}) {
  const { mergeState, FAIRNESS_VERSION, entryOf } = require("./cron-fairness");
  const request = deps.request || supabaseRequest;
  // Welche (cron, mandat)-Paare traegt der Patch? Nur die werden gegengelesen.
  const erwartet = [];
  for (const [cronName, mandate] of Object.entries((patch && patch.crons) || {})) {
    for (const tenantId of Object.keys(mandate || {})) erwartet.push([cronName, tenantId]);
  }
  let letzterFehler = null;
  for (let versuch = 1; versuch <= Math.max(1, maxVersuche); versuch += 1) {
    try {
      const aktuell = await readCronFairnessState(deps);
      if (!aktuell.ok) return { ok: false, fehler: aktuell.fehler || "zustand-nicht-lesbar", gelesen: false };
      if (Number.isFinite(aktuell.version) && aktuell.version > FAIRNESS_VERSION) {
        return { ok: false, fehler: `zustand-neuere-version-${aktuell.version}`, gelesen: true };
      }
      const merged = mergeState(aktuell.state, patch, { nowMs });
      // Der Zaehler gehoert zur ZEILE, nicht zum Fairnessinhalt: er wird beim
      // Schreiben angehaengt und beim Lesen wieder abgetrennt (normalizeState
      // fuehrt ihn nicht). Damit aendert er weder Reihenfolge noch Vertrag.
      const geschrieben = { ...merged, rev: (aktuell.rev === null ? 0 : aktuell.rev) + 1 };
      const gesetzt = useSupabase()
        ? await schreibeCronFairnessZeile(request, geschrieben, aktuell)
        : schreibeCronFairnessDatei(geschrieben, aktuell);
      if (!gesetzt) {
        // Die Zeile hat sich zwischen Lesen und Schreiben geaendert. NICHTS ist
        // verloren: der naechste Versuch liest den neuen Stand und verschmilzt
        // denselben Patch erneut darauf.
        letzterFehler = "gleichzeitiger-schreibvorgang";
        continue;
      }
      if (!pruefen || !erwartet.length) return { ok: true, state: merged, gelesen: true, versuche: versuch };
      const nachher = await readCronFairnessState(deps);
      if (!nachher.ok) return { ok: true, state: merged, gelesen: true, versuche: versuch, ungeprueft: true };
      const fehlt = erwartet.filter(([c, t]) => {
        const soll = entryOf(merged, c, t);
        const ist = entryOf(nachher.state, c, t);
        return !ist || (soll && soll.letzterVersuchAt && ist.letzterVersuchAt !== soll.letzterVersuchAt
          && Date.parse(ist.letzterVersuchAt || 0) < Date.parse(soll.letzterVersuchAt));
      });
      // Der eigene Eintrag steht (oder ein NEUERER fremder Versuch hat gewonnen — dann
      // ist nichts verloren, der andere Lauf hat das Mandat). Fernstand zurueckgeben,
      // damit der Aufrufer einen fremden Halter erkennen kann.
      if (!fehlt.length) return { ok: true, state: nachher.state, gelesen: true, versuche: versuch };
      letzterFehler = `eigener-eintrag-ueberschrieben (${fehlt.map(([c, t]) => `${c}/${t}`).join(",")})`;
    } catch (error) {
      letzterFehler = String((error && error.message) || "unbekannt").slice(0, 200);
      // Transiente Fehler duerfen wiederholt werden; permanente (4xx) nicht.
      if (/\b4\d\d\b/.test(letzterFehler)) break;
    }
  }
  return { ok: false, fehler: letzterFehler || "unbekannt", konflikt: /ueberschrieben|gleichzeitiger-schreibvorgang/.test(String(letzterFehler)) };
}

// DSGVO-Loeschung/Teardown: Scheduler-Spuren eines Mandats entfernen. Wirft NIE.
async function deleteCronFairnessTenant(politicianId, { maxVersuche = 3, deps = {} } = {}) {
  const { withoutTenant } = require("./cron-fairness");
  const request = deps.request || supabaseRequest;
  if (!politicianId) return { ok: true, entfernt: false };
  let letzterFehler = null;
  // Auch die Loeschung ist ein Lesen-Aendern-Schreiben und laeuft deshalb ueber
  // dasselbe Compare-and-Set: sonst koennte sie den Fortschritt eines gerade
  // laufenden Crons loeschen — oder ein Cron die Loeschung wieder einspielen.
  for (let versuch = 1; versuch <= Math.max(1, maxVersuche); versuch += 1) {
    try {
      const aktuell = await readCronFairnessState(deps);
      if (!aktuell.ok) return { ok: false, fehler: aktuell.fehler || "zustand-nicht-lesbar" };
      const vorher = JSON.stringify(aktuell.state);
      const bereinigt = withoutTenant(aktuell.state, politicianId);
      if (JSON.stringify(bereinigt) === vorher) return { ok: true, entfernt: false };
      const geschrieben = { ...bereinigt, rev: (aktuell.rev === null ? 0 : aktuell.rev) + 1 };
      const gesetzt = useSupabase()
        ? await schreibeCronFairnessZeile(request, geschrieben, aktuell)
        : schreibeCronFairnessDatei(geschrieben, aktuell);
      if (gesetzt) return { ok: true, entfernt: true };
      letzterFehler = "gleichzeitiger-schreibvorgang";
    } catch (error) {
      letzterFehler = String((error && error.message) || "unbekannt").slice(0, 200);
      if (/\b4\d\d\b/.test(letzterFehler)) break;
    }
  }
  return { ok: false, fehler: letzterFehler || "unbekannt" };
}

// P0-5 Stufe 1 — Blob-Timeout-Robustheit ---------------------------------------
// Der 1,24-MB-Monolith-Blob (Audit R1) laeuft wiederkehrend in 10-s-Timeouts; ein
// Timeout WAEHREND saveCrawlRun/saveRawItems verlor bisher OHNE Retry den ganzen
// Lauf. Jetzt: begrenzter Retry mit exponentiellem Backoff NUR bei transienten
// Fehlern (Timeout/5xx/Verbindung) — 4xx (permanent) werden sofort durchgereicht,
// nie Endlosschleife. Ein unbedingter Blob-Upsert ist bei konkurrierenden
// Schreibern NICHT sicher wiederholbar: ein neuerer Zwischenstand ginge verloren.
// Solche Writes setzen allowReplay:false. Ein technischer systemError bleibt
// erhalten; anschliessend sieht der Aufrufer den urspruenglichen Fehler.
const BLOB_RETRY_MAX = Math.max(0, Number(process.env.HELMUT_BLOB_RETRY_MAX) || 2);
const BLOB_RETRY_BASE_MS = Math.max(1, Number(process.env.HELMUT_BLOB_RETRY_BASE_MS) || 250);

function isRetryableStoreError(error) {
  const m = String((error && error.message) || "").toLowerCase();
  if (!m) return false;
  if (/\b4\d\d\b/.test(m)) return false;           // 4xx = permanent, NICHT retryen
  return m.includes("timed out") || m.includes("timeout") || m.includes("aborterror") ||
    /\b5\d\d\b/.test(m) || m.includes("econnreset") || m.includes("econnrefused") ||
    m.includes("socket") || m.includes("network") || m.includes("fetch failed");
}

// Re-entrancy-Guard: recordPipelineError liest/schreibt selbst den Auth-Store
// (ueber withStoreRetry). Ohne Guard fuehrte ein anhaltender Auth-Store-Ausfall zu
// unendlicher Rekursion (retry -> record -> read -> retry -> record …). Waehrend
// der Fehleraufzeichnung wird deshalb NICHT erneut aufgezeichnet.
let _recordingPipelineError = false;

async function withStoreRetry(fn, ctx = {}) {
  let lastError;
  const maxRetries = ctx.allowReplay === false ? 0 : BLOB_RETRY_MAX;
  for (let attempt = 0; attempt <= maxRetries; attempt += 1) {
    try {
      return await fn(attempt);
    } catch (error) {
      lastError = error;
      const retryable = isRetryableStoreError(error);
      if (!retryable || attempt >= maxRetries) break;
      const delay = BLOB_RETRY_BASE_MS * Math.pow(2, attempt); // 250, 500, 1000 …
      console.warn(`[blob-retry] ${ctx.label || "store"} Versuch ${attempt + 1}/${maxRetries + 1} fehlgeschlagen (${error && error.message}) — Backoff ${delay}ms`);
      await new Promise((r) => setTimeout(r, delay));
    }
  }
  // Bestaetigte Konkurrenz ist kein Transportausfall. Weder blind wiederholen
  // noch weitere Auth Writes zur Fehleraufzeichnung ausloesen.
  if (lastError?.code === "STORE_WRITE_CONFLICT") throw lastError;
  // Endgueltig fehlgeschlagen -> technischer systemError (kein stiller Lauf-Verlust).
  if (!_recordingPipelineError) {
    try {
      await recordPipelineError({
        process: ctx.label || "blob-io",
        errorType: lastError,
        retry: maxRetries,
        sourceId: ctx.storeKey || null
      });
    } catch (_) { /* Fehler-Logging darf den urspruenglichen Fehler nie verdecken */ }
  }
  throw lastError;
}

async function readSupabaseStore(storeKey = "main") {
  const rowId = storeKey === "main" ? supabaseStoreId : `${supabaseStoreId}-${storeKey}`;
  const rows = await withStoreRetry(
    () => supabaseRequest(`/rest/v1/helmut_store?id=eq.${encodeURIComponent(rowId)}&select=data`),
    { label: "blob-read", storeKey }
  );
  if (!Array.isArray(rows) || rows.length > 1 || (rows.length === 1 &&
      (!rows[0]?.data || typeof rows[0].data !== "object" || Array.isArray(rows[0].data)))) {
    const error = new Error(`Ungueltige Antwort des Datenspeichers (${storeKey})`);
    error.code = "STORE_READ_INVALID";
    throw error;
  }
  const raw = rows[0]?.data;
  const revision = raw?._storeRevision ?? null;
  if (revision !== null && (typeof revision !== "string" || !/^[a-f0-9-]{36}$/i.test(revision))) {
    const error = new Error(`Ungueltige Version des Datenspeichers (${storeKey})`);
    error.code = "STORE_READ_INVALID";
    throw error;
  }
  const remote = Object.freeze({ exists: rows.length === 1, revision, target: storeTarget(rowId) });
  const data = raw ? { ...raw } : (storeKey === "main" ? defaultStore() : defaultPoliticianStore());
  delete data._storeRevision;
  // Ein gueltiger Leerzustand wird nur zurueckgegeben. Ein Upsert beim Lesen
  // koennte eine seit dem GET parallel angelegte Zeile vollstaendig ersetzen.
  return { data: storeKey === "main" ? normalizeStore(data) : normalizePoliticianStore(data), remote };
}

function storeTarget(rowId) {
  return `${String(process.env.SUPABASE_URL || "").replace(/\/+$/, "")}|${rowId}`;
}

function storeWriteConflict() {
  const error = new Error("Datenspeicher wurde parallel geaendert. Bitte neu laden.");
  error.code = "STORE_WRITE_CONFLICT";
  error.statusCode = 409;
  return error;
}

async function writeSupabaseStore(store, storeKey = "main", snapshot) {
  const rowId = storeKey === "main" ? supabaseStoreId : `${supabaseStoreId}-${storeKey}`;
  if (!snapshot || snapshot.target !== storeTarget(rowId)) {
    const error = new Error("Datenspeicher hat keinen gueltigen Lesestand. Bitte neu laden.");
    error.code = "STORE_WRITE_SNAPSHOT_MISSING";
    error.statusCode = 409;
    throw error;
  }
  const revision = crypto.randomUUID();
  const data = { ...store, _storeRevision: revision };
  await withStoreRetry(async () => {
    let rows;
    if (!snapshot.exists) {
      try {
        // Erstanlage ist INSERT, niemals Upsert. Eine parallel entstandene
        // Zeile muss erhalten bleiben, auch wenn der Lesestand leer war.
        rows = await supabaseRequest("/rest/v1/helmut_store?select=id", {
          method: "POST", headers: { Prefer: "return=representation" },
          body: JSON.stringify({ id: rowId, data })
        });
      } catch (error) {
        if (/\b409\b/.test(String(error?.message))) throw storeWriteConflict();
        throw error;
      }
    } else {
      // Altbestand ohne Revision darf genau einmal bedingt uebernommen werden.
      // Die neue UUID verhindert auch ABA Konflikte zwischen neuen Schreibern.
      const condition = snapshot.revision === null ? "is.null" : `eq.${encodeURIComponent(snapshot.revision)}`;
      rows = await supabaseRequest(`/rest/v1/helmut_store?id=eq.${encodeURIComponent(rowId)}&data-%3E%3E_storeRevision=${condition}&select=id`, {
        method: "PATCH", headers: { Prefer: "return=representation" },
        body: JSON.stringify({ data })
      });
      if (Array.isArray(rows) && rows.length === 0) throw storeWriteConflict();
    }
    if (!Array.isArray(rows) || rows.length !== 1 || rows[0]?.id !== rowId) {
      throw new Error("Schreiben des Datenspeichers wurde nicht eindeutig bestaetigt");
    }
  },
    { label: "blob-write", storeKey, allowReplay: false }
  );
  return Object.freeze({ exists: true, revision, target: storeTarget(rowId) });
}

// --- Politician-Store Infrastruktur ---
// Jeder Abgeordnete bekommt seinen eigenen Supabase-Row ("main-p-{id}").
// Geteilte Daten (sources, rawItems, crawlRuns, profiles) bleiben im "main"-Store.

function pKey(politicianId) {
  return politicianId ? `p-${politicianId}` : "main";
}

function defaultPoliticianStore() {
  return {
    briefings: [],
    tasks: [],
    interactions: [],
    topicMemory: [],
    politicalItems: [],
    personalizedRecommendations: [],
    dailyTasks: [],
    communicationDrafts: [],
    userNotes: [],
    priorityChanges: [],
    lageChecks: [],
    pushSubscriptions: [],
    pushEvents: [],
    pipelineDebugReports: []
  };
}

function normalizePoliticianStore(store = {}) {
  const parsed = { ...defaultPoliticianStore(), ...store };
  return {
    briefings: Array.isArray(parsed.briefings) ? parsed.briefings : [],
    tasks: Array.isArray(parsed.tasks) ? parsed.tasks : [],
    interactions: Array.isArray(parsed.interactions) ? parsed.interactions : [],
    topicMemory: Array.isArray(parsed.topicMemory) ? parsed.topicMemory : [],
    politicalItems: Array.isArray(parsed.politicalItems) ? parsed.politicalItems : [],
    personalizedRecommendations: Array.isArray(parsed.personalizedRecommendations) ? parsed.personalizedRecommendations : [],
    dailyTasks: Array.isArray(parsed.dailyTasks) ? parsed.dailyTasks : [],
    communicationDrafts: Array.isArray(parsed.communicationDrafts) ? parsed.communicationDrafts : [],
    userNotes: Array.isArray(parsed.userNotes) ? parsed.userNotes : [],
    priorityChanges: Array.isArray(parsed.priorityChanges) ? parsed.priorityChanges : [],
    lageChecks: Array.isArray(parsed.lageChecks) ? parsed.lageChecks : [],
    pushSubscriptions: Array.isArray(parsed.pushSubscriptions) ? parsed.pushSubscriptions : [],
    pushEvents: Array.isArray(parsed.pushEvents) ? parsed.pushEvents : [],
    pipelineDebugReports: Array.isArray(parsed.pipelineDebugReports) ? parsed.pipelineDebugReports : []
  };
}

function compactPoliticianStore(store) {
  return {
    ...store,
    briefings: keepLatestPerOwner(store.briefings, "generatedAt", "date", 4, 320).map(compactStoredBriefing),
    interactions: keepLatestPerOwner(store.interactions, "createdAt", "createdAt", 80, 4000),
    topicMemory: keepLatestPerOwner(store.topicMemory, "updatedAt", "lastSeenAt", 120, 4000),
    politicalItems: keepLatestPerOwner(store.politicalItems, "created_at", "updated_at", 80, 4000),
    personalizedRecommendations: keepLatestPerOwner(store.personalizedRecommendations, "created_at", "updated_at", 80, 4000),
    dailyTasks: keepLatestPerOwner(store.dailyTasks, "createdAt", "dueDate", 60, 3000),
    communicationDrafts: keepLatestPerOwner(store.communicationDrafts, "createdAt", "createdAt", 40, 2000),
    userNotes: keepLatestPerOwner(store.userNotes, "createdAt", "createdAt", 80, 3000),
    priorityChanges: keepLatestPerOwner(store.priorityChanges, "created_at", "updated_at", 80, 3000),
    lageChecks: keepLatestPerOwner(store.lageChecks, "checkedAt", "createdAt", 10, 1000),
    pushSubscriptions: sortByDate(store.pushSubscriptions, "updatedAt", "createdAt").slice(0, 300),
    pushEvents: sortByDate(store.pushEvents, "createdAt").slice(0, 200),
    pipelineDebugReports: keepLatestPerOwner(store.pipelineDebugReports, "createdAt", "createdAt", 2, 200)
  };
}

// --- Separater, KLEINER Auth-Store ---
// Performance-kritisch: Accounts/Sessions liegen in einem EIGENEN Dokument (eigene
// Store-Row bzw. eigene lokale Datei), getrennt vom grossen Content-Blob. Sonst
// muesste jeder Login den mehrere MB grossen Haupt-Store komplett lesen + schreiben
// (auf Serverless laeuft das ins Funktions-Zeitlimit). So bleibt Login schnell.
const authStoreId = process.env.HELMUT_SUPABASE_AUTH_STORE_ID || `${supabaseStoreId}-auth`;
const authDataFile = path.join(dataDir, "auth.json");

function defaultAuthStore() {
  return {
    users: [],
    sessions: [],
    assignments: [],
    dailyInputs: [],
    auditEvents: [],
    systemErrors: [],
    // LLM-Nutzung (Kosten/Token je Call). Bewusst im KLEINEN Auth-Store, damit
    // nicht bei jedem Log-Eintrag der mehrere MB grosse Haupt-Blob geschrieben wird.
    llmUsage: [],
    // Pipeline-Locks: verhindert parallele Crawl-/Briefing-Laeufe (key = jobName, value = { lockedAt, expiresAt }).
    pipelineLocks: {},
    adminSettings: {},
    // Letzter manueller Admin-Recovery-Understanding-Lauf (Metadaten fuer die Anzeige,
    // ueberlebt Reload/Function-Kill). Nur Zahlen/Status/kurzer Grund — keine Rohtexte.
    adminRecoveryLastRun: null,
    // P0-1: Prozess-Laufzeit-Telemetrie (Understanding-Batch, Briefing-Aufbau,
    // Lage-Fold). Bewusst im KLEINEN Auth-Store (Muster adminRecoveryLastRun),
    // NICHT im grossen Content-Blob — sonst waechst der 1,24-MB-Monolith weiter
    // (Audit R1, Timeout-Quelle). Ausschliesslich technische Skalare/Zaehler —
    // keine Dokumentinhalte, keine Namen, keine Kontaktdaten (DSGVO-Datensparsamkeit).
    processRuns: [],
    // P1-4: Retry-Zähler fehlgeschlagener Wissensobjekte (vorgangId -> Anzahl),
    // damit der Auto-Retry BEGRENZT ist (kein Endlos-Retry, keine Schema-Migration).
    understandingRetries: {}
  };
}

async function readAuthStore() {
  if (useSupabase()) {
    const rows = await supabaseRequest(`/rest/v1/helmut_store?id=eq.${encodeURIComponent(authStoreId)}&select=data`);
    if (!Array.isArray(rows) || rows.length > 1) throw new Error("Ungueltige Antwort des Kontenspeichers");
    const row = rows[0];
    if (rows.length && (!row || !row.data || typeof row.data !== "object" || Array.isArray(row.data))) {
      throw new Error("Ungueltiger Inhalt des Kontenspeichers");
    }
    return authStoreCas.attachSnapshot({ ...defaultAuthStore(), ...(row?.data || {}) }, {
      exists: Boolean(row), revision: row?.data?.[authStoreCas.REVISION], target: authStoreTarget()
    });
  }
  if (!fs.existsSync(authDataFile)) return defaultAuthStore();
  try {
    return { ...defaultAuthStore(), ...JSON.parse(fs.readFileSync(authDataFile, "utf8")) };
  } catch (error) {
    console.error("Helmut auth store read failed", error);
    return defaultAuthStore();
  }
}

// Ringpuffergroesse des Nutzungslogs im Blob. War bisher eine nackte 5000 an der
// Kappstelle; sie ist jetzt benannt, weil `blobFensterVollstaendig` gegen genau
// diese Grenze entscheidet, ob ein Berichtsfenster still gekuerzt wurde.
const LLM_USAGE_RING_MAX = 5000;

function authStoreTarget() {
  return `${String(process.env.SUPABASE_URL || "").replace(/\/+$/, "")}|${authStoreId}`;
}

async function writeAuthStore(store) {
  const normalized = { ...defaultAuthStore(), ...store };
  normalized.sessions = (normalized.sessions || []).slice(0, 2000);
  normalized.auditEvents = (normalized.auditEvents || []).slice(0, 1000);
  normalized.systemErrors = (normalized.systemErrors || []).slice(0, 500);
  normalized.dailyInputs = (normalized.dailyInputs || []).slice(0, 2000);
  normalized.llmUsage = (normalized.llmUsage || []).slice(0, LLM_USAGE_RING_MAX);

  // P0-1: Prozess-Laufzeit-Ring gedeckelt halten (kleiner Auth-Store).
  normalized.processRuns = (normalized.processRuns || []).slice(0, 300);
  if (useSupabase()) {
    return authStoreCas.writeConditional(normalized, {
      request: supabaseRequest, rowId: authStoreId, target: authStoreTarget()
    });
  }
  fs.mkdirSync(dataDir, { recursive: true });
  fs.writeFileSync(authDataFile, JSON.stringify(normalized, null, 2));
  return normalized;
}

// Eine Kontomutation ist eine wiederholbare Aenderung auf einem FRISCHEN Stand,
// kein erneutes Schreiben eines alten Blobs. Nur bestaetigte CAS Konflikte werden
// wiederholt; Netzwerkfehler/unklarer Schreibausgang niemals. Die lokale Reihenfolge
// vermeidet Konkurrenz innerhalb einer Instanz, CAS schuetzt zwischen Instanzen.
let authMutationQueue = Promise.resolve();
const AUTH_MUTATION_MAX_ATTEMPTS = 64;
function mutateAuthStore(change) {
  const deadline = Date.now() + 30000;
  const run = async () => {
    for (let attempt = 0; attempt < AUTH_MUTATION_MAX_ATTEMPTS; attempt += 1) {
      const checkDeadline = () => {
        if (Date.now() >= deadline) {
          const error = new Error("Kontenspeicher ist derzeit ausgelastet. Bitte erneut versuchen.");
          error.statusCode = 503;
          throw error;
        }
      };
      checkDeadline();
      const store = await readAuthStore();
      // change muss ausschliesslich den uebergebenen Stand aendern, ohne externe
      // Nebenwirkung. So kann ein Konflikt keine Zustellung oder Folgearbeit verdoppeln.
      const result = await change(store);
      checkDeadline();
      try {
        await writeAuthStore(store);
        return result;
      } catch (error) {
        if (error?.code !== "AUTH_STORE_CONFLICT" || attempt === AUTH_MUTATION_MAX_ATTEMPTS - 1) throw error;
        // Breite Streuung verhindert, dass mehrere Instanzen immer wieder im
        // gleichen Takt kollidieren. 8 und 16 Versuche gaben im echten
        // Mehrprozessnachweis schon vor der Eingangsfrist auf. Jetzt ist diese
        // Frist fuehrend; 64 Versuche begrenzen zusaetzlich die Anfragemenge.
        const pause = 50 + Math.floor(Math.random() * Math.min(1000, 25 * 2 ** attempt));
        await new Promise((resolve) => setTimeout(resolve, pause));
      }
    }
  };
  const result = authMutationQueue.then(run, run);
  authMutationQueue = result.catch(() => {});
  return result;
}

// --- Quellenmodus-Shadow: letzter Production-Messlauf (kompakt, Auth-Store) --
// Persistiert den kompakten Shadow-Messbericht eines echten Crawl-Laufs (Muster wie
// adminRecoveryLastRun): überlebt Function-Kill/Reload, wird im Admin angezeigt und ist
// per SQL auslesbar. Nur Kennzahlen/IDs — keine Inhalte. Fail-safe beim Aufrufer.
async function saveSourceModeShadowRun(report = {}) {
  const store = await readAuthStore();
  const kompakt = JSON.parse(JSON.stringify(report));
  // Leitplanke: Listen deckeln, damit der kleine Auth-Store klein bleibt.
  if (kompakt.vergleich) {
    kompakt.vergleich.nurAlt = (kompakt.vergleich.nurAlt || []).slice(0, 20);
    kompakt.vergleich.nurRelational = (kompakt.vergleich.nurRelational || []).slice(0, 20);
  }
  if (kompakt.alt) kompakt.alt.fehlerQuellen = (kompakt.alt.fehlerQuellen || []).slice(0, 10);
  if (kompakt.relational) kompakt.relational.fehlerQuellen = (kompakt.relational.fehlerQuellen || []).slice(0, 10);
  await writeAuthStore({ ...store, sourceModeShadowLastRun: { ...kompakt, savedAt: new Date().toISOString() } });
  return store.sourceModeShadowLastRun || null;
}

async function getSourceModeShadowLastRun() {
  const store = await readAuthStore();
  return store.sourceModeShadowLastRun || null;
}

// --- Globale Dedup + Fundstellen (Cutover-Schreibpfad, Quellenmodus 'on') ----
// Persistiert einen Crawl-Batch mit globaler Deduplizierung: 1 Artikel ueber n Wege ->
// 1 raw_document + n document_findings; Treffer gegen den BESTAND (content_fingerprint/
// canonical_target_url, letzte 14 Tage) erzeugen KEIN neues Dokument, nur Fundstellen +
// finding_count-Erhoehung. Wird AUSSCHLIESSLICH vom Quellenmodus 'on' aufgerufen
// (source-mode.js, Cutover — freigabepflichtig); off/shadow beruehren diesen Pfad nie.
// Fail-safe: jeder Teilschritt schluckt Fehler einzeln — ein Dedup-/Findings-Fehler
// darf den Crawl nie brechen (schlimmstenfalls fehlt eine Fundstelle).
//
// KAPAZITAETSBEFUND F-RT (Production 2026-08-03, Lauf `cron-pipeline-20260803160002-xm71n`):
// dieser Schreibpfad war die HAUPTURSACHE dafuer, dass der globale Abruf sein Zeitbudget
// gesprengt hat. Er schickte je Dokument einen EIGENEN Round-Trip an PostgREST — gemessen
// 616 Einzel-Upserts in 89,89 s plus ~108 x (GET+PATCH) fuer `finding_count` in 34,85 s,
// zusammen 834 Requests / 124,74 s = 46,7 % eines 267-s-Laufs, bei ~149,6 ms je Round-Trip.
// Beide Schleifen sind deshalb gebuendelt. Die FACHLICHE Wirkung ist unveraendert: es werden
// dieselben Zeilen mit denselben Werten geschrieben, nur in wenigen Anfragen statt in
// hunderten. Der Dedup-Plan, die Fundstellen und die Bestandslogik sind unberuehrt.
// BESTANDSFENSTER-BEFUND (Kapazitätssprint 2026-08-31, rein lesend verifiziert):
// Der fruehere EINE Read mit `limit=5000` bekam von PostgREST still hoechstens
// 1.000 Zeilen (Server-Kappe je Anfrage, dasselbe Muster wie Befund W-1 /
// listKnowledgeObjectsSeitenweise) — das "14-Tage-Fenster" war bei ~344 docs/Tag
// effektiv nur ~2,9 Tage. Cross-Source-Dubletten aelter als ~3 Tage wurden nicht
// mehr erkannt und wurden zu eigenen Dokumenten (gemessen 31.08.: 23 Fingerprints
// mit Mehrfachzeilen und Zeitspanne > 3 Tage in 14 Tagen). Deshalb liest das
// Fenster jetzt SEITENWEISE, ohne Abhaengigkeit von einer einzelnen
// PostgREST-Seite; die fachliche Dedup-Semantik (planDedupWrites) ist unveraendert.
// Der Deckel schuetzt nur das Zeitbudget des Crawl-Slots und meldet sich LAUT —
// kein stilles Kappen mehr; die tatsaechliche Fenstergroesse steht im Ergebnis.
const DEDUP_BESTAND_SEITE = 1000; // PostgREST-Kappe je Anfrage (nicht konfigurierbar erhoehen)
// Pro AUFRUF gelesen (Konvention wie verstehen-rueckstand.js): unbrauchbare Werte fallen
// geschlossen auf den Default 12 (= 12.000 Zeilen ≈ 14 Tage x ~850 docs/Tag Reserveband).
function dedupBestandMaxSeiten() {
  const n = Number(process.env.HELMUT_DEDUP_BESTAND_MAX_SEITEN);
  return Number.isFinite(n) && n >= 2 ? Math.floor(n) : 12;
}

async function ladeDedupBestandsfenster() {
  // BLOCKER-5-KORREKTUR (500-Mandate-Reife 2026-09-01): `order=created_at.desc`
  // allein ist KEINE Totalordnung — bei identischen Zeitstempeln (ein Crawl-Batch
  // schreibt viele Zeilen in derselben Transaktion) ist die Reihenfolge innerhalb
  // der Gleichstandsgruppe serverseitig UNDEFINIERT und kann sich zwischen zwei
  // Seitenanfragen aendern: Zeilen fehlen oder erscheinen doppelt. Die
  // Zweitsortierung `id.desc` (id ist eindeutig) macht die Offset-Paginierung
  // zu einer echten Totalordnung — kein Datensatz kann bei identischen
  // Zeitstempeln verloren gehen oder doppelt erscheinen.
  // Neueste zuerst: falls der Deckel je greift, verliert das Fenster die AELTESTEN
  // Tage zuerst — exakt das bisherige (nun aber gemeldete) Degradationsverhalten.
  const stichtag = encodeURIComponent(new Date(Date.now() - 14 * 86400000).toISOString());
  const maxSeiten = dedupBestandMaxSeiten();
  const bestand = [];
  let seiten = 0;
  let gedeckelt = false;
  for (; seiten < maxSeiten; seiten += 1) {
    const rows = await supabaseRequest(
      "/rest/v1/raw_documents?select=id,content_fingerprint,canonical_target_url" +
      `&created_at=gte.${stichtag}&order=created_at.desc,id.desc` +
      `&limit=${DEDUP_BESTAND_SEITE}&offset=${seiten * DEDUP_BESTAND_SEITE}`
    );
    if (!Array.isArray(rows) || !rows.length) break;
    bestand.push(...rows);
    if (rows.length < DEDUP_BESTAND_SEITE) break;
  }
  if (seiten >= maxSeiten) {
    gedeckelt = true;
    console.error(`[dedup] Bestandsfenster am Seiten-Deckel (${maxSeiten} x ${DEDUP_BESTAND_SEITE}): `
      + `aelteste Tage des 14-Tage-Fensters fehlen — Dedup-Reichweite ehrlich verkuerzt (HELMUT_DEDUP_BESTAND_MAX_SEITEN erhoehen).`);
  }
  return { bestand, seiten: Math.max(1, seiten + (gedeckelt ? 0 : 1)), gedeckelt };
}

async function persistRawDocumentsDeduped(items = []) {
  if (!v3StoreReady()) return { skipped: true, reason: v3SkipReason() };
  const { planDedupWrites } = require("./quellenarchitektur/dedup-global");
  let existing = [];
  let fenster = { zeilen: 0, seiten: 0, gedeckelt: false, fehler: null };
  try {
    const geladen = await ladeDedupBestandsfenster();
    existing = geladen.bestand;
    fenster = { zeilen: geladen.bestand.length, seiten: geladen.seiten, gedeckelt: geladen.gedeckelt, fehler: null };
  } catch (error) {
    // Fehlerverhalten unveraendert (fail-safe): ohne Bestand wird der Batch ohne
    // Bestands-Match persistiert — aber der Ausfall steht jetzt auch im Ergebnis.
    fenster.fehler = String((error && error.message) || "unbekannt").slice(0, 160);
    console.error("[dedup] Bestandsabruf fehlgeschlagen (Batch wird ohne Bestands-Match persistiert):", error.message);
  }
  const plan = planDedupWrites(items, Array.isArray(existing) ? existing : []);

  const zuSchreiben = plan.persists.map((doc) => {
    const row = {
      ...doc,
      canonical_target_url: doc.canonical_url || null,
      publisher_id: doc.publisher_domain ? `publisher-${doc.publisher_domain}` : null,
      source_id: doc.primary_source_id || doc.source_id || null
    };
    delete row.findings; delete row.publisher_domain; delete row.primary_source_id;
    return row;
  });
  const schreiben = await saveRawDocumentsGebuendelt(zuSchreiben);

  let findingsWritten = 0;
  if (plan.findings.length) {
    try {
      const rows = plan.findings.slice(0, 2000).map((f) => ({
        raw_document_id: f.raw_document_id,
        source_id: f.source_id || "unbekannt",
        retrieval_path_id: f.retrieval_path_id || null,
        original_url: f.original_url || "",
        link_type: f.link_type || null,
        found_at: f.found_at || null
      }));
      await supabaseRequest("/rest/v1/document_findings?on_conflict=raw_document_id,source_id,original_url", {
        method: "POST",
        headers: { Prefer: "resolution=ignore-duplicates,return=minimal" },
        body: JSON.stringify(rows)
      });
      findingsWritten = rows.length;
    } catch (error) {
      console.error("[dedup] Fundstellen-Write fehlgeschlagen (ignoriert):", error.message);
    }
  }

  const zaehler = await erhoeheFindingCounts(plan.countIncrements);

  return {
    persisted: schreiben.persisted,
    zusammengefuehrt: items.length - plan.persists.length,
    fundstellen: findingsWritten,
    bestandsTreffer: Object.keys(plan.countIncrements).length,
    // Messbarkeit des Bestandsfensters (Befund 2026-08-31): tatsaechlich gelesene
    // Zeilen/Seiten, ob der Seiten-Deckel griff und ob der Abruf ausfiel. Die
    // Dublettenquote des Batches ist damit je Lauf ablesbar:
    // zusammengefuehrt + bestandsTreffer gegen items-Eingang.
    bestandsfenster: fenster,
    // Beleg statt Behauptung: wie viele Round-Trips dieser Batch wirklich gebraucht hat.
    // Genau diese Zahl ist in Production entgleist (834) und wird jetzt mitgeschrieben.
    // Der Bestandsabruf zaehlt mit seiner ECHTEN Seitenzahl (frueher pauschal 1).
    schreibAnfragen: (fenster.fehler ? 1 : fenster.seiten) + schreiben.anfragen + (plan.findings.length ? 1 : 0) + zaehler.anfragen,
    einzelnNachgezogen: schreiben.einzeln,
    zaehlerAktualisiert: zaehler.aktualisiert,
    zaehlerVerfehlt: zaehler.verfehlt.length
  };
}

// Groesse eines Bulk-Blocks. Klein genug fuer eine berechenbare Anfrage, gross genug, damit
// ein voller Crawl-Batch (Production: 616 neue Dokumente) in wenige Anfragen passt.
const RAW_DOCUMENT_BULK_CHUNK = Math.max(1, Number(process.env.HELMUT_RAW_DOCUMENT_BULK_CHUNK) || 200);

// Bulk-Upsert der neuen Rohdokumente.
//
// SPALTENGLEICHHEIT: PostgREST verlangt in EINEM Bulk-Body identische Schluesselmengen. Zeilen
// werden deshalb nach ihrer Spaltensignatur gruppiert, statt fehlende Spalten mit `null`
// aufzufuellen — sonst wuerde ein `merge-duplicates`-Upsert eine vorhandene Spalte eines
// bestehenden Dokuments mit `null` UEBERSCHREIBEN. Der Einzel-Upsert hat das nie getan, und
// dieser Pfad tut es auch nicht.
//
// FEHLERVERHALTEN unveraendert: schlaegt ein Block fehl (eine einzelne unbrauchbare Zeile
// reisst in PostgREST den ganzen Block mit), wird GENAU DIESER Block einmal einzeln
// nachgezogen. Damit bleibt die bisherige Robustheit erhalten: eine kaputte Zeile kostet die
// uebrigen nicht.
async function saveRawDocumentsGebuendelt(rows = []) {
  const liste = (Array.isArray(rows) ? rows : []).filter((row) => row && row.id);
  let persisted = 0;
  let anfragen = 0;
  let einzeln = 0;
  const gruppen = new Map();
  for (const row of liste) {
    const spalten = pickColumns(row, V3_RAW_DOCUMENT_COLUMNS);
    const signatur = Object.keys(spalten).sort().join("|");
    if (!gruppen.has(signatur)) gruppen.set(signatur, []);
    gruppen.get(signatur).push({ row, spalten });
  }
  for (const gruppe of gruppen.values()) {
    for (let i = 0; i < gruppe.length; i += RAW_DOCUMENT_BULK_CHUNK) {
      const block = gruppe.slice(i, i + RAW_DOCUMENT_BULK_CHUNK);
      try {
        anfragen += 1;
        await supabaseRequest("/rest/v1/raw_documents?on_conflict=id", {
          method: "POST",
          headers: { Prefer: "resolution=merge-duplicates,return=minimal" },
          body: JSON.stringify(block.map((b) => b.spalten))
        });
        persisted += block.length;
      } catch (error) {
        console.error(`[v3Store] raw_documents Bulk-Upsert fehlgeschlagen (${block.length} Zeilen,`
          + ` Einzelfallback): ${error.message}`);
        for (const b of block) {
          anfragen += 1;
          einzeln += 1;
          const res = await saveRawDocument(b.row);
          if (res && res.saved) persisted += 1;
        }
      }
    }
  }
  return { persisted, anfragen, einzeln };
}

// ── OP-30 Option B (Reparatursprint 2026-08-19): kanonische Rohdokument-Persistenz des
// WARTESCHLANGENPFADS — relational, gebuendelt, OHNE jeden Blob-Zugriff. ─────────────────────
//
// BELEGTER ANLASS: der erste Aktivierungslauf der skalierbaren Pipeline (18.08. 20:00 UTC)
// hat 0 von 193 Auftraegen abgeschlossen, weil JEDER `source_fetch`-Auftrag ueber
// `saveRawItems` die zentrale Blob-Zeile `main` (1,29 MB) vollstaendig las und schrieb —
// unter Parallelitaet 4 ein Row-Lock-Konvoi mit 10-s-Timeouts und Retry-Verstaerkung
// (Runbook op30-aktivierung-5-mandate.md §27). Der Warteschlangenpfad persistiert deshalb
// ausschliesslich relational (`raw_documents`); der Blob wird nur noch HOECHSTENS EINMAL JE
// SLOT als Lesespiegel nachgezogen (worker-betrieb.durchlauf), nie je Auftrag.
//
// `ignore-duplicates` + `return=representation` liefert in EINEM Round-Trip exakt die
// Kennungen der NEU eingefuegten Zeilen — genau die Menge, die der Handler zum Einreihen
// des Verstehens braucht. Bestehende Zeilen bleiben unveraendert; das ist byte-gleich zum
// bisherigen Verhalten, denn die Blob-Deduplizierung hat bereits gesehene Artikel schon
// bisher VOR dem relationalen Schreiben ausgefiltert.
//
// Fehlerverhalten: kein stilles Verschlucken und KEIN Schreiben in den Auth-Blob (die
// Quittung des Auftrags traegt `helmut_jobs.last_error`). `ok:false` + Grund; der Handler
// wirft daraufhin und der Auftrag wird mit Backoff wiederholt.
async function persistiereRohdokumenteWarteschlange(items = [], { runId = null } = {}) {
  if (!v3StoreReady()) return { ok: false, grund: v3SkipReason(), neuIds: [], vorhandene: 0, anfragen: 0 };
  const { toRawDocumentRow, dedupeRawDocuments } = require("./dedup");
  const rows = dedupeRawDocuments((Array.isArray(items) ? items : [])
    .map(toRawDocumentRow).filter((row) => row && row.id));
  if (!rows.length) return { ok: true, neuIds: [], kandidaten: (items || []).length, vorhandene: 0, anfragen: 0 };

  // Wie `saveRawDocumentsGebuendelt`: nach Spaltensignatur gruppieren, damit ein Bulk-POST
  // nie an heterogenen Zeilen scheitert.
  const gruppen = new Map();
  for (const row of rows) {
    const spalten = pickColumns(row, V3_RAW_DOCUMENT_COLUMNS);
    const signatur = Object.keys(spalten).sort().join("|");
    if (!gruppen.has(signatur)) gruppen.set(signatur, []);
    gruppen.get(signatur).push(spalten);
  }

  const neuIds = [];
  let anfragen = 0;
  try {
    for (const gruppe of gruppen.values()) {
      for (let i = 0; i < gruppe.length; i += RAW_DOCUMENT_BULK_CHUNK) {
        const block = gruppe.slice(i, i + RAW_DOCUMENT_BULK_CHUNK);
        anfragen += 1;
        const eingefuegt = await supabaseRequest("/rest/v1/raw_documents?on_conflict=id&select=id", {
          method: "POST",
          headers: { Prefer: "resolution=ignore-duplicates,return=representation" },
          body: JSON.stringify(block)
        });
        for (const zeile of Array.isArray(eingefuegt) ? eingefuegt : []) {
          if (zeile && zeile.id) neuIds.push(String(zeile.id));
        }
      }
    }
  } catch (error) {
    console.error(`[warteschlange] Rohdokument-Persistenz fehlgeschlagen (Lauf ${runId || "?"}):`, error.message);
    return {
      ok: false,
      grund: String((error && error.message) || "persistenz-fehler").slice(0, 200),
      neuIds, kandidaten: items.length, vorhandene: 0, anfragen
    };
  }
  return { ok: true, neuIds, kandidaten: items.length, vorhandene: rows.length - neuIds.length, anfragen };
}

// `finding_count` der Bestandstreffer erhoehen — gebuendelt UND BEDINGT.
//
// CLAUDE.md §4.10: Lesen -> Aendern -> Schreiben ohne Bedingung ist auf gemeinsam genutztem
// Zustand verboten. Der bisherige Pfad tat genau das (je Dokument `select finding_count`,
// danach `PATCH finding_count = gelesen + inc`) und haette einen parallelen Lauf
// stillschweigend ueberschrieben. Hier wird deshalb nach (gelesener Stand, Zuwachs)
// gruppiert: alle Dokumente einer Gruppe bekommen denselben neuen Wert unter derselben
// Bedingung `finding_count=eq.<gelesener Stand>`. Das ist ein echtes Compare-and-Set —
// eine Zeile, die inzwischen ein anderer Lauf veraendert hat, wird NICHT getroffen und
// NICHT ueberschrieben. Sie wird gezaehlt und benannt statt still verloren.
const FINDING_COUNT_CHUNK = Math.max(1, Number(process.env.HELMUT_FINDING_COUNT_CHUNK) || 100);

function inFilterWert(id) {
  return `"${String(id).replace(/"/g, '""')}"`;
}

async function erhoeheFindingCounts(countIncrements = {}) {
  const ids = Object.keys(countIncrements || {});
  if (!ids.length) return { aktualisiert: 0, verfehlt: [], anfragen: 0 };
  let anfragen = 0;
  const gelesen = new Map();
  for (let i = 0; i < ids.length; i += FINDING_COUNT_CHUNK) {
    const teil = ids.slice(i, i + FINDING_COUNT_CHUNK);
    try {
      anfragen += 1;
      const rows = await supabaseRequest(
        `/rest/v1/raw_documents?id=in.(${teil.map(inFilterWert).join(",")})&select=id,finding_count`
      );
      for (const r of Array.isArray(rows) ? rows : []) gelesen.set(String(r.id), Number(r.finding_count) || 0);
    } catch (error) {
      console.error("[dedup] finding_count-Lesen fehlgeschlagen (ignoriert):", error.message);
    }
  }

  const gruppen = new Map();
  for (const id of ids) {
    if (!gelesen.has(id)) continue;
    const stand = gelesen.get(id);
    const inc = Number(countIncrements[id]) || 0;
    const key = `${stand}|${inc}`;
    if (!gruppen.has(key)) gruppen.set(key, { stand, neu: stand + inc, ids: [] });
    gruppen.get(key).ids.push(id);
  }

  let aktualisiert = 0;
  const verfehlt = [];
  for (const gruppe of gruppen.values()) {
    for (let i = 0; i < gruppe.ids.length; i += FINDING_COUNT_CHUNK) {
      const teil = gruppe.ids.slice(i, i + FINDING_COUNT_CHUNK);
      try {
        anfragen += 1;
        const rows = await supabaseRequest(
          `/rest/v1/raw_documents?id=in.(${teil.map(inFilterWert).join(",")})`
          + `&finding_count=eq.${gruppe.stand}&select=id`,
          {
            method: "PATCH",
            headers: { Prefer: "return=representation" },
            body: JSON.stringify({ finding_count: gruppe.neu })
          }
        );
        const getroffen = new Set((Array.isArray(rows) ? rows : []).map((r) => String(r && r.id)));
        aktualisiert += getroffen.size;
        for (const id of teil) if (!getroffen.has(id)) verfehlt.push(id);
      } catch (error) {
        console.error("[dedup] finding_count-Update fehlgeschlagen (ignoriert):", error.message);
        verfehlt.push(...teil);
      }
    }
  }
  if (verfehlt.length) {
    console.warn(`[dedup] finding_count: ${verfehlt.length} von ${ids.length} Dokumenten nicht erhoeht`
      + " (Bedingung nicht mehr erfuellt oder Zeile nicht gefunden) — kein Wert ueberschrieben.");
  }
  return { aktualisiert, verfehlt, anfragen };
}

// --- Quellenarchitektur: relationale Zeilen (read-only) ---------------------
// Lädt die vier Quellenarchitektur-Tabellen für Crawl-Plan/Vergleich/Admin-Report.
// NUR Supabase-Backend; lokal/ohne Konfiguration -> null (Aufrufer fällt auf den
// alten Katalog bzw. auf Seeds zurück — ehrlich als "nicht verfügbar" markierbar).
async function listSourceArchitectureRows() {
  if (!useSupabase()) return null;
  const [publishers, retrievalPaths, packages, packagePaths, geographies] = await Promise.all([
    supabaseRequest("/rest/v1/publishers?select=*&limit=1000"),
    supabaseRequest("/rest/v1/retrieval_paths?select=*&limit=2000"),
    supabaseRequest("/rest/v1/source_packages?select=*&limit=500"),
    supabaseRequest("/rest/v1/package_paths?select=*&limit=5000"),
    // Punkt 18: nur fuer LESBARE Regionsnamen in der Paket-Inventur (geo-land-berlin
    // -> "Berlin"). Rein additiv; faellt der Aufruf aus, bleibt die Region die ID.
    supabaseRequest("/rest/v1/geographies?select=id,level,name,parent_id&limit=2000").catch(() => [])
  ]);
  return {
    publishers: Array.isArray(publishers) ? publishers : [],
    retrievalPaths: Array.isArray(retrievalPaths) ? retrievalPaths : [],
    packages: Array.isArray(packages) ? packages : [],
    packagePaths: Array.isArray(packagePaths) ? packagePaths : [],
    geographies: Array.isArray(geographies) ? geographies : []
  };
}

// --- Gate-Shadow-Telemetrie (gate_shadow_events) ---------------------------
// Schreibt die Understanding-Gate-Shadow-Entscheidungen (nur Signale/IDs, KEIN
// Volltext/PII) in die Production-Tabelle gate_shadow_events (RLS service_role-only).
// NUR im Supabase-Backend; lokal ein No-op. Der Aufrufer (understanding.js) kapselt
// den Aufruf fail-safe — ein Telemetrie-Fehler darf das Understanding NIE beeinflussen.
const GATE_SHADOW_EVENT_FIELDS = Object.freeze([
  "raw_document_id", "source_id", "package_id", "tier", "gate_decision", "gate_reason",
  "political_signals", "amtlich", "geografie", "document_type", "vorgang_id",
  "understanding_result", "knowledge_object_id", "estimated_cost_usd", "model"
]);

async function recordGateShadowEvents(rows) {
  const list = (Array.isArray(rows) ? rows : [])
    .filter((r) => r && typeof r === "object" && typeof r.gate_decision === "string" && r.gate_decision)
    .slice(0, 500) // Leitplanke: begrenzt Payload je Lauf; Ueberhang wird im Aggregat-Log sichtbar
    .map((r) => {
      const out = {};
      for (const f of GATE_SHADOW_EVENT_FIELDS) { if (r[f] !== undefined) out[f] = r[f]; }
      return out;
    });
  if (!list.length) return { written: 0, reason: "keine-zeilen" };
  if (!useSupabase()) return { written: 0, reason: "local-backend-keine-telemetrie" };
  await supabaseRequest("/rest/v1/gate_shadow_events", {
    method: "POST",
    headers: { Prefer: "return=minimal" },
    body: JSON.stringify(list)
  });
  return { written: list.length };
}

// ── GATE-ARM (OP-18, Kapazitätssprint 2026-08-31): Parkungs-Beleg und -Zustand ─────────
// Der Beleg einer Gate-Parkung ist KEINE fail-safe Telemetrie, sondern die
// Voraussetzung der Parkung selbst (Produktentscheidung: jeder geparkte Vorgang
// traegt Grund, Gate-Version und Entscheidungszeitpunkt). Deshalb eine EIGENE,
// fail-GESCHLOSSENE Schreibfunktion: schlaegt der Beleg fehl, liefert sie
// { ok:false } und der Aufrufer parkt NICHT (der Vorgang wird normal verstanden —
// der sichere Fehler kostet einen Aufruf, verliert aber nie Arbeit und erzeugt
// nie eine beleglose Parkung). Zeilen landen in gate_shadow_events mit
// understanding_result = 'gate-geparkt@<version>' (das ehrliche Verstehens-
// Ergebnis dieser Dokumente) bzw. 'gate-freigegeben@<version>' bei Wiederfreigabe.
async function recordGateParkungBeleg(rows) {
  const list = (Array.isArray(rows) ? rows : [])
    .filter((r) => r && typeof r === "object" && typeof r.gate_decision === "string" && r.gate_decision
      && typeof r.understanding_result === "string" && r.understanding_result)
    .slice(0, 500)
    .map((r) => {
      const out = {};
      for (const f of GATE_SHADOW_EVENT_FIELDS) { if (r[f] !== undefined) out[f] = r[f]; }
      return out;
    });
  if (!list.length) return { ok: false, written: 0, grund: "keine-zeilen" };
  if (!useSupabase()) return { ok: false, written: 0, grund: "kein-supabase-backend" };
  try {
    await supabaseRequest("/rest/v1/gate_shadow_events", {
      method: "POST",
      headers: { Prefer: "return=minimal" },
      body: JSON.stringify(list)
    });
    return { ok: true, written: list.length };
  } catch (error) {
    return { ok: false, written: 0, grund: String((error && error.message) || "unbekannt").slice(0, 160) };
  }
}

// Zustandsuebergang pending -> gate-geparkt. KONDITIONALES PATCH auf den erwarteten
// Vorstatus (CLAUDE.md §4.10): hat sich der Status seit der Entscheidung geaendert
// (z. B. inzwischen complete durch einen parallelen Lauf), trifft der Filter 0 Zeilen
// und es wird NICHTS geschrieben. `gate-geparkt` ist bereits Ziel UND erlaubter
// Vorstatus (idempotente Neubewertung derselben Entscheidung).
//
// BLOCKER-2-KORREKTUR (500-Mandate-Reife, 2026-09-01): `Prefer: return=minimal`
// lieferte HTTP 204 auch bei 0 getroffenen Zeilen — die Funktion meldete dann
// faelschlich { ok:true }, obwohl NICHTS geparkt war (der Aufrufer haette den
// Vorgang als geparkt gemeldet und uebersprungen: stiller Arbeitsausfall).
// Jetzt gilt: Erfolg NUR, wenn die Rueckgabe (return=representation) GENAU EINE
// Zeile mit der erwarteten Vorgangskennung im Zielzustand belegt. 0 Zeilen =
// Vorzustand hat sich geaendert (kein Erfolg); mehr als 1 Zeile = unerwarteter
// Mehrfachtreffer (Datenanomalie — kein Erfolg, sichtbar gemeldet).
async function markUnderstandingGateGeparkt(vorgangId) {
  if (!v3StoreReady()) return { ok: false, skipped: true, reason: v3SkipReason() };
  if (!vorgangId) return { ok: false, skipped: true, reason: "missing-vorgang" };
  try {
    const rows = await supabaseRequest(
      `/rest/v1/knowledge_objects?vorgang_id=eq.${encodeURIComponent(vorgangId)}&understanding_status=in.(pending,gate-geparkt)`,
      { method: "PATCH", headers: { Prefer: "return=representation" }, body: JSON.stringify({ understanding_status: "gate-geparkt", updated_at: new Date().toISOString() }) }
    );
    if (!Array.isArray(rows)) return { ok: false, reason: "antwort-unlesbar" };
    if (rows.length === 0) return { ok: false, reason: "kein-treffer-vorzustand-veraendert" };
    if (rows.length > 1) return { ok: false, reason: `mehrfachtreffer:${rows.length}` };
    const zeile = rows[0] || {};
    if (zeile.vorgang_id !== vorgangId || zeile.understanding_status !== "gate-geparkt") {
      return { ok: false, reason: "unerwartete-zeile" };
    }
    return { ok: true, zeilen: 1 };
  } catch (error) {
    return { ok: false, reason: String((error && error.message) || "unbekannt").slice(0, 160) };
  }
}

// Wiederfreigabe gate-geparkt -> pending (Rueckweg / neue Gate-Version / Betreiber).
// Konditional auf den Vorstatus; liefert die tatsaechlich freigegebene Menge.
async function releaseUnderstandingGateGeparkt(vorgangIds = []) {
  if (!v3StoreReady()) return { ok: false, freigegeben: 0, reason: v3SkipReason() };
  const ids = [...new Set((Array.isArray(vorgangIds) ? vorgangIds : []).filter((v) => typeof v === "string" && v))].slice(0, 200);
  if (!ids.length) return { ok: true, freigegeben: 0 };
  try {
    const rows = await supabaseRequest(
      `/rest/v1/knowledge_objects?vorgang_id=in.(${ids.map((v) => `"${v.replace(/"/g, "")}"`).join(",")})&understanding_status=eq.gate-geparkt`,
      { method: "PATCH", headers: { Prefer: "return=representation" }, body: JSON.stringify({ understanding_status: "pending", updated_at: new Date().toISOString() }) }
    );
    return { ok: true, freigegeben: Array.isArray(rows) ? rows.length : 0 };
  } catch (error) {
    return { ok: false, freigegeben: 0, reason: String((error && error.message) || "unbekannt").slice(0, 160) };
  }
}

// Geparkte Vorgaenge fuer die Wiedervorlage (aelteste zuerst, mit Tagesrotation
// ueber offset — deterministisch, ohne Schreibzugriff).
async function listGateGeparkteKnowledgeObjects({ limit = 25, offset = 0 } = {}) {
  if (!v3StoreReady()) return [];
  const safeLimit = Number.isFinite(Number(limit)) && Number(limit) > 0 ? Math.min(200, Math.floor(Number(limit))) : 25;
  const safeOffset = Number.isFinite(Number(offset)) && Number(offset) > 0 ? Math.floor(Number(offset)) : 0;
  try {
    const rows = await supabaseRequest(
      `/rest/v1/knowledge_objects?select=id,vorgang_id,created_at,updated_at,understanding_status&understanding_status=eq.gate-geparkt&order=created_at.asc&limit=${safeLimit}&offset=${safeOffset}`
    );
    return Array.isArray(rows) ? rows : [];
  } catch (error) {
    console.error("[v3Store] listGateGeparkteKnowledgeObjects fehlgeschlagen:", error.message);
    return [];
  }
}

// Anzahl geparkter Vorgaenge (Gesundheitsbericht). null = nicht messbar, nie 0 erfinden.
async function countGateGeparkt() {
  if (!v3StoreReady()) return null;
  try {
    const rows = await supabaseRequest("/rest/v1/knowledge_objects?select=count&understanding_status=eq.gate-geparkt");
    return Array.isArray(rows) && rows[0] ? (Number(rows[0].count) || 0) : null;
  } catch {
    return null;
  }
}

// ── DRAIN-BILANZ (PR-C, Kapazitätssprint 2026-08-31; Blocker 3+4-Korrektur
// 500-Mandate-Reife 2026-09-01): fail-safe Lesegroessen ────────────────────────────
// Die Abnahmegroesse des Kapazitätsziels — "gate-wuerdiger Abfluss >= gate-wuerdige
// Ankunft, verarbeitbarer Rueckstand waechst nicht" — wird damit TAEGLICH MESSBAR
// statt behauptet. Alle Groessen liefern bei Nichtmessbarkeit null (nie eine
// erfundene 0, CLAUDE.md §4.4); der Bericht zeigt dann "?". Keine neue Tabelle.
// BLOCKER-4-KORREKTUR: die fruehere Ereignisabfrage mit `limit=10000` bekam von
// PostgREST still hoechstens 1.000 Zeilen (Server-Kappe, Befund-W-1-Klasse) —
// eine abgeschnittene Ankunftszaehlung haette die Ankunft UNTERSCHAETZT und damit
// falsches Gruen ermoeglicht. Jetzt: begrenzte, DETERMINISTISCHE Pagination
// (Totalordnung created_at + id); reisst der Seiten-Deckel, gilt die Groesse als
// NICHT messbar (null, laut gemeldet) — nie als kleinere Zahl.

const GATE_EREIGNIS_SEITE = 1000; // PostgREST-Kappe je Anfrage (nicht konfigurierbar erhoehen)
// Pro AUFRUF gelesen (Konvention wie dedupBestandMaxSeiten): unbrauchbare Werte
// fallen geschlossen auf den Default 15 (= 15.000 Ereignis-Zeilen je Messung).
function gateEreignisMaxSeiten() {
  const n = Number(process.env.HELMUT_GATE_EREIGNIS_MAX_SEITEN);
  return Number.isFinite(n) && n >= 2 ? Math.floor(n) : 15;
}

// Deterministische, begrenzte Seitenlese fuer gate_shadow_events. Die Ordnung
// `created_at.asc,id.asc` ist eine TOTALORDNUNG (id ist bigint PK) — bei
// identischen Zeitstempeln kann keine Zeile zwischen zwei Seiten verschwinden
// oder doppelt erscheinen (dasselbe Blocker-5-Muster wie im Dedup-Fenster).
// Wirft bei unlesbarer Antwort; meldet den Deckel ehrlich statt still zu kappen.
async function ladeGateEreignisseSeitenweise(filter, { select = "raw_document_id" } = {}) {
  const maxSeiten = gateEreignisMaxSeiten();
  const zeilen = [];
  let seiten = 0;
  for (; seiten < maxSeiten; seiten += 1) {
    const rows = await supabaseRequest(
      `/rest/v1/gate_shadow_events?select=${select}&${filter}`
      + `&order=created_at.asc,id.asc&limit=${GATE_EREIGNIS_SEITE}&offset=${seiten * GATE_EREIGNIS_SEITE}`
    );
    if (!Array.isArray(rows)) throw new Error("gate_shadow_events: antwort-unlesbar");
    zeilen.push(...rows);
    if (rows.length < GATE_EREIGNIS_SEITE) return { zeilen, seiten: seiten + 1, gedeckelt: false };
  }
  console.error(`[drain-bilanz] gate_shadow_events am Seiten-Deckel (${maxSeiten} x ${GATE_EREIGNIS_SEITE}) — Messung gilt als NICHT messbar (HELMUT_GATE_EREIGNIS_MAX_SEITEN erhoehen).`);
  return { zeilen, seiten, gedeckelt: true };
}

// Gate-wuerdige ANKUNFT der letzten `stunden`: verschiedene Rohdokumente, deren
// (Schatten- oder Arm-)Gate-Entscheidung verstehen/zurueckstellen war — beides
// kostet bei Verarbeitung einen vollen Modellaufruf, nur echtes Parken spart ihn.
// Zaehlt distinct raw_document_id — Mehrfachbewertungen desselben Dokuments
// (Schattenlaeufe bewerten je Lauf) zaehlen nicht doppelt.
async function zaehleGateWuerdigeAnkunft(stunden = 24) {
  if (!useSupabase()) return null;
  const seit = new Date(Date.now() - Math.max(1, Number(stunden) || 24) * 3600e3).toISOString();
  try {
    const geladen = await ladeGateEreignisseSeitenweise(
      `gate_decision=in.(verstehen,zurueckstellen)&created_at=gte.${encodeURIComponent(seit)}`
    );
    if (geladen.gedeckelt) return null; // abgeschnitten waere eine falsche (zu kleine) Ankunft
    return new Set(geladen.zeilen.map((r) => r && r.raw_document_id).filter(Boolean)).size;
  } catch {
    return null;
  }
}

// ABFLUSS (brutto) der letzten `stunden`: complete-Beruehrungen von Vorgaengen.
// Ehrliche Benennung: enthaelt auch AKTUALISIERUNGEN bestehender Vorgaenge und
// ist damit eine OBERGRENZE des echten Abflusses — fuer die Drain-Bilanz gilt
// deshalb ausschliesslich zaehleGateWuerdigerAbfluss (Blocker 3).
async function zaehleVerstandene(stunden = 24) {
  if (!v3StoreReady()) return null;
  const seit = new Date(Date.now() - Math.max(1, Number(stunden) || 24) * 3600e3).toISOString();
  try {
    const rows = await supabaseRequest(
      "/rest/v1/knowledge_objects?select=count&understanding_status=eq.complete"
      + `&updated_at=gte.${encodeURIComponent(seit)}`
    );
    return Array.isArray(rows) && rows[0] ? (Number(rows[0].count) || 0) : null;
  } catch {
    return null;
  }
}

// ── BLOCKER-3-KORREKTUR: ECHTER gate-wuerdiger Abfluss ──────────────────────────────
// Die fruehere Bilanz verglich gate-wuerdige Ankunft mit ALLEN complete-Beruehrungen —
// ein systematisch zu grosser Abfluss (Aktualisierungen + nicht gate-wuerdige
// Vorgaenge zaehlten mit) und damit falsches Gruen. Jetzt wird jeder im Fenster
// abgeschlossene Vorgang gegen die persistierte Gate-Entscheidung SEINER Dokumente
// geprueft (knowledge_objects -> ko_document_links -> gate_shadow_events):
//   gatewuerdig      = mindestens ein Dokument mit verstehen/zurueckstellen
//   nichtGatewuerdig = bewertete Dokumente, aber ausschliesslich parken
//   unbewertet       = keine (auffindbare) Gate-Entscheidung (Altbestand vor der
//                      Gate-Telemetrie) — wird NIE als gatewuerdig behauptet
// Jede Teillese ist begrenzt UND deterministisch geordnet; reisst ein Deckel oder
// scheitert ein Read, ist die ganze Groesse null (nicht messbar), nie eine Zahl.
const ABFLUSS_SEITE = 1000;
const ABFLUSS_BLOCK_MAX_SEITEN = 10; // je in.()-Block: 10 x 1.000 Zeilen, dann ehrlich null
function abflussMaxSeiten() {
  const n = Number(process.env.HELMUT_ABFLUSS_MAX_SEITEN);
  return Number.isFinite(n) && n >= 2 ? Math.floor(n) : 5;
}
function inListe(werte) {
  return `in.(${werte.map((v) => `"${String(v).replace(/"/g, "")}"`).join(",")})`;
}
// Liest einen in.()-Block VOLLSTAENDIG (Review-Befund 2026-09-01: ein legitim
// voller Block — z. B. 50 Dokumente mit vielen Schatten-Events — galt frueher
// pauschal als Kappung und liess die Messgroesse dauerhaft auf null fallen).
// Deterministische Offset-Pagination auf der uebergebenen Totalordnung; erst
// jenseits des Block-Deckels gilt ehrlich "nicht messbar" (null, laut gemeldet).
async function ladeAbflussBlockSeitenweise(basisEndpoint) {
  const zeilen = [];
  for (let s = 0; s < ABFLUSS_BLOCK_MAX_SEITEN; s += 1) {
    const rows = await supabaseRequest(`${basisEndpoint}&limit=${ABFLUSS_SEITE}&offset=${s * ABFLUSS_SEITE}`);
    if (!Array.isArray(rows)) return null;
    zeilen.push(...rows);
    if (rows.length < ABFLUSS_SEITE) return zeilen;
  }
  console.error(`[drain-bilanz] in.()-Block am Seiten-Deckel (${ABFLUSS_BLOCK_MAX_SEITEN} x ${ABFLUSS_SEITE}) — Messgroesse gilt als nicht messbar.`);
  return null;
}
async function zaehleGateWuerdigerAbfluss(stunden = 24) {
  if (!v3StoreReady()) return null;
  const seit = new Date(Date.now() - Math.max(1, Number(stunden) || 24) * 3600e3).toISOString();
  try {
    // 1) ERSTABSCHLUESSE im Fenster — deterministisch paginiert (updated_at + id).
    //    Review-Befund 2026-09-01: ohne den ko_version-Filter zaehlte jede
    //    updated_at-BERUEHRUNG einer complete-Zeile (Aktualisierungen alter
    //    Vorgaenge, Wiederaufnahmen ohne neues Dokument) als frischer Abfluss —
    //    strukturell rechts inflationiert, falsches Gruen konstruierbar.
    //    ko_version=1 = Erstverstehen (Updates schreiben immer >= 2); das ist
    //    eine bewusste UNTERGRENZE des Abflusses (Update-Arbeit zaehlt nicht),
    //    waehrend die Ankunft in Dokumenten zaehlt (Obergrenze je Vorgang,
    //    ~1,8 Dokumente je Abschluss) — beide Verzerrungen zeigen nach ROT,
    //    nie nach Gruen. Production-Probe 31.08.: 76 Erstabschluesse vs. 11
    //    Update-Beruehrungen in 24 h.
    const koIds = [];
    const maxSeiten = abflussMaxSeiten();
    let seiten = 0;
    for (; seiten < maxSeiten; seiten += 1) {
      const rows = await supabaseRequest(
        "/rest/v1/knowledge_objects?select=id&understanding_status=eq.complete&ko_version=eq.1"
        + `&updated_at=gte.${encodeURIComponent(seit)}`
        + `&order=updated_at.asc,id.asc&limit=${ABFLUSS_SEITE}&offset=${seiten * ABFLUSS_SEITE}`
      );
      if (!Array.isArray(rows)) return null;
      koIds.push(...rows.map((r) => r && r.id).filter(Boolean));
      if (rows.length < ABFLUSS_SEITE) break;
    }
    if (seiten >= maxSeiten) {
      console.error(`[drain-bilanz] Abfluss-Lese am Seiten-Deckel (${maxSeiten} x ${ABFLUSS_SEITE}) — Abfluss gilt als nicht messbar.`);
      return null;
    }
    if (!koIds.length) return { gatewuerdig: 0, nichtGatewuerdig: 0, unbewertet: 0, gesamt: 0 };
    // 2) Dokumentverknuepfungen der Erstabschluesse (blockweise, je Block
    //    vollstaendig seitenweise gelesen — s. ladeAbflussBlockSeitenweise).
    const docsJeKo = new Map(koIds.map((id) => [id, []]));
    const alleDocIds = new Set();
    for (let i = 0; i < koIds.length; i += 50) {
      const block = koIds.slice(i, i + 50);
      const rows = await ladeAbflussBlockSeitenweise(
        `/rest/v1/ko_document_links?select=knowledge_object_id,raw_document_id&knowledge_object_id=${inListe(block)}`
        + "&order=knowledge_object_id.asc,raw_document_id.asc"
      );
      if (rows === null) return null;
      for (const r of rows) {
        if (!r || !r.knowledge_object_id || !r.raw_document_id) continue;
        if (docsJeKo.has(r.knowledge_object_id)) docsJeKo.get(r.knowledge_object_id).push(r.raw_document_id);
        alleDocIds.add(r.raw_document_id);
      }
    }
    // 3) Gate-Entscheidungen dieser Dokumente (zeitunabhaengig: die Entscheidung
    //    eines Rueckstands-Vorgangs kann Wochen vor seinem Abschluss liegen).
    const wuerdigeDocs = new Set();
    const bewerteteDocs = new Set();
    const docListe = [...alleDocIds];
    for (let i = 0; i < docListe.length; i += 50) {
      const block = docListe.slice(i, i + 50);
      const rows = await ladeAbflussBlockSeitenweise(
        `/rest/v1/gate_shadow_events?select=raw_document_id,gate_decision&raw_document_id=${inListe(block)}`
        + "&order=raw_document_id.asc,id.asc"
      );
      if (rows === null) return null;
      for (const r of rows) {
        if (!r || !r.raw_document_id) continue;
        bewerteteDocs.add(r.raw_document_id);
        if (r.gate_decision === "verstehen" || r.gate_decision === "zurueckstellen") wuerdigeDocs.add(r.raw_document_id);
      }
    }
    // 4) Je Vorgang klassifizieren.
    let gatewuerdig = 0, nichtGatewuerdig = 0, unbewertet = 0;
    for (const [, docs] of docsJeKo) {
      if (docs.some((d) => wuerdigeDocs.has(d))) gatewuerdig += 1;
      else if (docs.some((d) => bewerteteDocs.has(d))) nichtGatewuerdig += 1;
      else unbewertet += 1;
    }
    return { gatewuerdig, nichtGatewuerdig, unbewertet, gesamt: koIds.length };
  } catch {
    return null;
  }
}

// Verarbeitbarer RUECKSTAND jetzt: pending ohne failed/failed-final/gate-geparkt —
// exakt die Menge, die die Verstehenslaeufe bedienen koennen (NULL-sicher wie die
// Auswahl selbst; gate-geparkt zaehlt GETRENNT ueber countGateGeparkt).
async function zaehlePendingVerarbeitbar() {
  if (!v3StoreReady()) return null;
  try {
    const rows = await supabaseRequest(
      "/rest/v1/knowledge_objects?select=count&status=eq.pending"
      + "&or=(understanding_status.is.null,understanding_status.not.in.(failed,failed-final,gate-geparkt))"
    );
    return Array.isArray(rows) && rows[0] ? (Number(rows[0].count) || 0) : null;
  } catch {
    return null;
  }
}

// ── BLOCKER-3-KORREKTUR: Rueckstandstrend mit Anfangswert, Endwert und Trend ────────
// Ein Trend braucht ZWEI Messpunkte. Die Trendzeile ist eine EIGENE
// helmut_store-Zeile nach dem belegten F-CAS-Muster der Cron-Fairness (eigene
// Zeile, ein Schreiber, Compare-and-Set ueber `data.rev`, CLAUDE.md §4.10;
// keine neue Tabelle, keine Migration). Der ERSTE Eintrag eines Tages gewinnt
// (deterministischer Tagesanker, kein Nachmittags-Drift); ohne gestrigen
// Vergleichswert bleibt der Trend ehrlich `unvollstaendig`.
// BEFUND 2 (Korrektursprint 2026-09-01): der Gesundheitsbericht ruft
// schreibeDrainTrendSchnappschuss NICHT mehr auf — jeder Berichtsaufruf (auch
// ?dryRun=1) haette sonst in helmut_store geschrieben und den Read-only-Vertrag
// des Berichts verletzt. Die Schreibfunktion bleibt als VORBEREITETER, derzeit
// NIRGENDS verdrahteter Schreiber bestehen (testgesichert:
// scripts/verstehen-drain-bilanz-test.js §7.4); ihre Verdrahtung ist eine
// spaetere, ausdruecklich zu genehmigende Production-Datenaenderung.
const DRAIN_TREND_STORE_SUFFIX = "verstehen-drain-trend";
const DRAIN_TREND_MAX_EINTRAEGE = 40;

function drainTrendRowId() {
  return `${supabaseStoreId}-${DRAIN_TREND_STORE_SUFFIX}`;
}

function normalisiereDrainTrendStand(roh) {
  const eintraege = (roh && Array.isArray(roh.eintraege) ? roh.eintraege : [])
    .filter((e) => e && typeof e.tag === "string" && Number.isFinite(Number(e.wert)) && typeof e.um === "string")
    .map((e) => ({ tag: e.tag, wert: Math.max(0, Math.floor(Number(e.wert))), um: e.um }));
  eintraege.sort((a, b) => a.tag.localeCompare(b.tag) || a.um.localeCompare(b.um));
  return { eintraege: eintraege.slice(-DRAIN_TREND_MAX_EINTRAEGE) };
}

async function leseDrainTrendZeile(deps = {}) {
  const request = deps.request || supabaseRequest;
  if (!useSupabase()) return { ok: false, stand: normalisiereDrainTrendStand({}), existiert: null, rev: null, fehler: "kein-supabase-backend" };
  try {
    const rows = await request(`/rest/v1/helmut_store?id=eq.${encodeURIComponent(drainTrendRowId())}&select=data`);
    const row = Array.isArray(rows) ? rows[0] : null;
    const roh = (row && row.data) || {};
    return { ok: true, stand: normalisiereDrainTrendStand(roh), existiert: Boolean(row), rev: revOf(roh) };
  } catch (error) {
    return { ok: false, stand: normalisiereDrainTrendStand({}), existiert: null, rev: null, fehler: String((error && error.message) || "unbekannt").slice(0, 200) };
  }
}

// Traegt den Tagesschnappschuss BEDINGT ein (CAS wie schreibeCronFairnessZeile).
// Existiert fuer den Tag bereits ein Eintrag, wird NICHTS geschrieben (erster
// Messwert des Tages gewinnt — `{ ok:true, uebersprungen:true }`). Ein Konflikt
// fuehrt zu Neu-Lesen und erneutem Versuch (max 3); ein Fehler wird gemeldet,
// nie verschluckt. ACHTUNG (Befund 2, 2026-09-01): diese Funktion hat BEWUSST
// KEINEN Aufrufer — der rein lesende Gesundheitsbericht darf sie nie rufen;
// eine Verdrahtung ist eine separat freizugebende Production-Datenaenderung.
async function schreibeDrainTrendSchnappschuss({ tag, wert, um, deps = {} } = {}) {
  const request = deps.request || supabaseRequest;
  if (!useSupabase()) return { ok: false, fehler: "kein-supabase-backend" };
  if (typeof tag !== "string" || !tag || !Number.isFinite(Number(wert))) return { ok: false, fehler: "ungueltiger-schnappschuss" };
  let letzterFehler = null;
  for (let versuch = 1; versuch <= 3; versuch += 1) {
    try {
      const aktuell = await leseDrainTrendZeile(deps);
      if (!aktuell.ok) return { ok: false, fehler: aktuell.fehler || "zustand-nicht-lesbar" };
      if (aktuell.stand.eintraege.some((e) => e.tag === tag)) return { ok: true, uebersprungen: true };
      const stand = normalisiereDrainTrendStand({
        eintraege: [...aktuell.stand.eintraege, { tag, wert: Math.max(0, Math.floor(Number(wert))), um: String(um || new Date().toISOString()) }]
      });
      const daten = { ...stand, rev: (aktuell.rev === null ? 0 : aktuell.rev) + 1 };
      const id = drainTrendRowId();
      if (!aktuell.existiert) {
        try {
          await request("/rest/v1/helmut_store", {
            method: "POST",
            headers: { Prefer: "return=minimal" },
            body: JSON.stringify({ id, data: daten })
          });
          return { ok: true, geschrieben: true };
        } catch (error) {
          if (/\b409\b|duplicate key/i.test(String((error && error.message) || ""))) { letzterFehler = "gleichzeitiger-schreibvorgang"; continue; }
          throw error;
        }
      }
      const bedingung = aktuell.rev === null ? "data-%3E%3Erev=is.null" : `data-%3E%3Erev=eq.${aktuell.rev}`;
      const zeilen = await request(
        `/rest/v1/helmut_store?id=eq.${encodeURIComponent(id)}&${bedingung}&select=id`,
        { method: "PATCH", headers: { Prefer: "return=representation" }, body: JSON.stringify({ data: daten }) }
      );
      if (Array.isArray(zeilen) && zeilen.length > 0) return { ok: true, geschrieben: true };
      letzterFehler = "gleichzeitiger-schreibvorgang";
    } catch (error) {
      letzterFehler = String((error && error.message) || "unbekannt").slice(0, 200);
      if (/\b4\d\d\b/.test(letzterFehler)) break;
    }
  }
  return { ok: false, fehler: letzterFehler || "unbekannt" };
}

// --- LLM-Kosten-/Token-Logging -------------------------------------------
// Preise in USD pro 1 Mio. Token (Schaetzwerte, per HELMUT_LLM_PRICE_JSON
// ueberschreibbar). Unbekanntes Modell -> estimatedCost = "unknown".
//
// KOSTENWAHRHEIT (Punkt 17): Diese Zahlen sind SCHAETZWERTE ohne belegte
// Herkunft — sie stehen seit ihrer Einfuehrung unveraendert im Code, ohne
// Preisquelle und ohne Stand. Sie werden hier BEWUSST NICHT geaendert (eine
// Preisrecherche ist nicht Teil dieses Sprints, und ein aus dem Gedaechtnis
// gesetzter Preis waere schlechter als ein deklarierter Schaetzwert). Stattdessen
// traegt jede daraus berechnete Kostenangabe ab sofort ihre Herkunft mit:
// llmPriceProvenance() sagt, worauf der Betrag beruht. Solange die Herkunft
// 'unbelegt-schaetzwert' ist, darf der Betrag im Betriebsbericht nur als
// BERECHNET, nicht als tatsaechliche Providerkosten erscheinen.
//
// Belegt wird die Preisbasis vom Betreiber, nicht vom Code:
//   HELMUT_LLM_PRICE_JSON    = {"gpt-5-mini":{"in":0.25,"out":2.0}}  (Preise)
//   HELMUT_LLM_PRICE_SOURCE  = "OpenAI-Rechnung 2026-07, Pos. 3"     (Herkunft)
//   HELMUT_LLM_PRICE_ASOF    = "2026-07-01"                          (Stand)
// Erst wenn HELMUT_LLM_PRICE_SOURCE gesetzt ist, gilt die Preisbasis als belegt.
const LLM_PRICE_DEFAULTS = Object.freeze({
  "gpt-5-mini": { in: 0.25, out: 2.0 },
  "gpt-5.5": { in: 1.25, out: 10.0 },
  "gpt-4.1": { in: 2.0, out: 8.0 },
  "gpt-4o-mini": { in: 0.15, out: 0.6 }
});

function llmPriceOverride() {
  try {
    const raw = process.env.HELMUT_LLM_PRICE_JSON;
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : null;
  } catch (_) {
    return null; // ungueltiges JSON ignorieren, Defaults nutzen
  }
}

function llmPriceTable() {
  const override = llmPriceOverride();
  return override ? { ...LLM_PRICE_DEFAULTS, ...override } : { ...LLM_PRICE_DEFAULTS };
}

// Herkunft der Preisbasis — begleitet JEDE Kostenangabe im Betriebsbericht.
// waehrung ist USD, weil die Preistabelle in USD/1 Mio. Token gefuehrt wird;
// es findet KEINE Umrechnung statt (ein ungepruefter Wechselkurs waere eine
// zweite erfundene Groesse).
function llmPriceProvenance() {
  const override = llmPriceOverride();
  const quelle = String(process.env.HELMUT_LLM_PRICE_SOURCE || "").trim();
  const stand = String(process.env.HELMUT_LLM_PRICE_ASOF || "").trim();
  const belegt = Boolean(quelle);
  return {
    waehrung: "USD",
    herkunft: belegt ? "belegt" : "unbelegt-schaetzwert",
    quelle: quelle || null,
    stand: stand || null,
    ueberschrieben: Boolean(override),
    modelle: Object.keys(llmPriceTable()).sort(),
    hinweis: belegt
      ? "Preisbasis ist vom Betreiber belegt (HELMUT_LLM_PRICE_SOURCE)."
      : "Preisbasis ist ein unbelegter Schaetzwert im Code. Betraege sind BERECHNET, nicht vom Provider gemeldet — als Groessenordnung belastbar, nicht als Rechnungsbetrag."
  };
}

function numOrNull(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

function estimateLlmCost(model, promptTokens, completionTokens) {
  const price = llmPriceTable()[model];
  if (!price || promptTokens == null || completionTokens == null) return null;
  const cost = (promptTokens / 1e6) * price.in + (completionTokens / 1e6) * price.out;
  return Math.round(cost * 1e6) / 1e6; // auf 6 Nachkommastellen (USD)
}

// Baut EINEN Kostenlog-Eintrag aus einem Call-Meta-Objekt — REINE Funktion (kein I/O,
// kein Zufall/Zeit ausser explizit), damit sie offline testbar ist und recordLlmUsage
// nur noch persistiert. Fehlt der usage-Block, werden Token/Kosten als "unknown"
// protokolliert (nie stiller Verlust).
//
// SaaS-Fundament (mandantenfaehig, KEINE tenant-spezifische Sonderlogik): der Eintrag
// traegt zusaetzlich tenantId/profileId/runId/pipelineStep. Alle optional -> fehlt eines,
// wird es null (bzw. pipelineStep faellt auf den callType zurueck, der de facto der
// Pipeline-Schritt ist). Bestehende Felder bleiben UNVERAENDERT (rueckwaertskompatibel).
//
// WICHTIG (Kostentrennung): dieser Eintrag ist INTERN. estimatedCost/Token duerfen NIE
// in den Helmut-Tab / CurrentHelmutState fuer Abgeordnete gelangen — llmUsage liegt im
// separaten Auth-Store und wird ausschliesslich von Admin-/Kosten-Reports gelesen.
function buildLlmUsageRecord(entry = {}, opts = {}) {
  const usage = entry.usage || {};
  const promptTokens = numOrNull(usage.input_tokens ?? usage.prompt_tokens);
  const completionTokens = numOrNull(usage.output_tokens ?? usage.completion_tokens);
  const totalFromParts = promptTokens != null && completionTokens != null ? promptTokens + completionTokens : null;
  const totalTokens = numOrNull(usage.total_tokens) ?? totalFromParts;
  // OP-25-Befund 2026-08-07 (`kosten-nicht-bepreisbar`): Skip-Marker (Budget-Gate u. ä.)
  // sind KEINE Modellaufrufe — es gab keinen Provider-Request, ihre Kostenfreiheit ist
  // technisch belegt. Früher trugen sie model/estimatedCost "unknown" und waren vom
  // unbepreisbaren ECHTEN Aufruf nicht unterscheidbar (der strenge OP-25-Kostenvertrag
  // blockiert dann zu Recht). Kostenfrei gilt AUSSCHLIESSLICH, wenn ALLE Invarianten
  // eines Nicht-Aufrufs zusammen erfüllt sind (Review-Härtung PR #232, Befund 1):
  //   1. ausdrückliche Kennzeichnung durch den Aufrufer (`keinAufruf: true`),
  //   2. `success === false` (ein "erfolgreicher Nicht-Aufruf" ist ein Widerspruch),
  //   3. `callType` ist eindeutig ein Skip-Marker (Präfix `skipped-`),
  //   4. kein echtes Modell (nur fehlend, `none` oder der kanonische Marker),
  //   5. keinerlei Token-Angaben.
  // JEDER Widerspruch fällt auf den ehrlichen "unknown"-Pfad zurück (kein Audit-Feld,
  // nie still 0). Ein unbekanntes Modell wird weiterhin NIE still mit 0 bewertet.
  const keinAufruf = entry.keinAufruf === true
    && entry.success === false
    && typeof entry.callType === "string" && entry.callType.startsWith("skipped-")
    && (!entry.model || entry.model === "none" || entry.model === "kein-aufruf")
    && promptTokens == null && completionTokens == null && numOrNull(usage.total_tokens) == null;
  // ── EIN NICHT-AUFRUF IST NIE EIN ERFOLG (Haertung 2026-09-01) ─────────────
  // `success` wurde unten als `entry.success !== false` abgeleitet: ein fehlendes
  // Feld bedeutete also ERFOLG. Ein Aufrufer, der einen Skip meldet und dabei
  // `success: false` vergisst, erzeugte damit einen scheinbar erfolgreichen
  // Modellaufruf — genau das, was ein Budget-/Konfigurationsriegel nie tun darf
  // (CLAUDE.md §4.4, kein falsches Gruen). Der Skip-Marker im `callType` ist das
  // ehrlichste verfuegbare Signal: er wird vom Aufrufer ausdruecklich gesetzt.
  // Deshalb erzwingt er hier `success:false` — unabhaengig davon, was gemeldet
  // wurde. Die Kostenaggregation zaehlt `skipped-*` ohnehin nicht als billable;
  // diese Regel schuetzt zusaetzlich jede Erfolgs-/Fehlerstatistik.
  const istSkipMarker = typeof entry.callType === "string" && entry.callType.startsWith("skipped-");
  const erfolg = entry.success !== false && !istSkipMarker && entry.keinAufruf !== true;
  const model = entry.model || (keinAufruf ? "kein-aufruf" : "unknown");
  const estimatedCost = keinAufruf ? 0 : estimateLlmCost(model, promptTokens, completionTokens);
  const callType = entry.callType || "unknown";
  const id = opts.id || `llm-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  const createdAt = opts.createdAt || new Date().toISOString();
  const trim = (v) => (v == null ? null : String(v).slice(0, 120));
  return {
    id,
    createdAt,
    // SaaS-Kontext (alle optional, mandantenfaehig):
    tenantId: trim(entry.tenantId) || null,
    profileId: trim(entry.profileId ?? entry.politicianId ?? entry.userId) || null,
    runId: trim(entry.runId) || null,
    pipelineStep: trim(entry.pipelineStep ?? callType) || "unknown",
    // Quellenarchitektur-Zuordnung (Sprint 7, alle optional, rueckwaertskompatibel):
    // erlauben die Kostenzuordnung je Abrufweg/Paket/Vorgang. Fehlt eines -> null
    // (dann ist die Kosten-Zuordnung fuer diesen Eintrag "nicht zuordenbar" statt erfunden).
    // vorgangId reicht office.js bereits durch (wurde bisher verworfen).
    sourceId: trim(entry.sourceId ?? entry.legacySourceId ?? entry.retrievalPathId) || null,
    packageId: trim(entry.packageId) || null,
    vorgangId: trim(entry.vorgangId) || null,
    knowledgeObjectId: trim(entry.knowledgeObjectId ?? entry.koId) || null,
    // Bestehende Felder (unveraendert):
    politicianId: entry.politicianId || null,
    userId: entry.userId || entry.politicianId || null,
    model,
    callType,
    promptTokens: promptTokens ?? (keinAufruf ? 0 : "unknown"),
    completionTokens: completionTokens ?? (keinAufruf ? 0 : "unknown"),
    totalTokens: totalTokens ?? (keinAufruf ? 0 : "unknown"),
    estimatedCost: estimatedCost ?? "unknown",
    durationMs: numOrNull(entry.durationMs) ?? "unknown",
    success: erfolg,
    error: entry.error ? String(entry.error).slice(0, 300) : null,
    // Nur bei ausdruecklich gekennzeichneten Nicht-Aufrufen persistiert (Audit-Spur,
    // warum estimatedCost 0 belegt ist); bei echten Aufrufen fehlt das Feld.
    ...(keinAufruf ? { keinAufruf: true } : {})
  };
}

// --- W-2 fuer `llmUsage`: relationale Ablage (Sprint 02.09.) ----------------
// BEWIESENER BEFUND (Sicherheitsrahmen §17.2): der Blob-Schreibweg unten ist ein
// UNBEDINGTER Lese-Aendere-Schreibe-Zyklus ueber den GESAMTEN Auth-Store. Zwei
// nebenlaeufige KI-Aufrufe ueberschreiben sich lautlos ihren Eintrag
// (last-write-wins); der Tageszaehler zaehlt dadurch zu WENIG. Fuer `processRuns`
// wurde genau das 2026-07-27 relational geloest — hier folgt `llmUsage` demselben
// bereits bewaehrten Muster.
//
// ATOMAR statt Lese-Aendere-Schreibe: EIN Insert je Eintrag. Die Blob-Groesse
// spielt keine Rolle mehr, und zwei nebenlaeufige Schreiber koennen sich nicht
// mehr gegenseitig ueberschreiben.
//
// BEWUSST KEIN UPSERT (Unterschied zu `recordProcessRun`, adversarialer Review
// 02.09.): dort ist `(run_id, process)` ein ABSICHTLICHER Idempotenz-Anker —
// derselbe Lauf schreibt Start und Abschluss in dieselbe Zeile. Ein
// Nutzungseintrag ist dagegen ein EINMALIGES Ereignis; zwei Eintraege mit
// derselben `id` waeren kein zu verschmelzender Wiederholungsschreibvorgang,
// sondern eine Kennungskollision. `resolution=merge-duplicates` haette genau
// den stillen Verlust, den diese Umstellung beseitigen soll, aus dem Blob in
// die Tabelle verlegt. Ein reiner Insert macht die Kollision stattdessen als
// Fehler sichtbar (PostgREST 409) — und der wird unten ausgewiesen, nicht
// verschluckt.
async function insertLlmUsageRelational(row, deps = {}) {
  const request = deps.request || supabaseRequest;
  await request("/rest/v1/llm_usage", {
    method: "POST",
    headers: { Prefer: "return=minimal" },
    body: JSON.stringify(row)
  });
  return { inserted: true };
}

// Lesepfad des relationalen Ziels — GEGENPROBE, nicht Produktionslesepfad.
// Phase 3 (Lesepfad bevorzugt relational) ist ausdruecklich NICHT Teil dieses
// Sprints: alle Produktionsleser lesen weiter aus dem Blob. Ohne diese Funktion
// waere der Dual-Write aber gar nicht gegenpruefbar — man koennte nur behaupten,
// dass geschrieben wurde. Sie wird von `scripts/llm-usage-relational-test.js`
// und von Betreiber-Diagnosen benutzt.
async function leseLlmUsageRelational({ politicianId = null, seitIso = null, limit = 200 } = {}, deps = {}) {
  const request = deps.request || supabaseRequest;
  const teile = ["select=*", "order=created_at.desc", `limit=${Math.max(1, Math.min(1000, Math.floor(limit)))}`];
  if (politicianId) {
    // PostgREST-Filter sind eine Sprache: Komma und Klammer trennen dort
    // Ausdruecke. Eine Kennung, die solche Zeichen traegt, wuerde den Filter
    // umbauen statt ihn zu fuellen — deshalb hier eine Zeichenvorratspruefung
    // statt blossem Kodieren. Mandatskennungen sind Slugs (a-z, 0-9, Bindestrich,
    // Unterstrich); alles andere ist ein Abbruch, kein stilles Weglassen.
    const kennung = String(politicianId);
    if (!/^[A-Za-z0-9_-]{1,120}$/.test(kennung)) {
      throw new Error("leseLlmUsageRelational: politicianId ist keine gueltige Mandatskennung");
    }
    teile.push(`or=(politician_id.eq.${kennung},user_id.eq.${kennung})`);
  }
  if (seitIso) teile.push(`created_at=gte.${encodeURIComponent(seitIso)}`);
  const rows = await request(`/rest/v1/llm_usage?${teile.join("&")}`);
  const liste = Array.isArray(rows) ? rows : [];
  return liste.map((z) => relationalRowToLlmUsage(z));
}

// Schreibt genau EINEN Log-Eintrag pro LLM-Call.
// Loggen darf die App nie zum Absturz bringen -> alles in try/catch.
//
// UEBERGANGSPHASE 2 (Dual-Write, freigabepflichtig): ist BEIDES gegeben — Flag
// `HELMUT_LLM_USAGE_RELATIONAL` UND die angewendete Migration
// `20260902121500_llm_usage_relational.sql` — wird der Eintrag ZUSAETZLICH
// relational geschrieben. Der BLOB-PFAD BLEIBT DABEI UNVERAENDERT: alle heutigen
// Leser (`getLlmUsage`, `getLlmUsageToday`, `getRunCostReport`, Admin-Reports,
// `op25-nachweis`, Kontoloeschung) finden ihre Daten weiterhin genau dort.
// Ohne Flag ist der relationale Zweig ein reiner No-Op. Der Blobspiegel wird
// unabhaengig davon bedingt und bei bestaetigtem Konflikt auf frischem Stand geschrieben.
//
// EHRLICHKEIT STATT STILLEM VERSCHLUCKEN: der Rueckgabewert traegt jetzt
// zusaetzlich `_ablage` mit dem tatsaechlichen Ergebnis beider Wege. Der
// Eintrag selbst bleibt in Form und Feldern unveraendert — bestehende Aufrufer
// und Tests, die den Record weiterverwenden, sehen keinen Unterschied.
async function recordLlmUsage(entry = {}, deps = {}) {
  let record = null;
  try {
    record = buildLlmUsageRecord(entry);
  } catch (_) {
    return null; // Logging-Fehler duerfen den LLM-Pfad nicht beeintraechtigen
  }

  // Gate exakt wie beim bewaehrten Muster `recordProcessRun`: Flag UND ein
  // tatsaechlich benutzbares relationales Ziel (`v3StoreReady()` prueft Flag,
  // SUPABASE_URL und Service-Role-Key). `useSupabase()` allein haette gereicht,
  // um den Zweig zu betreten, ohne dass das Ziel bereit ist.
  const relationalAktiv = deps.relationalAktiv != null
    ? Boolean(deps.relationalAktiv)
    : (llmUsageRelationalEnabled(deps.env || process.env) && v3StoreReady());

  let relationalGespeichert = false;
  let relationalFehler = null;
  if (relationalAktiv) {
    try {
      const insert = deps.insertRelational || insertLlmUsageRelational;
      await insert(llmUsageToRelationalRow(record));
      relationalGespeichert = true;
    } catch (error) {
      // Der relationale Weg darf den KI-Pfad ebenso wenig brechen wie der Blob.
      // Er wird aber NICHT verschluckt. Alle bisherigen Aufrufer von
      // `recordLlmUsage` verwerfen den Rueckgabewert (`.catch(() => {})`) — ein
      // Ergebnisobjekt allein waere deshalb unsichtbar. Genau das war Befund W-2
      // beim Prozesslauf. Also zusaetzlich eine strukturierte Logzeile, wie
      // `meldeProcessRunTelemetrieFehler` sie schreibt.
      let meldung = String((error && error.message) || error || "unbekannt");
      try { meldung = require("./redact").redactSensitive(meldung); } catch (_) { /* nie verdecken */ }
      relationalFehler = meldung.slice(0, 200);
      try {
        console.error(`[llmUsage] TELEMETRIEFEHLER ${JSON.stringify({
          id: record.id, callType: record.callType, backend: "relational", fehler: relationalFehler
        })}`);
      } catch (_) { /* Logging darf nichts verdecken */ }
    }
  }

  let blobGespeichert = false;
  try {
    await mutateAuthStore((store) => {
      store.llmUsage = [record, ...(store.llmUsage || [])];
    });
    blobGespeichert = true;
  } catch (_) {
    // unveraendert: ein Blob-Fehler beendet den LLM-Pfad nicht.
  }

  if (!blobGespeichert && !relationalGespeichert) return null;
  return Object.assign({}, record, {
    _ablage: {
      relationalAktiv,
      relational: relationalGespeichert,
      blob: blobGespeichert,
      fehler: relationalFehler
    }
  });
}

async function getLlmUsage(politicianId = null, limit = 200) {
  const store = await readAuthStore();
  const all = Array.isArray(store.llmUsage) ? store.llmUsage : [];
  const filtered = politicianId ? all.filter((e) => e.politicianId === politicianId || e.userId === politicianId) : all;
  return filtered.slice(0, Math.max(0, limit));
}

// --- LLM-Budget / Kostenkontrolle -------------------------------------------
// Fundament fuer Datenmotor V2: leitet aus dem VORHANDENEN llmUsage-Log eine
// Tages-Aggregation ab und stellt ein Pre-Call-Gate bereit. Rein additiv —
// solange niemand canSpendLlm() aufruft, aendert sich am Verhalten nichts.

// Grenzwerte kommen aus Env-Variablen.
// AUDIT-FIX 2026-07 (fail-closed), verschaerft im Budget-Rollout: es gibt KEINEN
// Infinity-Pfad mehr. Frueher fiel ein ungueltiger Wert (Tippfehler "2Oo",
// Einheiten) UND ein fehlender/geloeschter Wert still auf "kein Limit" zurueck —
// ein Vertipper ODER das versehentliche Loeschen der Vercel-Variable hob den
// Kostendeckel unbemerkt auf. Jetzt gilt: NUR eine positive ganze Zahl setzt das
// Limit; alles andere (fehlend, leer, 0, negativ, unparsebar) aktiviert das
// konservative Schutzlimit (einmalige Warnung im Log). Wer bewusst mehr will,
// setzt explizit eine hohe Zahl.
const LLM_LIMIT_FALLBACK = 50;
let warnedLlmLimitFallback = false;
function llmDailyCallLimit() {
  const rawStr = String(process.env.HELMUT_MAX_LLM_CALLS_PER_DAY ?? "").trim();
  const raw = Number(rawStr);
  if (rawStr !== "" && Number.isFinite(raw) && raw > 0) return Math.floor(raw);
  if (!warnedLlmLimitFallback) {
    warnedLlmLimitFallback = true;
    console.warn(`[llm-budget] HELMUT_MAX_LLM_CALLS_PER_DAY ist ${rawStr === "" ? "nicht gesetzt" : `ungueltig ("${rawStr.slice(0, 20)}")`} — Schutzlimit ${LLM_LIMIT_FALLBACK} Calls/Tag aktiv (fail-closed statt unbegrenzt).`);
  }
  return LLM_LIMIT_FALLBACK;
}

// Zaehlt dieser Eintrag NICHT gegen das Tagesbudget?
//   - "skipped-*": es fand gar kein Provideraufruf statt.
//   - Diagnosepfade: der Aufruf fand statt, zieht aber bewusst keine
//     Reservierung (cost-model.NICHT_RESERVIERENDE_CALLTYPES).
// Bewusst hier lokal und ohne harte Modulabhaengigkeit, damit ein Ladefehler des
// Kostenmodells das Budget-Gate niemals ausfallen laesst (fail-safe).
function isNonBudgetCallType(callType) {
  const ct = String(callType || "");
  if (ct.startsWith("skipped")) return true;
  try { return require("./cost-model").istNichtReservierend(ct); }
  catch (_) { return false; }
}

// Kalendertag (UTC) eines ISO-Zeitstempels, z. B. "2026-07-01".
function dayKey(iso) {
  const s = String(iso || "");
  return s.length >= 10 ? s.slice(0, 10) : "";
}

// Aggregiert die heutigen (bzw. fuer referenceIso angegebenen) LLM-Calls eines
// Mandats: Anzahl, davon erfolgreich, geschaetzte Kosten. referenceIso ist
// injizierbar, damit Tests deterministisch ohne Systemuhr laufen koennen.
async function getLlmUsageToday(politicianId = null, referenceIso = null) {
  const today = dayKey(referenceIso || new Date().toISOString());
  const store = await readAuthStore();
  const all = Array.isArray(store.llmUsage) ? store.llmUsage : [];
  const scoped = politicianId
    ? all.filter((e) => e.politicianId === politicianId || e.userId === politicianId)
    : all;
  const todays = scoped.filter((e) => dayKey(e.createdAt) === today);
  // "skipped-*"-Eintraege sind reine Info (kein echter LLM-Call) und zaehlen
  // NICHT gegen das Budget — sonst wuerde ein Skip das Budget weiter belasten.
  // Ebenso ausgenommen (Punkt-17-Review): Diagnosepfade, die per Konstruktion
  // KEINE Reservierung ziehen. Sie duerfen keinen Kopfraum verbrauchen, den sie
  // nie reserviert haben — sonst verweigert das Vorab-Gate echte Fachaufrufe
  // wegen einer Diagnose. Ihre KOSTEN zaehlen weiterhin voll (kostenwahrheit).
  const billable = todays.filter((e) => !isNonBudgetCallType(e.callType));
  const cost = billable.reduce((sum, e) => sum + (typeof e.estimatedCost === "number" ? e.estimatedCost : 0), 0);
  return {
    day: today,
    calls: billable.length,
    successfulCalls: billable.filter((e) => e.success !== false).length,
    estimatedCostUsd: Math.round(cost * 1e6) / 1e6
  };
}

// Kleiner Flag-Parser (1/true/on/yes = an). Lokal gehalten, damit storage.js
// keine zusaetzliche Abhaengigkeit bekommt.
function isFlagOn(value) {
  return ["1", "true", "on", "yes"].includes(String(value || "").trim().toLowerCase());
}

// V3-Vorbereitung (C1), Default AUS: Soll der Budget-Check im FEHLERFALL
// fail-CLOSED sein (KI-Call verweigern) statt fail-OPEN? Standard bleibt
// fail-open, damit ein Storage-Problem die bestehende App nicht lahmlegt. Erst
// wenn V3 die geteilten, teuren Understanding-Calls fahrt, wird per Flag scharf
// geschaltet (dann kostet ein Storage-Fehler lieber ein uebersprungenes Briefing
// als eine unkontrollierte KI-Rechnung).
function llmBudgetFailClosed() {
  return isFlagOn(process.env.HELMUT_LLM_BUDGET_FAIL_CLOSED);
}

// Budget-Ergebnis, wenn die Nutzungsabfrage SELBST fehlschlaegt.
// Flag AUS -> allowed:true  (fail-open, bisheriges Verhalten, unveraendert).
// Flag AN  -> allowed:false (fail-closed).
function llmBudgetFailResult(limit) {
  const failClosed = llmBudgetFailClosed();
  return {
    allowed: !failClosed,
    used: null,
    limit: Number.isFinite(limit) ? limit : null,
    remaining: null,
    reason: failClosed ? "budget-check-failed-closed" : "budget-check-failed-open"
  };
}

// Pre-Call-Gate: Darf fuer dieses Mandat heute noch ein LLM-Call laufen?
// Gibt IMMER ein Objekt zurueck (nie throw) — der Aufrufer entscheidet, ob er
// bei allowed=false auf den Regelmotor zurueckfaellt. Fehlerfall: siehe
// llmBudgetFailResult (Default fail-OPEN, per Flag HELMUT_LLM_BUDGET_FAIL_CLOSED
// fail-CLOSED). Das Standardverhalten ist identisch zu vorher.
async function canSpendLlm(politicianId = null, referenceIso = null) {
  const limit = llmDailyCallLimit();
  try {
    const usage = await getLlmUsageToday(politicianId, referenceIso);
    const allowed = usage.calls < limit;
    return {
      allowed,
      used: usage.calls,
      limit: Number.isFinite(limit) ? limit : null,
      remaining: Number.isFinite(limit) ? Math.max(0, limit - usage.calls) : null,
      reason: allowed ? null : "daily-llm-budget-reached"
    };
  } catch (_) {
    return llmBudgetFailResult(limit);
  }
}

// ── REIN LESENDER Blick auf den MASSGEBLICHEN atomaren Tageszaehler ──────────────
// (Befund 3, Korrektursprint 2026-09-01.) canSpendLlm liest das llmUsage-Log im
// Auth-Store — ein VERLUSTBEHAFTETES Protokoll (dokumentiert ~16 % Verlust unter
// Last), waehrend die Budgetwahrheit allein `llm_budget_counters` ist (UTC-Tag,
// Scope 'global'; jede Reservierung bucht dort atomar via helmut_reserve_llm_call).
// Eine Vorab-Budgetentscheidung auf dem Log sieht zu wenig Verbrauch und blockiert
// zu spaet. Diese Funktion liest den Zaehler mit EINEM SELECT — keine Reservierung,
// kein Schreibzugriff, kein Modellaufruf. Vertrag:
//   * fehlende Tageszeile  => used 0 (heute wurde noch nichts reserviert — echte 0)
//   * unlesbarer Zaehler   => { ok:false, fehler } — der Aufrufer blockiert
//     geschlossen (nie fail-open auf das Log zurueckfallen)
//   * limit = wirksamer Tagesdeckel (HELMUT_MAX_LLM_CALLS_PER_DAY, sonst
//     Schutzlimit LLM_LIMIT_FALLBACK) — dieselbe Groesse wie am Choke-Point.
async function leseLlmTageszaehler(referenceIso = null, deps = {}) {
  const request = deps.request || supabaseRequest;
  const limitRoh = llmDailyCallLimit();
  const limit = Number.isFinite(limitRoh) ? limitRoh : null;
  const basis = { used: null, limit, remaining: null };
  if (!useSupabase()) return { ok: false, fehler: "kein-supabase-backend", ...basis };
  const tag = dayKey(referenceIso || new Date().toISOString());
  if (!tag) return { ok: false, fehler: "ungueltiger-stichtag", ...basis };
  try {
    const rows = await request(
      `/rest/v1/llm_budget_counters?day=eq.${encodeURIComponent(tag)}&scope=eq.global&select=used&limit=2`
    );
    if (!Array.isArray(rows)) return { ok: false, fehler: "antwort-keine-liste", ...basis };
    if (rows.length > 1) return { ok: false, fehler: `mehrdeutiger-zaehler:${rows.length}`, ...basis };
    const used = rows.length === 0 ? 0 : Number(rows[0] && rows[0].used);
    if (!Number.isFinite(used) || used < 0) return { ok: false, fehler: "zaehler-unlesbar", ...basis };
    return {
      ok: true, tag, used, limit,
      remaining: limit === null ? null : Math.max(0, limit - used)
    };
  } catch (error) {
    return { ok: false, fehler: String((error && error.message) || "unbekannt").slice(0, 200), ...basis };
  }
}

// Vollstaendige, ehrliche Tages-Budget-Sicht fuer den Admin (Phase 8).
// WICHTIG — Zeitzone: Die Tagesgrenze ist der UTC-KALENDERTAG (dayKey), exakt das
// Fenster, das auch das Budget-Gate (canSpendLlm/reserveLlmCall) nutzt. Eine
// Berliner Tagesgrenze in der ANZEIGE wuerde ueber das Gate luegen (das Gate setzt
// um 00:00 UTC zurueck = 02:00 Berliner Sommerzeit / 01:00 Winterzeit). Die
// bestehende "Heute"-Statistik (getAdminStatsCosts days=1) misst dagegen ein
// ROLLIERENDES 24h-Fenster — fuer Kostentrends ok, fuer den Budgetstand falsch.
// Skips (callType skipped-*) und Fehler (success=false) werden GETRENNT
// ausgewiesen: nur echte Calls zaehlen gegen das Budget, aber der Admin soll
// sehen, wie oft Pfade uebersprungen wurden und wie oft Calls scheiterten.
// Aggregiert ueber das VOLLE Log (Cap 5000 Eintraege beim Schreiben) — kein
// 500er-Anzeige-Cap wie frueher.
async function getLlmUsageBreakdownToday(referenceIso = null, deps = {}) {
  const readAuth = deps.readAuth || readAuthStore;
  const today = dayKey(referenceIso || new Date().toISOString());
  const store = await readAuth();
  const all = Array.isArray(store.llmUsage) ? store.llmUsage : [];
  const todays = all.filter((e) => dayKey(e.createdAt) === today);
  // Gleiche Abgrenzung wie im Gate (isNonBudgetCallType): was keine Reservierung
  // zieht, verbraucht auch keinen angezeigten Kopfraum. Die KOSTEN dieser Aufrufe
  // bleiben im kostenwahrheit-Block unten vollstaendig enthalten.
  const isSkip = (e) => isNonBudgetCallType(e.callType);
  const billable = todays.filter((e) => !isSkip(e));
  const skips = todays.filter(isSkip);
  const errors = billable.filter((e) => e.success === false);
  const costOf = (list) => Math.round(list.reduce((s, e) => s + (typeof e.estimatedCost === "number" ? e.estimatedCost : 0), 0) * 1e6) / 1e6;

  const byCallType = {};
  for (const e of billable) {
    const ct = String(e.callType || "unbekannt");
    if (!byCallType[ct]) byCallType[ct] = { calls: 0, errors: 0, estimatedCostUsd: 0 };
    byCallType[ct].calls += 1;
    if (e.success === false) byCallType[ct].errors += 1;
    if (typeof e.estimatedCost === "number") byCallType[ct].estimatedCostUsd += e.estimatedCost;
  }
  for (const v of Object.values(byCallType)) v.estimatedCostUsd = Math.round(v.estimatedCostUsd * 1e6) / 1e6;

  const byTenant = {};
  for (const e of billable) {
    const tid = e.politicianId || e.userId || "(mandantenlos)";
    if (!byTenant[tid]) byTenant[tid] = { calls: 0, estimatedCostUsd: 0 };
    byTenant[tid].calls += 1;
    if (typeof e.estimatedCost === "number") byTenant[tid].estimatedCostUsd += e.estimatedCost;
  }
  for (const v of Object.values(byTenant)) v.estimatedCostUsd = Math.round(v.estimatedCostUsd * 1e6) / 1e6;

  const skipsByReason = {};
  for (const e of skips) {
    const reason = String(e.error || "unbekannt");
    skipsByReason[reason] = (skipsByReason[reason] || 0) + 1;
  }

  const limit = llmDailyCallLimit();
  // KOSTENWAHRHEIT (Punkt 17): die Altsummen oben (costOf/byCallType/byTenant)
  // rechnen einen unbekannten Betrag als 0 — sie bleiben unveraendert, damit
  // bestehende Anzeigen nicht brechen, sind aber NICHT die ehrliche Wahrheit.
  // Der Block `kostenwahrheit` trennt bekannt / unbekannt / kein Provideraufruf
  // und ist die Grundlage jeder neuen Anzeige. Fail-safe: ein Fehler in der
  // Aggregation darf die bestehende Budgetanzeige nie ausfallen lassen.
  let kostenwahrheit = null;
  try {
    const costModel = require("./cost-model");
    const agg = costModel.aggregiere(todays);
    kostenwahrheit = {
      ...agg,
      preisbasis: llmPriceProvenance(),
      budgetstatus: costModel.budgetStatus(billable.length, Number.isFinite(limit) ? limit : null),
      klartext: costModel.kostensatz(agg.gesamt)
    };
  } catch (_) { kostenwahrheit = null; }

  return {
    day: today,
    timezone: "UTC-Kalendertag (identisch zum Budget-Gate; Reset 00:00 UTC = 02:00 Berlin Sommer / 01:00 Winter)",
    limit: Number.isFinite(limit) ? limit : null,
    reserveUnderstanding: llmUnderstandingReserve() || 0,
    failClosed: llmBudgetFailClosed(),
    calls: billable.length,
    errors: errors.length,
    skips: skips.length,
    remaining: Number.isFinite(limit) ? Math.max(0, limit - billable.length) : null,
    estimatedCostUsd: costOf(billable),
    byCallType,
    byTenant,
    skipsByReason,
    kostenwahrheit
  };
}

// Kostenbericht je LAUF (Punkt 17). Bindeglied zwischen den drei bereits
// vorhandenen Telemetriequellen — es entsteht KEINE neue Tabelle:
//   processRuns            (Auth-Store) Laufkennung, Start/Ende, Dauer, Menge
//   llmUsage               (Auth-Store) Aufrufe, Tokens, berechnete Kosten
//   source_crawl_telemetry (Supabase)   Abrufwege, Dokumente je Lauf
//
// Zwei Zuordnungswege, in dieser Reihenfolge:
//   'laufkennung' — der Nutzungseintrag traegt runId. Exakt, ab sofort der
//                   Regelfall (die Laufkennung wird jetzt durchgereicht).
//   'zeitfenster' — Rekonstruktion ueber startedAt..finishedAt des Laufs. Noetig
//                   fuer den Altbestand (dort ist runId durchgehend null).
// Der Weg wird je Lauf ausgewiesen, damit eine rekonstruierte Zahl nie wie eine
// gemessene aussieht. Aufrufe ausserhalb jedes Laufzeitfensters bleiben
// ausdruecklich unzugeordnet, statt einem Lauf zugeschlagen zu werden.
// opts.readAuth: injizierbarer Store-Leser (nur fuer Tests — offline, ohne DB).
async function getRunCostReport(opts = {}) {
  const costModel = require("./cost-model");
  const limitRuns = Number.isFinite(Number(opts.limit)) ? Math.max(1, Number(opts.limit)) : 20;
  const readAuth = typeof opts.readAuth === "function" ? opts.readAuth : readAuthStore;
  const store = await readAuth();
  const usage = Array.isArray(store.llmUsage) ? store.llmUsage : [];
  // W-2: Laeufe ueber den Dual-Read (relational bevorzugt, Blob als Altbestand) —
  // sonst fehlen im Kostenreport genau die Laeufe, die der Blob per
  // Last-Write-Wins verloren hat. Injizierte readAuth (Tests) wird durchgereicht.
  const runs = await listProcessRuns({ limit: limitRuns }, { readAuth });

  const zeit = (v) => { const t = Date.parse(String(v || "")); return Number.isFinite(t) ? t : null; };
  // Objektreferenzen statt Ids: ein Eintrag OHNE Id wuerde sonst nie als
  // zugeordnet gelten und dauerhaft in "nicht zugeordnet" auftauchen.
  const zugeordnet = new Set();

  const laeufe = runs.map((run) => {
    const runId = run && run.runId ? String(run.runId) : null;
    const start = zeit(run && run.startedAt);
    const ende = zeit(run && run.finishedAt);
    const perRunId = runId ? usage.filter((e) => e && e.runId === runId) : [];
    const weg = perRunId.length ? "laufkennung" : "zeitfenster";
    // DOPPELZAEHLUNG: Zeitfenster von Laeufen koennen sich ueberlappen (heute
    // durch den globalen Understanding-Lock praktisch nicht, konstruktiv aber
    // sehr wohl — z. B. Briefing parallel zum Crawl). Ohne Sperre landete
    // derselbe Aufruf in ZWEI Laeufen und die Summe je Lauf waere zu hoch.
    // processRuns ist neueste-zuerst sortiert; der zeitlich naechstliegende Lauf
    // beansprucht einen Eintrag zuerst, spaetere Laeufe sehen ihn nicht mehr.
    // Der exakte Weg (Laufkennung) ist davon bewusst NICHT betroffen: eine
    // gemessene Zuordnung ist immer eindeutig und darf nie verdraengt werden.
    const treffer = perRunId.length
      ? perRunId
      : (start != null && ende != null
        ? usage.filter((e) => {
          if (zugeordnet.has(e)) return false;
          const t = zeit(e && e.createdAt);
          return t != null && t >= start && t <= ende;
        })
        : []);
    for (const e of treffer) zugeordnet.add(e);
    const agg = costModel.aggregiere(treffer);
    return {
      laufkennung: runId,
      lauftyp: (run && run.process) || null,
      modus: (run && run.mode) || null,
      start: (run && run.startedAt) || null,
      ende: (run && run.finishedAt) || null,
      dauerMs: Number.isFinite(Number(run && run.durationMs)) ? Number(run.durationMs) : null,
      status: (run && run.status) || null,
      verarbeiteteEinheiten: Number.isFinite(Number(run && run.processed)) ? Number(run.processed) : null,
      zuordnungsweg: weg,
      zuordnungExakt: weg === "laufkennung",
      kosten: agg
    };
  });

  // Ehrliche Restgroesse: Provideraufrufe im Beobachtungsfenster, die KEINEM
  // Lauf zugeordnet werden konnten (z. B. Aufrufe aus einem Nutzer-Request).
  const fensterStart = laeufe.reduce((min, l) => {
    const t = zeit(l.start); return t != null && (min == null || t < min) ? t : min;
  }, null);
  const unzugeordnet = usage.filter((e) => {
    const t = zeit(e && e.createdAt);
    if (t == null || fensterStart == null || t < fensterStart) return false;
    return !zugeordnet.has(e);
  });

  return {
    laeufe,
    nichtZugeordnet: costModel.aggregiere(unzugeordnet),
    preisbasis: llmPriceProvenance(),
    hinweis: "Ein Lauf mit zuordnungsweg='zeitfenster' ist REKONSTRUIERT, nicht gemessen: die Nutzungseintraege tragen keine Laufkennung und wurden ueber Start-/Endzeit zugeordnet."
  };
}

// Kostensumme eines Mandats seit einem Kalendertag (inklusive), z. B. Monatsbeginn.
// billable = ohne "skipped-*"-Info-Eintraege (wie getLlmUsageToday).
async function getLlmCostSince(politicianId = null, sinceDay = null, referenceIso = null) {
  const store = await readAuthStore();
  const all = Array.isArray(store.llmUsage) ? store.llmUsage : [];
  const scoped = politicianId
    ? all.filter((e) => e.politicianId === politicianId || e.userId === politicianId)
    : all;
  const from = String(sinceDay || "").slice(0, 10);
  const inWindow = scoped.filter((e) => {
    const d = dayKey(e.createdAt);
    if (!d) return false;
    return from ? d >= from : true;
  });
  const billable = inWindow.filter((e) => !String(e.callType || "").startsWith("skipped"));
  const cost = billable.reduce((sum, e) => sum + (typeof e.estimatedCost === "number" ? e.estimatedCost : 0), 0);
  return { calls: billable.length, estimatedCostUsd: Math.round(cost * 1e6) / 1e6 };
}

// Per-Mandant-Budget-Gate (Phase 10). Kombiniert den GLOBALEN Call-Count-Deckel
// (canSpendLlm) mit dem per-Profil-EUR-Deckel (Tag + Monat) aus dem Profil. Beide
// muessen "allowed" sein. Rueckwaertskompatibel: sind KEINE Profil-Budgets gesetzt
// (dailyBudgetCent/monthlyBudgetCent null), ist das Verhalten identisch zu
// canSpendLlm (nur der globale Deckel). Nie throw.
async function canSpendLlmForTenant(politicianId = null, budgets = {}, referenceIso = null, deps = {}) {
  const llmBudget = require("./llm-budget");
  const usageTodayFn = deps.usageToday || getLlmUsageToday;
  const costSinceFn = deps.costSince || getLlmCostSince;
  const canSpendFn = deps.canSpend || canSpendLlm;
  // GESAMTDECKEL (Budget-Rollout 2026-07): Der Call-Count-Deckel zaehlt GLOBAL
  // (politicianId=null => alle billable Calls aller Pfade/Mandanten), wie beim
  // Understanding. Vorher zaehlte er hier nur die MANDANTEN-eigenen Calls gegen
  // denselben Zahlwert — Buero/Lage und Understanding teilten damit KEINEN
  // echten gemeinsamen Topf (in unguenstiger Reihenfolge bis ~2x Limit). Die
  // EUR-Budgets darunter bleiben bewusst PRO Mandant.
  const global = await canSpendFn(null, referenceIso);
  const dailyBudgetCent = budgets && Number.isFinite(Number(budgets.dailyBudgetCent)) ? Number(budgets.dailyBudgetCent) : null;
  const monthlyBudgetCent = budgets && Number.isFinite(Number(budgets.monthlyBudgetCent)) ? Number(budgets.monthlyBudgetCent) : null;
  if (dailyBudgetCent == null && monthlyBudgetCent == null) {
    return { ...global, tenantBudget: { applied: false } };
  }
  let spentTodayUsd = null;
  let spentMonthUsd = null;
  try {
    const today = dayKey(referenceIso || new Date().toISOString());
    const monthStart = `${today.slice(0, 7)}-01`;
    const [dayCost, monthCost] = await Promise.all([
      usageTodayFn(politicianId, referenceIso),
      costSinceFn(politicianId, monthStart, referenceIso)
    ]);
    spentTodayUsd = dayCost.estimatedCostUsd;
    spentMonthUsd = monthCost.estimatedCostUsd;
  } catch (_) {
    spentTodayUsd = null; // unbekannt -> evaluateTenantBudget faellt fail-closed
    spentMonthUsd = null;
  }
  const tenant = llmBudget.evaluateTenantBudget({ dailyBudgetCent, monthlyBudgetCent, spentTodayUsd, spentMonthUsd });
  const allowed = Boolean(global.allowed) && Boolean(tenant.allowed);
  return {
    allowed,
    used: global.used,
    limit: global.limit,
    remaining: global.remaining,
    reason: !global.allowed ? global.reason : (!tenant.allowed ? tenant.reason : (tenant.warn ? tenant.reason : null)),
    warn: Boolean(tenant.warn),
    tenantBudget: tenant
  };
}

// --- Atomare LLM-Call-Reservierung (Race-Fix 2026-07) ------------------------
// BEFUND (belegt in Production): canSpendLlm ist reines Read-then-Decide ueber dem
// llmUsage-Log; der Log-Eintrag (recordLlmUsage) folgt erst NACH dem Modellaufruf.
// Parallele Requests lesen denselben alten Zaehlerstand und werden gleichzeitig
// freigegeben (bei Zaehlerstand 20 wurde 1 zusaetzlicher Call zugelassen; die
// theoretische Ueberschreitung waechst mit der Zahl paralleler Invocations).
// Verschaerfend: der Auth-Store ist EIN JSON-Dokument mit Voll-Upsert
// (last-write-wins) — parallele recordLlmUsage koennen sich gegenseitig Eintraege
// ueberschreiben, der Zaehler zaehlt dann sogar zu WENIG.
//
// FIX: Reservierung VOR dem Modellaufruf, atomar in Supabase (SQL-Funktion
// helmut_reserve_llm_call: EIN INSERT..ON CONFLICT..WHERE-Statement, Postgres
// serialisiert konkurrierende Upserts derselben (day,scope)-Zeile ueber den
// Row-Lock — korrekt ueber beliebig viele Server-Instanzen). Lokal (Datei-Modus,
// ein Prozess) genuegt ein in-Prozess serialisierter Zaehler. Durchgesetzt wird
// die Reservierung am EINZIGEN Modell-Callsite (ai.js requestOpenAI) — kein
// LLM-Pfad kann sie umgehen. Eine verbrauchte Reservierung wird bei Fehlschlag
// des Modellaufrufs BEWUSST nicht zurueckgegeben (konservativ: Retry-Stuerme
// koennen das Tagesbudget nicht umgehen; identisch zur bisherigen Zaehlung, die
// fehlgeschlagene Calls ebenfalls als billable zaehlt).
//
// Migration: supabase/migrations/20260717_llm_budget_reservation.sql (+ Runbook
// docs/betrieb/llm-budget-reservierung.md). Solange die Migration in Production
// NICHT eingespielt ist, faellt die Reservierung erkennbar (atomic:false, einmalige
// Warnung) auf das bisherige Read-then-Decide zurueck — der Merge ist dadurch
// unabhaengig von der Migrations-Freigabe deploybar.

// Prioritaetsklasse: Understanding (der geteilte Pipeline-Pfad) darf das volle
// Tageslimit nutzen; alle anderen Pfade (Buero, Kommunikation, Lage, App-Start,
// Backfills) nur limit - Reserve. So kann Buero Understanding nicht mehr
// aushungern (F5-Befund Punkt 10), ohne dass ein zweites Budget-System entsteht.
const LLM_PRIORITY_CALLTYPES = new Set(["understanding"]);

// ── Per-Mandant-Kostendeckel (Sprint-1-Sicherheit) ──────────────────────────
// Zusaetzlich zum GLOBALEN Notfalldeckel (llmDailyCallLimit) bekommt jeder Mandant
// einen eigenen atomaren Tageszaehler. Baut auf der bereits in Production
// vorhandenen SQL-Funktion helmut_reserve_llm_call(p_day, p_scope, p_max) auf
// (Migration 20260717) — deren scope-Parameter war exakt fuer 'tenant:<id>'
// vorgesehen. KEINE neue Migration noetig.
//
// SICHERHEIT / VERHALTENSNEUTRALITAET: Default AUS (HELMUT_TENANT_LLM_CAP leer).
// Solange der Deckel aus ist, verhaelt sich reserveLlmCall byte-identisch wie
// bisher (nur globaler Scope) — laufende Mandanten bleiben unberuehrt,
// bis der Betreiber den Deckel ausdruecklich freischaltet (Freigabepunkt).

// Bewusst mandantenlose/geteilte KI-Pfade: der GLOBALE Deckel regelt sie, sie
// bekommen KEINEN per-Mandant-Scope und loesen KEIN fail-closed aus, wenn kein
// Mandant vorliegt. Deckt ab: understanding (geteilter Pipeline-Pfad),
// understanding-* (staff-/presentation-Backfill) und koTagsBackfill (globaler
// Wissenskorpus). Alle anderen callTypes tragen einen Mandanten (siehe ai.js).
const TENANT_EXEMPT_CALLTYPES = new Set(["understanding", "koTagsBackfill"]);
function isSharedGlobalCallType(callType) {
  const ct = String(callType || "");
  return TENANT_EXEMPT_CALLTYPES.has(ct) || ct.startsWith("understanding-");
}

function tenantLlmCapEnabled() {
  return isFlagOn(process.env.HELMUT_TENANT_LLM_CAP);
}

// Sicheres Standardlimit je Mandant, wenn der Deckel aktiv ist, aber fuer den
// Mandanten nichts konfiguriert wurde. Konservativ (fail-closed-Geist): lieber ein
// niedriger Deckel als „unbegrenzt".
const TENANT_LLM_LIMIT_FALLBACK = 40;

// Per-Mandant-Overrides als JSON-Karte, z. B.
// HELMUT_TENANT_LLM_LIMITS='{"tenant-alpha":150,"tenant-beta":30}'. Ungueltiges JSON ->
// ignoriert (uniformer Default greift), einmalige Warnung.
let warnedTenantLimitJson = false;
function tenantLlmLimitsMap() {
  const raw = String(process.env.HELMUT_TENANT_LLM_LIMITS || "").trim();
  if (!raw) return {};
  try {
    const obj = JSON.parse(raw);
    return obj && typeof obj === "object" && !Array.isArray(obj) ? obj : {};
  } catch (_) {
    if (!warnedTenantLimitJson) {
      warnedTenantLimitJson = true;
      console.warn("[llm-budget] HELMUT_TENANT_LLM_LIMITS ist kein gueltiges JSON — per-Mandant-Overrides ignoriert (uniformer Default greift).");
    }
    return {};
  }
}

// Uniformer Default fuer ALLE Mandanten (wenn keine JSON-Override vorliegt). Nur
// eine positive ganze Zahl zaehlt; alles andere -> null (dann greift der
// sichere Fallback).
function tenantLlmUniformDefault() {
  const rawStr = String(process.env.HELMUT_MAX_LLM_CALLS_PER_TENANT_PER_DAY ?? "").trim();
  const raw = Number(rawStr);
  if (rawStr !== "" && Number.isFinite(raw) && raw > 0) return Math.floor(raw);
  return null;
}

// Aufgeloestes Tageslimit (Anzahl Calls) fuer EINEN Mandanten. Praezedenz:
//   expliziter Override (opts.override) > JSON-Map > uniformer Env-Default >
//   sicherer Fallback (TENANT_LLM_LIMIT_FALLBACK). Liefert IMMER eine positive Zahl,
//   sodass ein aktiver Deckel NIE versehentlich „unbegrenzt" bedeutet.
function tenantDailyCallLimit(politicianId, opts = {}) {
  if (opts.override != null && Number.isFinite(Number(opts.override)) && Number(opts.override) > 0) {
    return Math.floor(Number(opts.override));
  }
  const map = tenantLlmLimitsMap();
  const fromMap = map ? map[politicianId] : null;
  if (fromMap != null && Number.isFinite(Number(fromMap)) && Number(fromMap) > 0) {
    return Math.floor(Number(fromMap));
  }
  const uniform = tenantLlmUniformDefault();
  if (uniform != null) return uniform;
  return TENANT_LLM_LIMIT_FALLBACK;
}

// Reservierter Understanding-Mindestanteil (Anzahl Calls). Default 0 = aus, damit
// der Merge verhaltensneutral bleibt; Production-Empfehlung siehe Runbook
// (im selben Freigabeschritt wie HELMUT_MAX_LLM_CALLS_PER_DAY=100 setzen).
let warnedInvalidLlmReserve = false;
function llmUnderstandingReserve() {
  const rawStr = String(process.env.HELMUT_LLM_RESERVE_UNDERSTANDING ?? "").trim();
  if (rawStr === "" || rawStr === "0") return 0;
  const raw = Number(rawStr);
  if (Number.isFinite(raw) && raw > 0) return Math.floor(raw);
  if (!warnedInvalidLlmReserve) {
    warnedInvalidLlmReserve = true;
    console.warn("[llm-budget] HELMUT_LLM_RESERVE_UNDERSTANDING ist gesetzt, aber ungueltig — Reserve 0 aktiv (das Tageslimit selbst bleibt unberuehrt).");
  }
  return 0;
}

// ── VORRANGRESERVE DER REALEN MANDATE (500er-Funktionstest, Sprint 02.09.) ───
// BELEGTER BEFUND (Sicherheitsrahmen §16.6): `HELMUT_TENANT_LLM_CAP` ist AUS, und
// selbst eingeschaltet begrenzt er nur JE Mandant — den GLOBALEN Tagestopf haelt
// er nicht frei. 495 synthetische Profile und 5 reale greifen also in denselben
// Topf, „wer zuerst kommt". Der Vorrangwert des Sicherheitsrahmens
// (`HELMUT_TESTLAUF_VORRANG_REAL`) war bis hierher reine KONFIGURATIONSPRUEFUNG
// ohne Laufzeitwirkung — er schuetzte den Testplan, nicht den Betrieb.
//
// DIE REGEL (jetzt laufzeitwirksam): der Vorrangwert wird vom wirksamen
// Tagesmaximum abgezogen. AUSGENOMMEN ist GENAU EINE Klasse: mandatsgebundene
// Aufrufe eines REALEN Mandats. Sie sind der Zweck der Reserve und sehen
// unveraendert dasselbe Maximum wie bisher.
//
// KORRIGIERT 02.09. (adversariales Diff-Review, bestaetigter Befund): Hier stand
// vorher "Reale Mandate und GETEILTE Arbeit sehen unveraendert dasselbe
// Maximum". Das war FALSCH und widersprach `mandatsklasse.vorrangGiltFuer`, das
// fuer `geteilt === true` ausdruecklich `gilt: true` liefert. Die GETEILTE
// Arbeit (Verstehen, Backfills) IST betroffen — bewusst: sie hat mit
// `HELMUT_LLM_RESERVE_UNDERSTANDING` ihre eigene Reserve und darf nicht
// zusaetzlich die Vorrangreserve aufbrauchen, sonst waere diese keine Reserve
// mehr, sondern eine Empfehlung. Beide Reserven liegen IM Deckel und werden
// NIE addiert.
//
// UNTERGRENZE STATT STILLER NULL (derselbe Befund): Ohne Untergrenze ergaebe ein
// Vorrangwert >= Deckel fuer JEDEN Verstehensaufruf `effectiveMax = 0` — der
// Datenmotor auch der fuenf REALEN Mandate stuende still, waehrend deren
// mandatsgebundene Aufrufe weiterliefen. Der Abzug wird deshalb so gekappt, dass
// dem geteilten/priorisierten Pfad IMMER mindestens die Verstehens-Reserve
// bleibt (`llmVorrangUntergrenze`). Eine Fehlkonfiguration bremst damit, sie
// schaltet nicht ab, und sie wird einmalig protokolliert.
//
// VERHALTENSNEUTRAL OHNE UMGEBUNGSWERT: `HELMUT_TESTLAUF_VORRANG_REAL` ist nicht
// gesetzt => Abzug 0 => dieser Pfad ist byte-identisch zum bisherigen Verhalten.
// FUER MANDATSGEBUNDENE Aufrufe ist er zusaetzlich strukturell wirkungslos,
// solange 0 synthetische Mandatszeilen existieren; fuer die GETEILTE Arbeit gilt
// das ausdruecklich NICHT — dort greift er, sobald der Wert gesetzt ist.
let gewarntVorrangUeberDeckel = false;

function llmVorrangAbzug(callType, politicianId, env = process.env) {
  const geteilt = isSharedGlobalCallType(callType);
  const befund = mandatsklasse.vorrangGiltFuer({ kennung: politicianId, geteilt });
  if (!befund.gilt) return { abzug: 0, befund, reserve: null };
  const reserve = mandatsklasse.vorrangreserveReal(env);
  return { abzug: Math.max(0, Number(reserve.wert) || 0), befund, reserve };
}

// Standard-RPC gegen die atomare SQL-Funktion (PostgREST: returns table -> Array).
async function defaultLlmReserveRpc(params) {
  const rows = await supabaseRequest("/rest/v1/rpc/helmut_reserve_llm_call", {
    method: "POST",
    body: JSON.stringify(params)
  });
  return Array.isArray(rows) ? rows[0] : rows;
}

// Erkennung "Migration noch nicht eingespielt": PostgREST meldet eine unbekannte
// RPC-Funktion mit 404/PGRST202 — DAS ist kein Infrastrukturfehler, sondern der
// dokumentierte Uebergangszustand vor der Migrations-Freigabe.
function isMissingReservationRpcError(error) {
  const msg = String((error && error.message) || "");
  return msg.includes("PGRST202") || /failed \(404\)/.test(msg);
}

// Lokaler Datei-Modus: EIN Prozess -> in-Prozess-Serialisierung (Promise-Kette)
// genuegt; der Zaehler wird pro Tag einmal aus dem llmUsage-Log geseedet und dann
// nur noch im Speicher inkrementiert (Reservierung passiert VOR dem Log-Eintrag).
// BEWUSSTER Trade-off: der Reservierungszaehler ist damit eine EIGENE, strikt
// konservative Wahrheitsquelle — wird das Usage-Log extern manipuliert (Tests)
// oder geleert, gibt die Reservierung NIE mehr Calls frei als seit Prozessstart
// gezaehlt (nie fail-open). Tests, die das Log zuruecksetzen, simulieren einen
// Prozessneustart ueber __resetLlmReservationForTests().
const localLlmCounters = new Map();
let localLlmReserveChain = Promise.resolve();
// Analoger lokaler Zaehler je Mandant (Datei-Modus). Key: `${day}|${tenantId}`.
const localTenantLlmCounters = new Map();
let localTenantReserveChain = Promise.resolve();

// NUR fuer Tests: simuliert Prozessneustart/Tageswechsel des lokalen
// Reservierungszaehlers (Production-Supabase-Pfad hat kein Prozess-Gedaechtnis —
// dort zaehlt die SQL-Funktion in llm_budget_reservations).
function __resetLlmReservationForTests() {
  localLlmCounters.clear();
  localLlmReserveChain = Promise.resolve();
  localTenantLlmCounters.clear();
  localTenantReserveChain = Promise.resolve();
}

function reserveLlmCallLocally(day, effectiveMax, limit, priority, usageTodayFn, vorrangAbzug = 0) {
  const work = async () => {
    let counter = localLlmCounters.get(day);
    if (!counter) {
      const usage = await usageTodayFn(null, `${day}T00:00:00.000Z`);
      counter = { used: Number(usage && usage.calls) || 0 };
      localLlmCounters.set(day, counter);
      // Speicherhygiene: nur die juengsten Tage behalten (Tests springen zwischen Tagen).
      if (localLlmCounters.size > 4) {
        const oldest = [...localLlmCounters.keys()].sort()[0];
        if (oldest !== day) localLlmCounters.delete(oldest);
      }
    }
    if (counter.used >= effectiveMax) {
      return buildReservationResult(false, counter.used, limit, effectiveMax, priority, false, vorrangAbzug);
    }
    counter.used += 1;
    return buildReservationResult(true, counter.used, limit, effectiveMax, priority, false, vorrangAbzug);
  };
  const next = localLlmReserveChain.then(work, work);
  localLlmReserveChain = next.then(() => undefined, () => undefined);
  return next;
}

function buildReservationResult(allowed, used, limit, effectiveMax, priority, atomic, vorrangAbzug = 0) {
  const usedNum = Number.isFinite(Number(used)) ? Number(used) : null;
  // Ehrlicher Ablehnungsgrund: lag der Stand unter dem Tageslimit, hat eine
  // Reserve gegriffen — der Nutzerpfad soll das unterscheiden koennen.
  // Greift die VORRANGRESERVE der realen Mandate (nur bei synthetischen bzw. nicht
  // zuordenbaren mandatsgebundenen Aufrufen, siehe reserveLlmCall), ist SIE die
  // aeusserste Bindung und damit der genauere Grund.
  const abzug = Number.isFinite(Number(vorrangAbzug)) ? Number(vorrangAbzug) : 0;
  const reason = allowed
    ? null
    : (abzug > 0 && usedNum != null && usedNum < limit
      ? "daily-llm-budget-reserved-for-real-mandates"
      : (!priority && usedNum != null && usedNum < limit ? "daily-llm-budget-reserved-for-understanding" : "daily-llm-budget-reached"));
  return {
    allowed,
    used: usedNum,
    limit: Number.isFinite(limit) ? limit : null,
    remaining: Number.isFinite(limit) && usedNum != null ? Math.max(0, limit - usedNum) : null,
    reason,
    priority,
    atomic,
    // Nur gesetzt, wenn die Vorrangreserve fuer DIESEN Aufruf ueberhaupt gilt.
    vorrangreserveReal: abzug > 0 ? abzug : 0
  };
}

// Lokale (Datei-Modus) Mandanten-Reservierung, serialisiert wie der globale Zaehler.
function reserveTenantLocally(day, tenantId, tenantMax, usageTodayFn) {
  const work = async () => {
    const key = `${day}|${tenantId}`;
    let counter = localTenantLlmCounters.get(key);
    if (!counter) {
      const usage = await usageTodayFn(tenantId, `${day}T00:00:00.000Z`);
      counter = { used: Number(usage && usage.calls) || 0 };
      localTenantLlmCounters.set(key, counter);
      // Speicherhygiene: NUR Zaehler FRUEHERER Tage verdraengen — niemals einen
      // HEUTE aktiven Mandanten (sonst re-seedet dessen naechster Call aus dem noch
      // unvollstaendigen Usage-Log unter sein Limit -> Cap-Umgehung). Anders als der
      // globale Zaehler (nur nach Tag gekeyt) tragen Mandanten-Keys `${day}|${id}`,
      // daher explizit auf den Tages-Praefix pruefen statt lexikografisch.
      for (const k of [...localTenantLlmCounters.keys()]) {
        if (k.slice(0, 10) < day) localTenantLlmCounters.delete(k);
      }
    }
    if (counter.used >= tenantMax) return { allowed: false, used: counter.used };
    counter.used += 1;
    return { allowed: true, used: counter.used };
  };
  const next = localTenantReserveChain.then(work, work);
  localTenantReserveChain = next.then(() => undefined, () => undefined);
  return next;
}

function buildTenantResult(allowed, used, tenantMax, atomic) {
  const usedNum = Number.isFinite(Number(used)) ? Number(used) : null;
  return {
    allowed,
    scope: "tenant",
    used: usedNum,
    limit: Number.isFinite(tenantMax) ? tenantMax : null,
    remaining: Number.isFinite(tenantMax) && usedNum != null ? Math.max(0, tenantMax - usedNum) : null,
    reason: allowed ? null : "tenant-daily-budget-reached",
    atomic
  };
}

// Reserviert atomar einen Slot im MANDANTEN-Scope (`tenant:<id>`), VOR der globalen
// Reservierung. Gibt { allowed:true } (weiter zur globalen Reservierung) oder ein
// vollstaendiges Ablehnungsobjekt zurueck. WICHTIG:
//  - Geteilte Calls (understanding/*-backfill/koTagsBackfill) -> allowed:true, kein
//    Mandanten-Scope (globaler Deckel regelt sie).
//  - Tenant-Call OHNE eindeutigen Mandanten -> FAIL-CLOSED (Sprint-Anforderung 8).
//  - Fehlerfall der Reservierung selbst -> llmBudgetFailResult (fail-open, per Flag
//    HELMUT_LLM_BUDGET_FAIL_CLOSED fail-closed) — identisch zur globalen Semantik.
async function reserveTenantScope(opts = {}) {
  const { politicianId = null, callType = "", day, referenceIso = null, rpc = null, usageTodayFn, override } = opts;
  if (isSharedGlobalCallType(callType)) return { allowed: true, scope: "shared" };
  const tid = politicianId == null || String(politicianId).trim() === "" ? null : String(politicianId);
  if (!tid) {
    return {
      allowed: false,
      scope: "tenant",
      used: null,
      limit: null,
      remaining: null,
      reason: "tenant-context-missing-fail-closed",
      atomic: Boolean(rpc)
    };
  }
  const tenantMax = tenantDailyCallLimit(tid, { override });
  const scope = `tenant:${tid}`;
  if (!rpc) {
    try {
      const r = await reserveTenantLocally(day, tid, tenantMax, usageTodayFn);
      return buildTenantResult(r.allowed, r.used, tenantMax, false);
    } catch (_) {
      return { ...llmBudgetFailResult(tenantMax), scope: "tenant", atomic: false };
    }
  }
  try {
    const row = await rpc({ p_day: day, p_scope: scope, p_max: tenantMax });
    if (row && typeof row.allowed === "boolean") return buildTenantResult(row.allowed, row.used, tenantMax, true);
    return { ...llmBudgetFailResult(tenantMax), scope: "tenant", atomic: false };
  } catch (error) {
    if (isMissingReservationRpcError(error)) {
      // Migration nicht eingespielt -> nicht-atomares Altverhalten (auf Basis des
      // Usage-Logs des Mandanten). Der bekannte Race bleibt bis zur Migration.
      try {
        const usage = await usageTodayFn(tid, referenceIso);
        const used = Number(usage && usage.calls) || 0;
        return buildTenantResult(used < tenantMax, used < tenantMax ? used + 1 : used, tenantMax, false);
      } catch (_) {
        return { ...llmBudgetFailResult(tenantMax), scope: "tenant", atomic: false };
      }
    }
    return { ...llmBudgetFailResult(tenantMax), scope: "tenant", atomic: false };
  }
}

// Reserviert GENAU EINEN LLM-Call fuer heute (globaler Zaehler) — atomar, vor dem
// Modellaufruf. Gibt IMMER ein Objekt zurueck (nie throw). Fehlerfall der
// Reservierung selbst: llmBudgetFailResult (fail-open, per Flag
// HELMUT_LLM_BUDGET_FAIL_CLOSED fail-closed) — identische Semantik wie canSpendLlm.
// deps.rpc / deps.usageToday sind fuer Tests injizierbar.
//
// PER-MANDANT-DECKEL (HELMUT_TENANT_LLM_CAP, Default AUS): ist er aktiv, wird ZUERST
// der Mandanten-Scope reserviert und ERST DANN der globale — ein ausgeschoepfter
// Mandant verbraucht so KEINEN globalen Slot und kann keinen anderen Mandanten
// aushungern. Ist er aus, ist der Pfad unten byte-identisch zum bisherigen Verhalten.
let warnedMissingReservationRpc = false;
async function reserveLlmCall(opts = {}) {
  const { callType = "", referenceIso = null, deps = {} } = opts;
  const limit = llmDailyCallLimit();
  if (!Number.isFinite(limit)) {
    // SICHERHEITSNETZ ohne realen Pfad: seit dem Budget-Rollout liefert
    // llmDailyCallLimit() IMMER eine endliche Zahl (fehlend/ungueltig => Schutz-
    // limit 50, es gibt keinen "kein Limit"-Wert mehr). Der Zweig bleibt nur,
    // damit eine kuenftige Aenderung dort das Gate nie versehentlich crasht.
    return { allowed: true, used: null, limit: null, remaining: null, reason: null, priority: false, atomic: false };
  }
  const priority = LLM_PRIORITY_CALLTYPES.has(String(callType || ""));
  const reserve = priority ? 0 : llmUnderstandingReserve();
  // Vorrangreserve der realen Mandate: der Abzug ist 0 fuer mandatsgebundene
  // Aufrufe eines REALEN Mandats; fuer synthetische, nicht zuordenbare UND
  // GETEILTE Aufrufe greift er (siehe llmVorrangAbzug und der Block darueber).
  const vorrang = llmVorrangAbzug(callType, opts.politicianId ?? null, opts.env || process.env);
  const rohMax = priority ? limit : limit - reserve;
  // UNTERGRENZE: der priorisierte/geteilte Pfad behaelt immer mindestens die
  // Verstehens-Reserve. Sonst wuerde ein Vorrangwert >= Deckel den Datenmotor
  // ALLER Mandate stilllegen — auch der fuenf realen.
  const untergrenze = vorrang.abzug > 0 && (priority || vorrang.befund.klasse === "geteilt")
    ? Math.min(rohMax, llmUnderstandingReserve())
    : 0;
  const effectiveMax = Math.max(untergrenze, Math.max(0, rohMax - vorrang.abzug));
  // Eine Fehlkonfiguration darf nicht still bremsen (CLAUDE.md §4.4). Greift die
  // Untergrenze tatsaechlich, wird das EINMAL je Prozess benannt.
  if (untergrenze > 0 && rohMax - vorrang.abzug < untergrenze && !gewarntVorrangUeberDeckel) {
    gewarntVorrangUeberDeckel = true;
    console.warn(`[llm-budget] ${mandatsklasse.VORRANG_REAL_ENV}=${vorrang.abzug} ist zu gross fuer `
      + `den Tagesdeckel ${limit} (Verstehens-Reserve ${llmUnderstandingReserve()}). Der geteilte/`
      + `priorisierte Pfad wird auf die Untergrenze ${untergrenze} gehalten statt auf 0 zu fallen. `
      + "Der Tagesdeckel gehoert VOR der Vorrangreserve angehoben.");
  }
  const day = dayKey(referenceIso || new Date().toISOString());
  const usageTodayFn = deps.usageToday || getLlmUsageToday;
  const rpc = deps.rpc || (useSupabase() ? defaultLlmReserveRpc : null);
  // Per-Mandant-Deckel ZUERST (nur wenn HELMUT_TENANT_LLM_CAP aktiv). Bei Ablehnung
  // wird der globale Zaehler bewusst NICHT angefasst (kein Aushungern anderer
  // Mandanten). Default aus -> No-Op, globaler Pfad unten unveraendert.
  if (tenantLlmCapEnabled()) {
    const tenantGate = await reserveTenantScope({
      politicianId: opts.politicianId ?? null,
      callType,
      day,
      referenceIso,
      rpc,
      usageTodayFn,
      override: opts.tenantMaxCalls
    });
    if (tenantGate && tenantGate.allowed === false) {
      return { ...tenantGate, priority };
    }
  }
  if (!rpc) {
    try {
      return await reserveLlmCallLocally(day, effectiveMax, limit, priority, usageTodayFn, vorrang.abzug);
    } catch (_) {
      return { ...llmBudgetFailResult(limit), priority, atomic: false };
    }
  }
  try {
    const row = await rpc({ p_day: day, p_scope: "global", p_max: effectiveMax });
    if (row && typeof row.allowed === "boolean") {
      return buildReservationResult(row.allowed, row.used, limit, effectiveMax, priority, true, vorrang.abzug);
    }
    return { ...llmBudgetFailResult(limit), priority, atomic: false };
  } catch (error) {
    if (isMissingReservationRpcError(error)) {
      // Uebergangszustand vor der Migrations-Freigabe: bisheriges Read-then-Decide
      // (NICHT atomar — der bekannte Race bleibt bis zur Migration bestehen).
      if (!warnedMissingReservationRpc) {
        warnedMissingReservationRpc = true;
        console.warn("[llm-budget] SQL-Funktion helmut_reserve_llm_call fehlt (Migration 20260717 nicht eingespielt) — Budget-Gate laeuft NICHT-atomar im Altverhalten weiter.");
      }
      try {
        const usage = await usageTodayFn(null, referenceIso);
        const used = Number(usage && usage.calls) || 0;
        return buildReservationResult(used < effectiveMax, used < effectiveMax ? used + 1 : used, limit, effectiveMax, priority, false, vorrang.abzug);
      } catch (_) {
        return { ...llmBudgetFailResult(limit), priority, atomic: false };
      }
    }
    return { ...llmBudgetFailResult(limit), priority, atomic: false };
  }
}

// --- Pipeline-Locking --------------------------------------------------------
// Verhindert, dass zwei parallele Vercel-Invocations denselben Crawl/Briefing-Job
// gleichzeitig ausfuehren und sich gegenseitig ueberschreiben.
//
// P0-4 (freigabepflichtig, Default AUS via HELMUT_ATOMIC_LOCK): zwei Backends.
//  (A) ATOMAR (Flag an + Migration 20260719 eingespielt): EIN INSERT..ON CONFLICT
//      ..WHERE ueber public.pipeline_locks (helmut_acquire_pipeline_lock) —
//      konkurrenzsicher, token-gebundenes Release, und FAIL-CLOSED (return false)
//      bei DB-Fehler. Schliesst R2 (Doppelverarbeitung) + R14 (05:30-Ueberlappung).
//  (B) BLOB (Default): bedingtes Schreiben im Auth-Store. Ein Konflikt oder
//      Datenbankfehler darf niemals als erworbene Sperre gelten.
const heldLockTokens = new Map(); // jobName -> token (nur im atomaren Modus, per Invocation)

function atomicLockEnabled() {
  return isFlagOn(process.env.HELMUT_ATOMIC_LOCK);
}

async function acquirePipelineLockAtomic(jobName, ttlMs, deps = {}) {
  const request = deps.request || supabaseRequest;
  try {
    const rows = await request("/rest/v1/rpc/helmut_acquire_pipeline_lock", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ p_job: jobName, p_ttl_ms: Math.max(1, Math.floor(ttlMs)) })
    });
    const row = Array.isArray(rows) ? rows[0] : rows;
    if (row && row.acquired) {
      if (row.token) heldLockTokens.set(jobName, row.token);
      return true;
    }
    return false;
  } catch (error) {
    // FAIL-CLOSED (Gegenteil des Alt-Verhaltens): bei Lock-Fehler NICHT ausfuehren.
    console.error("[pipelineLock:atomic] fail-closed:", error && error.message);
    return false;
  }
}

async function acquirePipelineLock(jobName, ttlMs = 10 * 60 * 1000, deps = {}) {
  if (atomicLockEnabled()) return acquirePipelineLockAtomic(jobName, ttlMs, deps);
  // (B) Blob-Fallback: CAS Konflikt bedeutet, dass keine Sperre erworben wurde.
  try {
    const store = await readAuthStore();
    const locks = store.pipelineLocks || {};
    const existing = locks[jobName];
    if (existing && existing.expiresAt > Date.now()) {
      console.warn(`[pipelineLock] ${jobName} bereits gesperrt bis ${new Date(existing.expiresAt).toISOString()}`);
      return false;
    }
    locks[jobName] = { lockedAt: Date.now(), expiresAt: Date.now() + ttlMs };
    await writeAuthStore({ ...store, pipelineLocks: locks });
    return true;
  } catch (error) {
    console.error("[pipelineLock] acquire fehlgeschlagen, fail-closed:", error.message);
    return false;
  }
}

async function releasePipelineLock(jobName, deps = {}) {
  if (atomicLockEnabled()) {
    const request = deps.request || supabaseRequest;
    const token = heldLockTokens.get(jobName);
    heldLockTokens.delete(jobName);
    if (!token) return; // nie gehalten (Acquire abgelehnt) -> nichts freizugeben
    try {
      await request("/rest/v1/rpc/helmut_release_pipeline_lock", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ p_job: jobName, p_token: token })
      });
    } catch (error) {
      console.error("[pipelineLock:atomic] release fehlgeschlagen (TTL raeumt auf):", error && error.message);
    }
    return;
  }
  // (B) Blob-Fallback — unveraendert.
  try {
    const store = await readAuthStore();
    const locks = { ...(store.pipelineLocks || {}) };
    delete locks[jobName];
    await writeAuthStore({ ...store, pipelineLocks: locks });
  } catch (error) {
    console.error("[pipelineLock] release fehlgeschlagen:", error.message);
  }
}

// --- Globaler Understanding-Lock (V3-Vorbereitung, C1 — standardmaessig INAKTIV) ---
// Der spaetere globale KI-"Understanding"-Call (1x pro NEUEM Vorgang, mandantenlos)
// darf nicht von zwei ueberlappenden Cron-Laeufen doppelt ausgefuehrt werden — sonst
// verdoppeln sich die KI-Kosten. Anders als die bestehenden per-Mandat-Locks
// (runSourceCrawl/runMorningBriefing) ist dieser Lock GLOBAL: ein fixer,
// mandantenloser jobName.
//
// Aktivierung NUR ueber Flag HELMUT_UNDERSTANDING_LOCK (1/true/on/yes). Solange das
// Flag aus ist (Default), sind beide Helfer NO-OPs: acquire liefert immer ein
// "granted"-Token (active:false) und schreibt NICHTS, release tut nichts. Es wird
// heute noch NIRGENDS aufgerufen — dies verdrahtet nur die Naht fuer die spaetere
// Understanding Engine, ohne V3-Logik zu bauen oder bestehendes Verhalten zu aendern.
const GLOBAL_UNDERSTANDING_LOCK = "global-understanding";

function understandingLockEnabled() {
  return isFlagOn(process.env.HELMUT_UNDERSTANDING_LOCK);
}

async function acquireGlobalUnderstandingLock(ttlMs = 10 * 60 * 1000) {
  if (!understandingLockEnabled()) {
    return { granted: true, active: false, jobName: GLOBAL_UNDERSTANDING_LOCK };
  }
  const granted = await acquirePipelineLock(GLOBAL_UNDERSTANDING_LOCK, ttlMs);
  return { granted, active: true, jobName: GLOBAL_UNDERSTANDING_LOCK };
}

async function releaseGlobalUnderstandingLock() {
  if (!understandingLockEnabled()) return;
  await releasePipelineLock(GLOBAL_UNDERSTANDING_LOCK);
}

// --- Vorgangswache (OP-30-Zielarchitektur, C-Nachfolger des globalen Schlosses) ---
// DEFAULT INERT: ohne HELMUT_VERSTEHEN_KONKURRENZ liefert vorgangsWache() null und
// nichts veraendert sich. Mit Flag: eine datenbank-atomare Exklusivbelegung je
// VORGANG (helmut_klasse_belege, Klasse `verstehen-vorgang:<id>`, max 1), die das
// eigentliche Schutzgut des globalen Understanding-Schlosses — "ein KI-Aufruf je
// neuem Vorgang" — instanzuebergreifend sichert, ohne alles zu serialisieren.
// FAIL CLOSED: eine nicht pruefbare Wache (Migration 20260813 fehlt, DB-Fehler)
// erlaubt NICHTS; der Cluster wird ehrlich zurueckgestellt (skipped-cluster-belegt).
// Abgelaufene Slots heilen sich ueber die TTL selbst (Worker-Absturz).
const VORGANGSWACHE_TTL_MS = Math.max(60000, Number(process.env.HELMUT_VERSTEHEN_WACHE_TTL_MS) || 300000);

function verstehenKonkurrenzEnabled() {
  return isFlagOn(process.env.HELMUT_VERSTEHEN_KONKURRENZ);
}

function vorgangsWache(owner = null) {
  if (!verstehenKonkurrenzEnabled()) return null;
  const wer = String(owner || `verstehen-${Date.now()}-${Math.floor(Math.random() * 1e6)}`);
  return {
    belege: async (vorgangId) => {
      const kennung = String(vorgangId || "").slice(0, 120);
      if (!kennung) return { erlaubt: false, grund: "vorgang-ohne-kennung", slot: null };
      const antwort = await klasseBelege({
        klasse: `verstehen-vorgang:${kennung}`, max: 1, ttlMs: VORGANGSWACHE_TTL_MS, owner: wer
      });
      if (!antwort || antwort.verfuegbar === false) {
        return { erlaubt: false, grund: `wache-nicht-verfuegbar:${(antwort && antwort.grund) || "unbekannt"}`, slot: null };
      }
      return {
        erlaubt: antwort.erlaubt === true,
        grund: antwort.erlaubt === true ? null : "vorgang-belegt",
        slot: antwort.slot || null
      };
    },
    gebeFrei: async (slot) => {
      if (!slot) return;
      await klasseGebeFrei({ slot, owner: wer }).catch(() => null);
    }
  };
}

// --- Admin-Recovery: letzter manueller Understanding-Lauf (Metadaten, KEINE KI/Daten) ---
// Persistiert im BESTEHENDEN Auth-Store (JSON-Dokument, wie pipelineLocks) — keine neue
// Tabelle, keine Migration. Nur skalare Metadaten (Zeit/Status/Zahlen/kurzer Grund), damit
// das Ergebnis des Admin-Buttons einen Reload/Function-Kill uebersteht. Keine Rohtexte/Secrets.
async function saveAdminRecoveryLastRun(entry = {}) {
  try {
    const store = await readAuthStore();
    const clip = (v) => (v == null ? null : String(v).slice(0, 200));
    const num = (v) => (Number.isFinite(Number(v)) ? Number(v) : null);
    const prev = store.adminRecoveryLastRun || {};
    const merged = {
      startedAt: entry.startedAt || prev.startedAt || null,
      finishedAt: entry.finishedAt !== undefined ? entry.finishedAt : (prev.finishedAt || null),
      status: clip(entry.status || prev.status || null),
      grund: entry.grund !== undefined ? clip(entry.grund) : (prev.grund || null),
      verarbeitet: num(entry.verarbeitet),
      versucht: num(entry.versucht),
      imFenster: num(entry.imFenster),
      ausserhalb: num(entry.ausserhalb),
      ohneRohdokumente: num(entry.ohneRohdokumente),
      pendingVorher: num(entry.pendingVorher),
      pendingNachher: num(entry.pendingNachher),
      completeVorher: num(entry.completeVorher),
      completeNachher: num(entry.completeNachher),
      fehler: entry.fehler !== undefined ? clip(entry.fehler) : (prev.fehler || null)
    };
    await writeAuthStore({ ...store, adminRecoveryLastRun: merged });
    return merged;
  } catch (error) {
    console.error("[adminRecovery] saveLastRun fehlgeschlagen:", error && error.message);
    return null;
  }
}

async function getAdminRecoveryLastRun() {
  try {
    const store = await readAuthStore();
    return store.adminRecoveryLastRun || null;
  } catch (_) {
    return null;
  }
}

// --- P0-1: Prozess-Laufzeit-Telemetrie (Understanding-Batch / Briefing / Lage-Fold) ---
// Persistiert eine ECHTE Wall-Clock-Dauer je Batch-Lauf im kleinen Auth-Store —
// NICHT im grossen Content-Blob (Audit R1). Der Eintrag ist eine strenge Allowlist
// technischer Skalare: keine Dokumentinhalte, keine KI-Texte, keine Namen/Kontakte
// (DSGVO-Datensparsamkeit). Fail-safe beim Aufrufer — ein Telemetrie-Write-Fehler
// darf den Batch nie beeinflussen.
// Zaehlerkarte (Ergebnisklasse -> Anzahl) auf eine harte Obergrenze bringen:
// nur bekannte Schluesselform, nur Zahlen, maximal MAX_TELEMETRIE_SCHLUESSEL
// Eintraege. Der Auth-Store ist klein und haelt 300 Laeufe — ohne diese Kappung
// koennte eine unerwartete Statusflut ihn aufblaehen (Audit R1).
const MAX_TELEMETRIE_SCHLUESSEL = 20;
function sanitizeZaehlerkarte(map) {
  if (!map || typeof map !== "object") return null;
  const out = {};
  let n = 0;
  for (const [k, v] of Object.entries(map)) {
    if (n >= MAX_TELEMETRIE_SCHLUESSEL) break;
    const schluessel = String(k).replace(/[^a-zA-Z0-9_-]/g, "").slice(0, 32);
    const wert = Number(v);
    if (!schluessel || !Number.isFinite(wert)) continue;
    out[schluessel] = wert;
    n += 1;
  }
  return Object.keys(out).length ? out : null;
}

function sanitizeProcessRun(entry = {}) {
  // WIE IN blob-relational.js (Befund 30.08.): `Number(null) === 0`. Ein AUSDRUECKLICH
  // als unbekannt uebergebener Wert (null) wurde hier sonst zu einer gemessenen 0 —
  // und haette die Ehrlichkeit der Laufbilanz direkt am Speicherweg wieder aufgehoben.
  // Fehlend (undefined) und unbekannt (null) sind jetzt beide `null`.
  const num = (v) => {
    if (v === null || v === undefined || v === "") return null;
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  };
  const str = (v, max) => (v == null ? null : String(v).slice(0, max));
  const t = entry.telemetrie && typeof entry.telemetrie === "object" ? entry.telemetrie : null;
  return {
    process: str(entry.process, 40) || "unknown",
    runId: str(entry.runId, 80),
    mode: str(entry.mode, 24),
    location: str(entry.location, 40),
    startedAt: str(entry.startedAt, 40),
    finishedAt: str(entry.finishedAt, 40),
    durationMs: num(entry.durationMs),
    processed: num(entry.processed),
    deferred: num(entry.deferred),
    skippedStore: num(entry.skippedStore),
    reason: str(entry.reason, 120),
    status: str(entry.status, 40) || "ok",
    // Nur pseudonyme Zuordnung und feste technische Zustaende, keine Texte.
    mandatsErgebnisse: Array.isArray(entry.mandatsErgebnisse) ? entry.mandatsErgebnisse.slice(0, 500)
      .filter(r => r && /^[a-f0-9]{64}$/.test(r.mandatHash || ""))
      .map(r => ({ mandatHash: r.mandatHash, gestartet: r.gestartet === true,
        lageGespeichert: r.lageGespeichert === true, briefingGespeichert: r.briefingGespeichert === true,
        grund: /^[a-z0-9-]{1,100}$/.test(r.grund || "") ? r.grund : null,
        ...(require("./lage-textqualitaet").sichereDiagnose(r.diagnose)
          ? { diagnose: require("./lage-textqualitaet").sichereDiagnose(r.diagnose) } : {}) })) : null,
    // --- Vorgangsbildung (Betriebsbefund B4): Ergebnis JEDES Clusters -------
    // Bis zu diesem Sprint war der haeufigste Ausgang (`skipped-exists`) in der
    // Telemetrie unsichtbar — ein Betreiber konnte nicht erkennen, dass ein
    // Grossteil der Rohdokumente nie bewertet wurde. Weiterhin AUSSCHLIESSLICH
    // technische Skalare und Klassenzaehler: kein Dokumenttext, keine KI-Ausgabe,
    // keine personenbezogenen Daten.
    cluster: t ? num(t.cluster) : num(entry.cluster),
    dokumente: t ? num(t.dokumente) : null,
    dokumenteOhneEndzustand: t ? num(t.dokumenteOhneEndzustand) : null,
    vorgemerkt: t ? num(t.vorgemerkt) : num(entry.vorgemerkt),
    grossereignisse: t ? num(t.grossereignisse) : null,
    ergebnisse: t ? sanitizeZaehlerkarte(t.ergebnisse) : null,
    gruppen: t ? sanitizeZaehlerkarte(t.gruppen) : null,
    aufloesungen: t ? sanitizeZaehlerkarte(t.aufloesungen) : null,
    auffaelligkeitenGesamt: t ? num(t.auffaelligkeitenGesamt) : null,
    // --- Rueckstandsschleife (Kapazitätssprint 2026-08-31): Waechterwerte der
    // Quittung. BELEGTER ANLASS: der erste natuerliche Lauf (31.08. 11:30 UTC)
    // quittierte OHNE seinen rueckstand-Block — diese Whitelist verwarf ihn
    // still, waehrend der Aufrufer glaubte, ihn zu persistieren (Verstoss gegen
    // CLAUDE.md §4.10: die Meldung behauptete mehr, als die Ablage trug).
    // Ausschliesslich Zahlen (+ der uebersprungen-Marker der Wiedervorlage).
    rueckstand: t && t.rueckstand && typeof t.rueckstand === "object" ? {
      fenster: num(t.rueckstand.fenster),
      laufDeckel: num(t.rueckstand.laufDeckel),
      budgetBoden: num(t.rueckstand.budgetBoden),
      erlaubnisse: num(t.rueckstand.erlaubnisse),
      // PR-C: Fehlversuche des Laufs (billable Azure-Fehlschlaege) — Grundlage der
      // Fehlversuchsquote im Gesundheitsbericht und Ausloesekriterium der
      // Anbietersteuerungs-Eskalation.
      fehlversuche: num(t.rueckstand.fehlversuche),
      // Vorab-Bodenpruefung (Minimal-Cron 2026-09-01; Review-Befund: dieser
      // Block wurde von der Whitelist STILL verworfen, waehrend die Route
      // glaubte, ihn zu persistieren — exakt der §4.10-Verstoss, den diese
      // Whitelist verhindern soll). Nur begrenzter Grund + Zahlen, kein Freitext.
      vorabBoden: t.rueckstand.vorabBoden && typeof t.rueckstand.vorabBoden === "object" ? {
        grund: typeof t.rueckstand.vorabBoden.grund === "string" ? t.rueckstand.vorabBoden.grund.slice(0, 80) : null,
        used: num(t.rueckstand.vorabBoden.used),
        limit: num(t.rueckstand.vorabBoden.limit),
        remaining: num(t.rueckstand.vorabBoden.remaining)
      } : null,
      wiedervorlage: t.rueckstand.wiedervorlage && typeof t.rueckstand.wiedervorlage === "object" ? {
        uebersprungen: t.rueckstand.wiedervorlage.skipped === true,
        geprueft: num(t.rueckstand.wiedervorlage.geprueft),
        freigegeben: num(t.rueckstand.wiedervorlage.freigegeben),
        bleibtGeparkt: num(t.rueckstand.wiedervorlage.bleibtGeparkt),
        unpruefbar: num(t.rueckstand.wiedervorlage.unpruefbar)
      } : null
    } : null,
    // --- W-2 (Werkzeug-Haertung): Pflichtangaben je Lauf — weiterhin NUR
    // technische Skalare, keine Inhalte, keine PII, keine Secrets.
    zielmenge: num(entry.zielmenge),                 // wie viele Objekte sollte der Lauf bearbeiten
    gespeichert: num(entry.gespeichert),
    uebersprungen: num(entry.uebersprungen),
    fehlgeschlagen: num(entry.fehlgeschlagen),
    // --- OP-30 Warteschlangenslot-Quittung (Option D, 2026-08-19): zusaetzliche
    // technische Zaehler des Slots — ausschliesslich Zahlen, keine Inhalte.
    wiederholt: num(entry.wiederholt),               // Auftraege mit Backoff wiederholt
    leaseVerloren: num(entry.leaseVerloren),
    geplant: num(entry.geplant),                     // Planungsphase: kompilierte Auftraege
    neuGeplant: num(entry.neuGeplant),               // davon neu eingereiht
    spiegelGesammelt: num(entry.spiegelGesammelt),   // Blob-Lesespiegel: gesammelte Rohitems
    spiegelGeschrieben: num(entry.spiegelGeschrieben), // davon im EINEN Slot-Write neu im Blob
    fehlerklasse: str(entry.fehlerklasse, 40),       // klassifiziert (redact.js), nie Rohtext
    backend: str(entry.backend, 24) || (useSupabase() ? "supabase" : "local"),
    commit: str(entry.commit || process.env.VERCEL_GIT_COMMIT_SHA || process.env.HELMUT_COMMIT_SHA || null, 40),
    createdAt: new Date().toISOString()
  };
}

// --- W-2 (Werkzeug-Haertung 2026-07-27): Lauftelemetrie parallel-sicher ------
// BEFUND: recordProcessRun lief als Lese-Aendere-Schreibe-Zyklus ueber den
// GESAMTEN Auth-Store-Blob (Zeile `main-auth`). Denselben Blob schreiben
// parallel: recordLlmUsage (bei JEDEM KI-Call), Sessions, systemErrors,
// pipelineLocks (Blob-Modus), understandingRetries, adminRecoveryLastRun … —
// jeder dieser Writer ersetzt die komplette `data`-Spalte mit seinem Lesestand.
// Ein processRuns-Eintrag, der zwischen fremdem Read und fremdem Write entstand,
// war damit VERLOREN (Last-Write-Wins), ohne dass irgendein Fehler auftrat.
// Zusaetzlich verschluckte `.catch(() => {})` bei den Aufrufern jeden echten
// Schreibfehler. Beides ist Befund W-2 (zwei Production-Nachweislaeufe fehlten).
//
// LOESUNG (Option B des Sprints, Muster 20260720_crawl_runs_relational):
//   * Kanonisches Ziel ist die relationale Tabelle public.process_runs —
//     EINE Zeile je (run_id, process), atomarer Upsert (on_conflict), dadurch
//     append-only, idempotent und parallel-sicher unabhaengig von der Blob-Groesse.
//   * Freigabepflichtig: Migration 20260727_process_runs_relational.sql PLUS
//     Flag HELMUT_PROCESS_RUNS_RELATIONAL (Default AUS). Ohne beides bleibt der
//     Blob-Pfad aktiv (Uebergangsphase 1) — jetzt aber idempotent je
//     (runId, process) und mit SICHTBAREN Fehlern statt `return null`.
//   * Dual-Write in der Uebergangsphase 2 (Flag AN): relational ist kanonisch,
//     der Blob wird als Lesespiegel fuer bestehende Leser weitergefuehrt, bis
//     Phase 3/4 des Migrationsplans freigegeben sind
//     (docs/betrieb/blob-relational-migration-plan.md).
//   * KEIN stilles Verschlucken: Ergebnisobjekt { ok, fehler[] } + strukturiertes
//     Log + systemError-Eintrag. Aufrufer muessen das Ergebnis ausweisen.
//
// Zustaende (kanonisch, CHECK-Constraint der Tabelle): running · success ·
// partial · failed · blocked · rolled_back. Die historischen Blob-Werte "ok" und
// "skipped" werden in der Projektion abgebildet (ok->success, skipped->blocked);
// im Blob bleiben sie unveraendert erhalten (bestehende Leser/Tests).
const {
  processRunsRelationalEnabled,
  processRunToRelationalRow,
  relationalRowToProcessRun
} = require("./blob-relational");

// Atomarer relationaler Upsert: EINE Zeile je (run_id, process). Wiederholtes
// Schreiben derselben Laufkennung aktualisiert die Zeile, dupliziert nie.
async function upsertProcessRunRelational(row) {
  if (!v3StoreReady()) throw new Error("relational-store-not-ready");
  await supabaseRequest("/rest/v1/process_runs?on_conflict=run_id,process", {
    method: "POST",
    headers: { Prefer: "resolution=merge-duplicates,return=minimal" },
    body: JSON.stringify(row)
  });
  return { upserted: true };
}

function processRunTelemetrieFehler(backend, error) {
  let meldung = String((error && error.message) || error || "unbekannt");
  try { meldung = require("./redact").redactSensitive(meldung); } catch (_) { /* nie verdecken */ }
  return { backend, fehlerklasse: klassifiziereLesefehler(error), meldung: meldung.slice(0, 200) };
}

// Sichtbarkeit eines Telemetriefehlers: strukturiertes Log + systemError-Eintrag
// (dedupliziert ueber recordPipelineError). Der systemError-Pfad schreibt selbst
// den Auth-Store und kann bei einem Store-Totalausfall ebenfalls scheitern —
// dann bleibt mindestens die strukturierte Log-Zeile.
async function meldeProcessRunTelemetrieFehler(clean, fehler) {
  try {
    console.error(`[processRun] TELEMETRIEFEHLER ${JSON.stringify({
      runId: clean.runId, process: clean.process, fehler
    })}`);
  } catch (_) { /* Logging darf nichts verdecken */ }
  try {
    await recordPipelineError({
      process: "prozesslauf-telemetrie",
      runId: clean.runId,
      errorType: fehler && fehler[0] && `${fehler[0].backend}: ${fehler[0].meldung}`,
      sourceId: clean.process
    });
  } catch (_) { /* Doppelfehler: Log-Zeile oben bleibt */ }
}

// Schreibt die Lauftelemetrie EINES Laufs. Ergebnisobjekt statt Exception:
//   { ok, vollstaendig, relationalAktiv, gespeichert: {relational, blob}, fehler[], eintrag }
// ok            = der KANONISCHE Pfad hat gespeichert (relational, sonst Blob).
// vollstaendig  = zusaetzlich auch der jeweils andere Pfad (Dual-Write-Spiegel).
// Aufrufer duerfen das Ergebnis nicht verwerfen — ein Telemetriefehler gehoert
// in den Abschlussstatus des Laufs (kein `.catch(() => {})` mehr).
// deps (readAuth/writeAuth/insertRelational/relationalAktiv) sind fuer
// deterministische Tests injizierbar (Muster getRunCostReport).
async function recordProcessRun(entry = {}, deps = {}) {
  const readAuth = deps.readAuth || readAuthStore;
  const writeAuth = deps.writeAuth || writeAuthStore;
  const mutateAuth = deps.mutateAuth || (!deps.readAuth && !deps.writeAuth
    ? mutateAuthStore
    : async (change) => { const store = await readAuth(); await change(store); await writeAuth(store); });
  const insertRelational = deps.insertRelational || upsertProcessRunRelational;
  const relationalAktiv = deps.relationalAktiv != null
    ? Boolean(deps.relationalAktiv)
    : (processRunsRelationalEnabled() && v3StoreReady());

  const clean = sanitizeProcessRun(entry);
  if (!clean.runId) {
    // Jeder Lauf braucht eine eindeutige, stabile Kennung. Abgeleitet aus
    // Prozessname + Startzeit — deterministisch fuer denselben logischen Lauf.
    const t = Date.parse(clean.startedAt || clean.createdAt || "") || Date.now();
    clean.runId = `${clean.process}-${t}`;
    clean.runIdAbgeleitet = true;
  }

  const fehler = [];
  let relationalGespeichert = false;
  if (relationalAktiv) {
    try {
      await insertRelational(processRunToRelationalRow(clean));
      relationalGespeichert = true;
    } catch (error) {
      fehler.push(processRunTelemetrieFehler("relational", error));
    }
  }

  let blobGespeichert = false;
  try {
    // Nur diese idempotente Aenderung bei einem bestaetigten CAS Konflikt
    // auf frischem Stand wiederholen, niemals den alten Gesamtblob.
    await mutateAuth((store) => {
      const ohneSelbst = (Array.isArray(store.processRuns) ? store.processRuns : [])
        .filter((r) => !(r && r.runId === clean.runId && r.process === clean.process));
      store.processRuns = [clean, ...ohneSelbst].slice(0, 300);
    });
    blobGespeichert = true;
  } catch (error) {
    fehler.push(processRunTelemetrieFehler("blob", error));
  }

  const ok = relationalAktiv ? relationalGespeichert : blobGespeichert;
  if (fehler.length) await meldeProcessRunTelemetrieFehler(clean, fehler);
  return {
    ok,
    vollstaendig: fehler.length === 0,
    relationalAktiv,
    gespeichert: { relational: relationalGespeichert, blob: blobGespeichert },
    fehler,
    eintrag: clean
  };
}

// Startbeleg eines Laufs (status=running) — NUR relational. Bewusst KEIN
// Blob-Write: ein zusaetzlicher Blob-RMW je Laufstart wuerde das Last-Write-
// Wins-Fenster fuer alle anderen Writer VERGROESSERN. Ohne aktives relationales
// Ziel ist der Startbeleg ein dokumentierter No-Op (Uebergangsphase 1).
// NUTZEN: ein Lauf, der hart stirbt (z. B. Serverless-504), hinterlaesst eine
// sichtbare `running`-Zeile statt spurlos zu verschwinden — genau der zweite
// Verlustmodus aus Befund W-2.
async function recordProcessRunStart(entry = {}, deps = {}) {
  const insertRelational = deps.insertRelational || upsertProcessRunRelational;
  const relationalAktiv = deps.relationalAktiv != null
    ? Boolean(deps.relationalAktiv)
    : (processRunsRelationalEnabled() && v3StoreReady());
  const clean = sanitizeProcessRun({ ...entry, status: "running", finishedAt: null });
  if (!clean.runId) return { ok: false, uebersprungen: false, fehler: [{ backend: "relational", fehlerklasse: "schema-invalid", meldung: "Startbeleg braucht eine runId" }], eintrag: clean };
  if (!relationalAktiv) return { ok: true, uebersprungen: true, grund: "relational-inaktiv", eintrag: clean };
  try {
    await insertRelational(processRunToRelationalRow(clean));
    return { ok: true, uebersprungen: false, eintrag: clean };
  } catch (error) {
    const fehler = [processRunTelemetrieFehler("relational", error)];
    await meldeProcessRunTelemetrieFehler(clean, fehler);
    return { ok: false, uebersprungen: false, fehler, eintrag: clean };
  }
}

// ── OP-30 Option D (Reparatursprint 2026-08-19): Laufquittung des WARTESCHLANGENSLOTS —
// relational, blob-unabhaengig. ──────────────────────────────────────────────────────────────
//
// BELEGTER ANLASS: `runCronUeberWarteschlange` schrieb bis zu diesem Sprint GAR KEINE
// Lauftelemetrie — die beiden Slots des Aktivierungsfensters 18./19.08. (20:00 und 04:00 UTC)
// haben deshalb keine `process_runs`-Zeile hinterlassen, und die Diagnose musste auf
// Vercel-Runtime-Logs ausweichen (Runbook §27). Diese Quittung ist bewusst KEIN
// `recordProcessRun`: sie fasst weder den Auth-Blob noch irgendeine andere Blob-Zeile an
// und ueberlebt damit genau die Stoerungsklasse (Blob-/Storage-Ausfall), die den Anlass
// ausgeloest hat. Beginn (`status='running'`) und Abschluss schreiben dieselbe Zeile
// (atomarer Upsert je (run_id, process)) — idempotent, parallel-sicher.
//
// Gate: NUR `v3StoreReady()`. Das Flag `HELMUT_PROCESS_RUNS_RELATIONAL` steuert den
// Dual-Write der BLOB-kanonischen Telemetrie; diese Quittung ist relational-nativ und hat
// nie eine Blob-Form gehabt. Kann die Warteschlange laufen (sie ist selbst relational),
// ist auch `process_runs` erreichbar. Fehler werden gemeldet, nie geworfen — eine
// gescheiterte Quittung darf den Slot nicht brechen, bleibt aber im Ergebnis sichtbar.
async function schreibeWarteschlangenLaufquittung(entry = {}, deps = {}) {
  const insertRelational = deps.insertRelational || upsertProcessRunRelational;
  const bereit = deps.bereit != null ? Boolean(deps.bereit) : v3StoreReady();
  const clean = sanitizeProcessRun(entry);
  if (!clean.runId) {
    return { ok: false, uebersprungen: false, fehlerklasse: "schema-invalid", grund: "quittung-braucht-runId" };
  }
  if (!bereit) return { ok: false, uebersprungen: true, grund: "relational-store-nicht-bereit" };
  try {
    await insertRelational(processRunToRelationalRow(clean));
    return { ok: true, uebersprungen: false, eintrag: clean };
  } catch (error) {
    const fehler = [processRunTelemetrieFehler("relational", error)];
    // Sichtbar machen OHNE Blob-Zwang: `meldeProcessRunTelemetrieFehler` loggt strukturiert;
    // sein systemError-Versuch darf bei Blob-Ausfall scheitern, die Log-Zeile bleibt.
    await meldeProcessRunTelemetrieFehler(clean, fehler);
    return { ok: false, uebersprungen: false, fehlerklasse: fehler[0].fehlerklasse, grund: fehler[0].meldung };
  }
}

// Relationale process_runs-Zeilen lesen (neueste zuerst, seitenweise).
async function listProcessRunsRelational({ limit = 300 } = {}) {
  const max = Math.max(1, Number(limit) || 300);
  const seite = 1000;
  const out = [];
  for (let offset = 0; offset < max; offset += seite) {
    const nehmen = Math.min(seite, max - offset);
    const rows = await supabaseRequest(
      `/rest/v1/process_runs?select=*&order=created_at.desc&offset=${offset}&limit=${nehmen}`
    );
    if (!Array.isArray(rows) || !rows.length) break;
    out.push(...rows);
    if (rows.length < seite) break;
  }
  return out.map(relationalRowToProcessRun);
}

// Dual-Read: relational (kanonisch, falls aktiv) + Blob (Altbestand/Spiegel),
// dedupliziert ueber (runId, process) mit Vorrang fuer die relationale Zeile.
// Historische Blob-Eintraege bleiben damit ohne Datenmigration lesbar.
// Fehlerverhalten (W-1-Regel gilt auch hier): scheitert JEDE verfuegbare
// Quelle, wird geworfen statt [] zu liefern; scheitert nur eine, liefert die
// andere und der Ausfall wird geloggt.
async function listProcessRuns({ process: proc = null, limit = 100 } = {}, deps = {}) {
  const readAuth = deps.readAuth || readAuthStore;
  const listRelational = deps.listRelational || listProcessRunsRelational;
  const relationalAktiv = deps.relationalAktiv != null
    ? Boolean(deps.relationalAktiv)
    : (processRunsRelationalEnabled() && v3StoreReady());

  let blobRuns = null;
  let blobFehler = null;
  try {
    const store = await readAuth();
    blobRuns = Array.isArray(store.processRuns) ? store.processRuns : [];
  } catch (error) {
    blobFehler = error;
    console.error("[processRun] Blob-Lesepfad fehlgeschlagen:", error && error.message);
  }

  let relationalRuns = null;
  if (relationalAktiv) {
    try {
      relationalRuns = await listRelational({ limit: Math.max(300, Number(limit) || 0) });
    } catch (error) {
      console.error("[processRun] relationaler Lesepfad fehlgeschlagen:", error && error.message);
    }
  }

  if (blobRuns == null && relationalRuns == null) {
    throw new StorageReadError("process_runs", blobFehler || new Error("kein Lesepfad verfuegbar"));
  }

  const key = (r) => `${(r && r.runId) || "?"}|${(r && r.process) || "?"}`;
  const merged = [];
  const gesehen = new Set();
  for (const r of relationalRuns || []) {
    if (!r || gesehen.has(key(r))) continue;
    gesehen.add(key(r));
    merged.push(r);
  }
  for (const r of blobRuns || []) {
    if (!r || gesehen.has(key(r))) continue;
    gesehen.add(key(r));
    merged.push(r);
  }
  merged.sort((a, b) => String((b && b.createdAt) || "").localeCompare(String((a && a.createdAt) || "")));

  let runs = merged;
  if (proc) runs = runs.filter((r) => r && r.process === proc);
  return runs.slice(0, Math.max(0, Number(limit) || 0));
}

// --- Kennzahlen der Vorgangsbildung je Lauf UND je Tag (Betriebsbefund B4) ---
// Verdichtet die Lauftelemetrie, die recordProcessRun ohnehin schreibt. Kein
// zweites Telemetriesystem, keine zusaetzliche Tabelle, kein KI-/Netzzugriff.
// Reine Aggregation ueber den Auth-Store -> auch ohne Datenbankzugriff testbar.
// Welche Laeufe zaehlen als Vorgangsbildung? Bewusst ein PRAEFIX statt einer
// Aufzaehlung: die frueher hier stehende Liste nannte `understanding-lagecheck`,
// geschrieben wird aber `understanding-lage` — und `understanding-nachhol` fehlte
// ganz. Beide Lauftypen fielen dadurch still aus den Kennzahlen. Genau diese Art
// stiller Auslassung ist der Kern von Betriebsbefund B4; ein Praefix kann bei
// einem neuen Lauftyp nicht erneut auseinanderlaufen.
// Geschriebene Namen (Stand 2026-07-26): understanding-eager (scheduler.js),
// understanding-lage (scheduler.js), understanding-cron (server.js),
// understanding-nachhol (scripts/vorgangsbildung-nachholen.js).
function istVorgangsbildungsLauf(run) {
  return Boolean(run && typeof run.process === "string" && run.process.startsWith("understanding-"));
}

function aggregateVorgangsbildung(runs = [], { tage = 7 } = {}) {
  const relevant = (Array.isArray(runs) ? runs : []).filter(istVorgangsbildungsLauf);
  const grenze = Date.now() - Math.max(1, Number(tage) || 7) * 86400000;
  const imFenster = relevant.filter((r) => {
    const t = Date.parse(r.createdAt || r.finishedAt || r.startedAt || "");
    return Number.isFinite(t) ? t >= grenze : false;
  });

  const leereGruppen = () => ({ verarbeitet: 0, zusammengefuehrt: 0, duplikate: 0, ausgeschlossen: 0, fehlgeschlagen: 0, erneut: 0, unbekannt: 0 });
  const summiere = (ziel, quelle) => {
    for (const [k, v] of Object.entries(quelle || {})) ziel[k] = (ziel[k] || 0) + (Number(v) || 0);
    return ziel;
  };

  const jeTag = new Map();
  const gesamt = {
    laeufe: imFenster.length, cluster: 0, dokumente: 0, dokumenteOhneEndzustand: 0,
    vorgemerkt: 0, grossereignisse: 0, zurueckgestellt: 0,
    gruppen: leereGruppen(), ergebnisse: {}, aufloesungen: {}
  };

  for (const r of imFenster) {
    const tag = String(r.createdAt || r.finishedAt || r.startedAt || "").slice(0, 10) || "unbekannt";
    if (!jeTag.has(tag)) {
      jeTag.set(tag, {
        tag, laeufe: 0, cluster: 0, dokumente: 0, dokumenteOhneEndzustand: 0,
        vorgemerkt: 0, grossereignisse: 0, zurueckgestellt: 0,
        gruppen: leereGruppen(), ergebnisse: {}, aufloesungen: {}
      });
    }
    const z = jeTag.get(tag);
    for (const ziel of [z, gesamt]) {
      ziel.cluster += Number(r.cluster) || 0;
      ziel.dokumente += Number(r.dokumente) || 0;
      ziel.dokumenteOhneEndzustand += Number(r.dokumenteOhneEndzustand) || 0;
      ziel.vorgemerkt += Number(r.vorgemerkt) || 0;
      ziel.grossereignisse += Number(r.grossereignisse) || 0;
      ziel.zurueckgestellt += Number(r.deferred) || 0;
      summiere(ziel.gruppen, r.gruppen);
      summiere(ziel.ergebnisse, r.ergebnisse);
      summiere(ziel.aufloesungen, r.aufloesungen);
    }
    z.laeufe += 1;
  }

  const anteile = (gruppen, basis) => Object.fromEntries(Object.entries(gruppen).map(([k, v]) =>
    [k, basis ? Math.round((v / basis) * 1000) / 10 : 0]));
  gesamt.anteile = anteile(gesamt.gruppen, gesamt.cluster);

  return {
    fensterTage: Math.max(1, Number(tage) || 7),
    gesamt,
    jeTag: [...jeTag.values()]
      .map((z) => ({ ...z, anteile: anteile(z.gruppen, z.cluster) }))
      .sort((a, b) => (a.tag < b.tag ? 1 : -1)),
    // Ehrliche Grenze: die Lauftelemetrie ist ein Ringpuffer ueber 300 Laeufe.
    // Reicht das Fenster weiter zurueck, sind die aeltesten Laeufe schlicht nicht
    // mehr da — das wird hier benannt statt als Null ausgewiesen.
    hinweis: relevant.length >= 300 ? "ringpuffer-300-laeufe-moeglicherweise-gekappt" : null
  };
}

async function getVorgangsbildungKennzahlen({ tage = 7 } = {}) {
  const runs = await listProcessRuns({ limit: 300 });
  return aggregateVorgangsbildung(runs, { tage });
}

// --- P0-3: zentraler, datenschutzsicherer Pipeline-Fehler-Sammler ---------------
// Schreibt bislang STILL verschluckte Pipeline-/Crawl-/Understanding-/Matching-/
// Decision-/Lage-Fehler in systemErrors (Auth-Store). VERBINDLICH nur technische
// Metadaten: Prozessname, Laufkennung, pseudonyme Nutzerkennung (nur falls noetig),
// Quellenkennung, KLASSIFIZIERTER Fehlertyp, Zeitpunkt, Commit, Wiederholungsnummer.
// KEIN roher Fehlertext, KEINE Dokumentinhalte, KEINE Secrets/Kontaktdaten.
//
// Dedup ueber einen stabilen, inhaltsfreien Fingerprint (Prozess+Fehlertyp+Quelle):
// wiederkehrende identische Fehler in einem 6-h-Fenster erhoehen einen Zaehler,
// statt die Liste zu fluten. Erfolgslaeufe rufen den Sammler NICHT auf -> kein
// Fehlereintrag bei Erfolg.
const PIPELINE_ERROR_DEDUP_WINDOW_MS = Number(process.env.HELMUT_PIPELINE_ERROR_WINDOW_MS) || 6 * 60 * 60 * 1000;

async function recordPipelineError(entry = {}) {
  _recordingPipelineError = true; // Rekursions-Guard fuer withStoreRetry (Auth-Store-IO)
  try {
    const { classifyPipelineError, pipelineErrorFingerprint } = require("./redact");
    const num = (v) => (Number.isFinite(Number(v)) ? Number(v) : null);
    const str = (v, max) => (v == null ? null : String(v).slice(0, max));
    const store = await readAuthStore();
    const errors = Array.isArray(store.systemErrors) ? store.systemErrors : [];
    const processName = str(entry.process, 40) || "pipeline";
    const errorType = classifyPipelineError(entry.errorType || entry.error);
    const sourceId = str(entry.sourceId, 120);
    const fingerprint = pipelineErrorFingerprint(processName, errorType, sourceId);
    const nowMs = Date.now();
    const nowIso = new Date(nowMs).toISOString();
    const commit = str(entry.commit || process.env.VERCEL_GIT_COMMIT_SHA || process.env.HELMUT_COMMIT_SHA || null, 40);

    // Dedup: bestehenden Eintrag im Fenster hochzaehlen statt neu anlegen.
    const existing = errors.find((e) => e && e.fingerprint === fingerprint && e.lastAtMs && (nowMs - e.lastAtMs) < PIPELINE_ERROR_DEDUP_WINDOW_MS);
    if (existing) {
      existing.count = (Number(existing.count) || 1) + 1;
      existing.lastAt = nowIso;
      existing.lastAtMs = nowMs;
      const r = num(entry.retry);
      if (r != null) existing.retry = Math.max(Number(existing.retry) || 0, r);
      await writeAuthStore({ ...store, systemErrors: errors.slice(0, 500) });
      return existing;
    }

    const clean = {
      id: `err-${nowMs.toString(36)}-${Math.random().toString(36).slice(2, 7)}`,
      scope: "pipeline",
      process: processName,
      runId: str(entry.runId, 80),
      sourceId,
      userId: str(entry.userId, 80),   // pseudonyme Mandats-/Nutzerkennung, nur falls uebergeben
      errorType,                        // KLASSIFIZIERT — nie Rohtext
      retry: num(entry.retry) || 0,     // Wiederholungsnummer
      count: 1,
      commit,
      fingerprint,
      createdAt: nowIso,
      lastAt: nowIso,
      lastAtMs: nowMs
    };
    await writeAuthStore({ ...store, systemErrors: [clean, ...errors].slice(0, 500) });
    return clean;
  } catch (error) {
    try { console.error("[recordPipelineError] fehlgeschlagen (ignoriert):", error && error.message); } catch (_) { /* ignore */ }
    return null;
  } finally {
    _recordingPipelineError = false;
  }
}

// --- Helmut Core V3 Store (C5) — hinter Flag HELMUT_V3_STORE, standardmaessig AUS ---
// Schreibt/liest die relationalen V3-Tabellen (raw_documents, knowledge_objects).
// Wird HEUTE von keinem bestehenden Pfad aufgerufen — reine additive Naht.
// Sicherheitsgarantien:
//   - Flag AUS -> alle Funktionen sind inert (no-op / null / []). Die App laeuft
//     exakt wie bisher; bestehende Storage-Signaturen bleiben unveraendert.
//   - Supabase nicht verfuegbar -> inert statt Crash (kein Netzwerk, kein throw).
function v3StoreEnabled() {
  return isFlagOn(process.env.HELMUT_V3_STORE);
}

// V3-Objekte liegen in relationalen Supabase-Tabellen. Ohne konfiguriertes Supabase
// sind die Funktionen inert (kein Crash), bis der Store bereitsteht.
function v3StoreReady() {
  return v3StoreEnabled() && Boolean(process.env.SUPABASE_URL) && Boolean(supabaseServiceRoleKey());
}

function v3SkipReason() {
  return v3StoreEnabled() ? "v3-store-unavailable" : "v3-store-disabled";
}

function pickColumns(obj = {}, columns) {
  const row = {};
  for (const col of columns) {
    if (obj[col] !== undefined) row[col] = obj[col];
  }
  return row;
}

const V3_RAW_DOCUMENT_COLUMNS = [
  "id", "canonical_url", "content_hash", "cluster_id", "title", "summary", "url",
  "source_name", "source_id", "source_type", "confidence", "link_type",
  "published_at", "retrieved_at", "document_type", "wahlperiode", "raw", "created_at",
  // Globale Dedup/Fundstellen (Migration 20260715_dedup_findings; beschrieben NUR vom
  // Cutover-Schreibpfad persistRawDocumentsDeduped — bestehende Writes setzen sie nicht).
  "content_fingerprint", "publisher_id", "canonical_target_url", "finding_count"
];

const V3_KNOWLEDGE_OBJECT_COLUMNS = [
  "id", "vorgang_id", "ko_version", "headline",
  "was_ist_passiert", "warum_wichtig", "wer_ist_betroffen",
  "parteien", "ausschuesse", "ministerien", "risiken", "chancen",
  "zeitdruck", "handlungsempfehlung", "confidence_score", "source_document_count", "status",
  "understanding_status",
  "mentioned_people", "mentioned_mps", "mentioned_parties", "mentioned_committees",
  "mentioned_ministries", "mentioned_locations", "mentioned_organizations",
  "policy_field", "political_level", "instrument", "stage", "tags", "deadline",
  "best_source_url", "best_link_type", "source_trust",
  "understanding_model", "understanding_tokens", "created_at", "updated_at",
  "display_title", "display_summary", "why_relevant", "recommendation", "display_category",
  // Stabschef-Felder (V3-Fundament, additiv). Aeltere Zeilen bleiben NULL/{} -> die
  // Anwendung liest leer und leitet daraus qualityStatus ab (kein Backfill, kein Fallback).
  "risk_of_no_action", "opportunity_summary", "recommended_communication", "action_items",
  // Strukturierte Stabschef-Werte (Runde 2, additiv NEBEN den Alt-Feldern):
  "risk_level", "opportunity_level", "recommended_communication_struct", "action_items_struct",
  // Klassifikation (Sprint 2, additiv). Lese+Schreib (Matching/Read nutzen decision_level +
  // Geografie). embedding ist bewusst NICHT hier -> siehe V3_KO_WRITE_COLUMNS (Schreiben) und
  // V3_KO_READ_SELECT (Lesen ohne Vektor, Perf).
  "decision_level", "related_levels", "event_type",
  "affected_geographies", "mentioned_geographies", "decision_entities", "related_entities",
  "classification_confidence"
];

// Schreib-Projektion: wie oben PLUS die Spalte embedding vector(256). Inhalt ist ein
// TECHNISCHER FEATURE-/MERKMALSVEKTOR (Token-Hash), KEIN semantisches Embedding — die
// Spalte heisst nur aus Legacy-Gruenden "embedding". Er wird write-time einmal persistiert
// (Sprint 2), beim LESEN aber weggelassen (V3_KO_READ_SELECT), weil er die PostgREST-Antwort
// pro Zeile stark aufblaeht und der Read-Pfad ihn nicht braucht.
// OP-30 CAS, Korrekturlauf 2026-08-15: `verstehen_fencing` steht hier ABSICHTLICH NICHT
// mehr drin. Der Fencing-Wert darf ausschliesslich ueber `helmut_verstehen_speichere`
// geschrieben werden (die Funktion prueft Besitzer, Reservierung, Zustand und Lease
// gemeinsam unter Row-Lock); der Trigger `helmut_ko_fencing_wache` weist jeden anderen
// Setzversuch mit SQLSTATE HV002 ab. Damit kann dieser PostgREST-Pfad den Wert technisch
// gar nicht mehr tragen — die Einwegigkeit ist strukturell, nicht bloss Konvention.
const V3_KO_WRITE_COLUMNS = [...V3_KNOWLEDGE_OBJECT_COLUMNS, "embedding"];

// Die CAS-Projektion des Wissensobjekts fuer `helmut_verstehen_speichere`: identisch zur
// PostgREST-Projektion (dieselben Spalten, dieselbe Embedding-Formatierung), nur ohne den
// Fencing-Wert — der kommt in der Datenbank aus dem dort geprueften Argument.
function baueKoSchreibProjektion(ko = {}) {
  const row = pickColumns(ko, V3_KO_WRITE_COLUMNS);
  if (Array.isArray(ko.embedding) && ko.embedding.length) row.embedding = formatVector(ko.embedding);
  else delete row.embedding;
  return row;
}

// Der Trigger meldet ein veraltetes Ergebnis mit dieser Marke (SQLSTATE HV001). Das ist
// KEIN Speicherfehler, sondern die erfolgreiche Abwehr einer veralteten Ueberschreibung —
// der Aufrufer meldet sie als solche und wiederholt NICHT.
function istFencingVeraltetFehler(error) {
  const text = String((error && error.message) || "");
  return /helmut-verstehen-fencing-veraltet/.test(text) || /HV001/.test(text);
}

// Optionaler 4. Parameter tenantId: NUR gesetzt von den 2 Live-Schreibpfaden
// (saveOfficeOutput, saveRenderedBriefingV3) — jeder andere Aufrufer (Decision-/
// Matching-/Profile-Embedding-Shadow, Raw-Documents, Knowledge-Objects) laesst
// ihn weg und bleibt dadurch unveraendert auf service_role.
async function v3Upsert(table, row, onConflict, tenantId) {
  const rows = await tenantRequest(`/rest/v1/${table}?on_conflict=${onConflict}`, tenantId, {
    method: "POST",
    headers: { Prefer: "resolution=merge-duplicates,return=representation" },
    body: JSON.stringify(row)
  });
  return Array.isArray(rows) && rows.length ? rows[0] : row;
}

// Verknuepfen ist keine Quellenaktualisierung: vorhandene Rohzeilen bleiben atomar
// vollstaendig erhalten, auch bei leerem/neuem Auszug oder veraenderter Provenienz.
// PostgREST verlangt pro Stapel gleiche Spalten; fehlende Felder nie mit null auffuellen.
async function ensureRawDocumentsForLinks(rows = [], onRequest = () => {}) {
  const gruppen = new Map();
  for (const row of rows) {
    if (!row || !row.id) continue;
    const spalten = pickColumns(row, V3_RAW_DOCUMENT_COLUMNS);
    const signatur = Object.keys(spalten).sort().join("|");
    if (!gruppen.has(signatur)) gruppen.set(signatur, []);
    gruppen.get(signatur).push(spalten);
  }
  for (const gruppe of gruppen.values()) {
    for (let i = 0; i < gruppe.length; i += RAW_DOCUMENT_BULK_CHUNK) {
      onRequest();
      await supabaseRequest("/rest/v1/raw_documents?on_conflict=id", {
        method: "POST",
        headers: { Prefer: "resolution=ignore-duplicates,return=minimal" },
        body: JSON.stringify(gruppe.slice(i, i + RAW_DOCUMENT_BULK_CHUNK))
      });
    }
  }
}

async function saveRawDocument(doc = {}) {
  if (!v3StoreReady()) return { skipped: true, reason: v3SkipReason() };
  if (!doc.id) return { skipped: true, reason: "missing-id" };
  try {
    const saved = await v3Upsert("raw_documents", pickColumns(doc, V3_RAW_DOCUMENT_COLUMNS), "id");
    return { saved: true, id: saved.id || doc.id };
  } catch (error) {
    console.error("[v3Store] saveRawDocument fehlgeschlagen:", error.message);
    return { skipped: true, reason: "v3-store-error", error: error.message };
  }
}

async function saveKnowledgeObject(ko = {}) {
  if (!v3StoreReady()) return { skipped: true, reason: v3SkipReason() };
  if (!ko.id || !ko.vorgang_id) return { skipped: true, reason: "missing-id-or-vorgang" };
  try {
    // Embedding als pgvector-Literal; fehlt es, bleibt die Spalte unangetastet
    // (kein Ueberschreiben mit NULL bei einem reinen Feld-Update).
    const row = baueKoSchreibProjektion(ko);
    const saved = await v3Upsert("knowledge_objects", row, "id");
    return { saved: true, id: saved.id || ko.id, vorgangId: saved.vorgang_id || ko.vorgang_id };
  } catch (error) {
    // OP-30 CAS: die Datenbank hat eine VERALTETE Ueberschreibung abgewehrt (ein Lauf mit
    // kleinerem Fencing-Wert wollte ein neueres Ergebnis ersetzen). Das ist der Vertrag bei
    // der Arbeit, kein Speicherfehler — und ausdruecklich KEIN Wiederholungsgrund.
    if (istFencingVeraltetFehler(error)) {
      console.warn("[v3Store] saveKnowledgeObject abgewehrt (veraltetes Verstehensergebnis):", ko.vorgang_id);
      return { skipped: true, reason: "verstehen-fencing-veraltet", veraltet: true };
    }
    console.error("[v3Store] saveKnowledgeObject fehlgeschlagen:", error.message);
    return { skipped: true, reason: "v3-store-error", error: error.message };
  }
}

async function getKnowledgeObjectById(id) {
  if (!v3StoreReady() || !id) return null;
  try {
    const rows = await supabaseRequest(`/rest/v1/knowledge_objects?id=eq.${encodeURIComponent(id)}&select=*&limit=1`);
    return Array.isArray(rows) && rows.length ? rows[0] : null;
  } catch (error) {
    console.error("[v3Store] getKnowledgeObjectById fehlgeschlagen:", error.message);
    return null;
  }
}

// P29-4 (Fix-Sprint Punkt 29): `null` bedeutet fuer Aufrufer "existiert nicht" —
// ein verschluckter LESEFEHLER ist davon nicht unterscheidbar und hat im
// Vormerkpfad ein fertiges Wissensobjekt auf pending zurueckstufen koennen.
// { throwOnError: true } laesst den Lesefehler deshalb sichtbar durchschlagen;
// ohne die Option bleibt das Verhalten fuer alle Bestandsaufrufer unveraendert.
async function getKnowledgeObjectByVorgang(vorgangId, { throwOnError = false } = {}) {
  if (!v3StoreReady() || !vorgangId) return null;
  try {
    const rows = await supabaseRequest(`/rest/v1/knowledge_objects?vorgang_id=eq.${encodeURIComponent(vorgangId)}&select=*&order=updated_at.desc&limit=1`);
    return Array.isArray(rows) && rows.length ? rows[0] : null;
  } catch (error) {
    console.error("[v3Store] getKnowledgeObjectByVorgang fehlgeschlagen:", error.message);
    if (throwOnError) throw error;
    return null;
  }
}

// --- Vorgangsaufloesung (Betriebsbefund B4) ---------------------------------
// Bestehende Vorgaenge unter einem Themenwurzel-Praefix holen. Grundlage der
// Reparatur aus docs/befund-csd-2026-vorgangsverlust.md: die Frage ist nicht mehr
// "gibt es genau diese Kennung?", sondern "gibt es einen Vorgang, der DIESELBE
// SACHE beschreibt?". Die Kandidatenmenge dafuer sind alle Vorgaenge derselben
// Themenwurzel — inklusive der ALTEN Kennungen der Form `vg-<wurzel>`, die exakt
// auf das Praefix fallen und dadurch weiter fortgeschrieben statt dupliziert werden.
//
// Bewusst `like` statt einer Bereichsabfrage: `knowledge_objects` ist klein
// (Groessenordnung 10^3), und eine linksverankerte `like`-Suche ist unter der
// Standard-Collation ohnehin nicht index-nutzbar. Korrektheit vor Mikro-Optimierung.
// MANDANTENNEUTRAL: `knowledge_objects` traegt kein `user_id`/`tenant_id` (ein
// Vorgang wird global genau einmal verstanden) — deshalb hier kein assertTenant.
function sanitizeVorgangPrefix(prefix) {
  // Praefixe entstehen aus slug() und enthalten nur [a-z0-9äöüß-]. Trotzdem
  // defensiv saeubern: PostgREST-Metazeichen duerfen nie in den Filter geraten.
  return String(prefix || "").replace(/[^a-z0-9äöüß-]/gi, "").slice(0, 40);
}

async function listKnowledgeObjectsByVorgangPrefix(prefixes = [], limit = 8) {
  if (!v3StoreReady()) return [];
  const sauber = [...new Set((Array.isArray(prefixes) ? prefixes : [prefixes]).map(sanitizeVorgangPrefix).filter(Boolean))];
  if (!sauber.length) return [];
  const safeLimit = Number.isFinite(Number(limit)) && Number(limit) > 0 ? Math.floor(Number(limit)) : 8;
  try {
    const filter = sauber.length === 1
      ? `vorgang_id=like.${encodeURIComponent(`${sauber[0]}*`)}`
      : `or=(${sauber.map((p) => `vorgang_id.like.${p}*`).join(",")})`;
    // SPRINT 19: die Klassifikationsspalten gehoeren in diese Projektion. Dieser
    // Lesepfad liefert den `existing`-Datensatz, mit dem `understandUpdate` einen
    // Vorgang fortschreibt — ohne decision_level/classification_confidence koennte
    // die bereits ermittelte politische Ebene dort nicht wiederverwendet werden und
    // wuerde bei jeder Aktualisierung neu berechnet. Nur 3 zusaetzliche Spalten auf
    // maximal 8 Zeilen (kein Volltext, kein Vektor).
    //
    // SPRINT 20: aus demselben Grund gehoeren auch die beiden Geografie-Spalten in
    // diese Projektion. Ohne sie kann `understandUpdate` eine bereits belastbar
    // ermittelte betroffene Region nicht wiederverwenden — sie wuerde bei jeder
    // Aktualisierung neu berechnet und bei fehlendem Signal still verloren gehen.
    const cols = "id,vorgang_id,ko_version,status,understanding_status,headline,display_title,created_at,updated_at,source_document_count,decision_level,political_level,classification_confidence,affected_geographies,mentioned_geographies";
    const rows = await supabaseRequest(
      `/rest/v1/knowledge_objects?select=${cols}&${filter}&order=updated_at.desc&limit=${safeLimit}`
    );
    return Array.isArray(rows) ? rows : [];
  } catch (error) {
    console.error("[v3Store] listKnowledgeObjectsByVorgangPrefix fehlgeschlagen:", error.message);
    return [];
  }
}

// Die bereits mit einem Vorgang verknuepften Rohdokumente — der BELEG dafuer,
// worum es in diesem Vorgang tatsaechlich geht. Ohne sie muesste die Aufloesung
// sich auf die KI-formulierte Ueberschrift verlassen (schwaecherer Beleg).
async function listKoDocuments(knowledgeObjectId, limit = 40) {
  if (!v3StoreReady() || !knowledgeObjectId) return [];
  const safeLimit = Number.isFinite(Number(limit)) && Number(limit) > 0 ? Math.floor(Number(limit)) : 40;
  try {
    // Gate-Arm 2026-08-31: document_type gehoert in diese Projektion. Der Pending-/
    // Wiedervorlage-Pfad bewertet Cluster ueber genau diese Zeilen; ohne die
    // Dokumentart koennte ein amtliches Dokument (amtliche-dokumentart) dort als
    // "medien" fehlgestuft und faelschlich geparkt werden — die Gate-Eingabe muss
    // dem Schattenpfad entsprechen, auf dem die Fehlerfreiheit gemessen wurde.
    const cols = "id,title,summary,published_at,url,canonical_url,content_hash,source_id,source_name,document_type,link_type,confidence";
    const rows = await supabaseRequest(
      `/rest/v1/ko_document_links?knowledge_object_id=eq.${encodeURIComponent(knowledgeObjectId)}&select=raw_documents(${cols})&limit=${safeLimit}`
    );
    return (Array.isArray(rows) ? rows : []).map((r) => r && r.raw_documents).filter(Boolean);
  } catch (error) {
    console.error("[v3Store] listKoDocuments fehlgeschlagen:", error.message);
    return [];
  }
}

// Read-Projektion: exakt die vom Read-Pfad genutzten Spalten OHNE das
// embedding vector(256) — das wird beim Lesen nie gebraucht, blaeht die
// PostgREST-Antwort aber pro Zeile deutlich auf (Perf: 200 Zeilen x Vektor).
const V3_KO_READ_SELECT = V3_KNOWLEDGE_OBJECT_COLUMNS.join(",");

// _signalError:true -> bei scharfem Fehler NICHT still [] liefern, sondern ein
// Sentinel { __storeError:true }. So kann der Aufrufer einen echten DB-Ausfall
// von "0 Vorgaenge" unterscheiden (sonst sieht ein Timeout wie Leerstand aus).
//
// `reihenfolge` (Kapazitätssprint 2026-08-31): Whitelist, kein freier Sortier-
// ausdruck. "neueste" = Bestandsverhalten (updated_at.desc). "aelteste" =
// created_at.asc — die Auswahl der Rückstandsläufe, damit die ältesten wartenden
// Vorgänge überhaupt je ins Fenster kommen (belegtes Verhungern: 8.895 von 9.080
// pending älter als 24 h bei ausschließlich jüngst-zuerst-Auswahl). Jeder andere
// Wert fällt geschlossen auf das Bestandsverhalten zurück.
const KO_REIHENFOLGEN = Object.freeze({
  neueste: "updated_at.desc",
  aelteste: "created_at.asc"
});
async function listKnowledgeObjects({ limit = 50, status = null, reihenfolge = "neueste", ohneGateGeparkt = false, _signalError = false } = {}) {
  if (!v3StoreReady()) return _signalError ? { __storeError: true } : [];
  try {
    const safeLimit = Number.isFinite(Number(limit)) && Number(limit) > 0 ? Math.floor(Number(limit)) : 50;
    const order = KO_REIHENFOLGEN[reihenfolge] || KO_REIHENFOLGEN.neueste;
    let endpoint = `/rest/v1/knowledge_objects?select=${V3_KO_READ_SELECT}&order=${order}&limit=${safeLimit}`;
    if (status) endpoint += `&status=eq.${encodeURIComponent(status)}`;
    // Gate-Arm: geparkte Vorgaenge SERVERSEITIG ausschliessen. Ein reiner Client-
    // Filter wuerde das Fenster schrumpfen lassen: die Parkung bumpt updated_at,
    // frisch Geparkte saessen also ganz OBEN im neueste-Fenster und verdraengten
    // echte Arbeit. NULL-sicher als or-Filter — `neq` allein wuerde Altzeilen mit
    // understanding_status IS NULL mit ausschliessen (NULL != 'x' ist NULL).
    if (ohneGateGeparkt) endpoint += "&or=(understanding_status.is.null,understanding_status.neq.gate-geparkt)";
    const rows = await supabaseRequest(endpoint);
    return Array.isArray(rows) ? rows : [];
  } catch (error) {
    console.error("[v3Store] listKnowledgeObjects fehlgeschlagen:", error.message);
    return _signalError ? { __storeError: true } : [];
  }
}

// SPRINT 23C-2A (Befund M-7): gezielter STAPEL-Lesezugriff auf genau die
// Wissensobjekte einer bereits feststehenden Trefferliste.
//
// WARUM NICHT EINFACH EIN GROESSERES FENSTER: `listKnowledgeObjects({limit:N})`
// liefert die N zuletzt GEAENDERTEN Objekte. Die Trefferliste des Matchings
// folgt aber der AEHNLICHKEIT, nicht der Aenderungszeit — beide Ordnungen haben
// nichts miteinander zu tun. Jedes feste N ist deshalb nur eine Wette darauf,
// dass sie sich zufaellig ueberlappen: sie stimmt bei kleinem Bestand, wird mit
// jedem neuen Wissensobjekt unwahrscheinlicher (Production 2026-07-29: ~1 500
// Objekte gegen ein Fenster von 200) und bricht dabei STILL. Diese Funktion
// fragt stattdessen nach den konkreten Kennungen — die gelesene Menge ist exakt
// die gebrauchte, unabhaengig davon, wie gross der Bestand wird.
//
// EINE Anfrage je 100 Kennungen, KEINE Abfrage je Treffer (kein N+1). Bei der
// produktiven Trefferzahl (`matchCount`, heute 20) ist das genau EINE Anfrage,
// die 20 statt 200 Zeilen liest — der Fix ist also auch guenstiger als der
// bisherige Fensterlauf, nicht teurer.
//
// MANDANTENNEUTRAL: `knowledge_objects` traegt kein `user_id`/`tenant_id` (ein
// Vorgang wird global genau einmal verstanden, siehe
// `listKnowledgeObjectsByVorgangPrefix`) — deshalb hier kein `assertTenant`.
// Die Mandantengrenze liegt eine Ebene hoeher und bleibt unveraendert: die
// Kennungen stammen ausschliesslich aus der Trefferliste, die das Matching fuer
// GENAU DIESEN Mandanten berechnet hat.
//
// FEHLERPOLITIK — fail closed und LAUT: ein echter Lesefehler wird GEWORFEN
// (`StorageReadError`) statt still als „kein Objekt gefunden" zu erscheinen.
// Genau diese Verwechslung von „nicht geladen" mit „nichts gefunden" ist der
// Kern von M-7. Ein wirklich nicht (mehr) vorhandenes Objekt fehlt dagegen
// einfach im Ergebnis — der Aufrufer laesst den Beleg dann leer und erfindet
// nichts.
const KO_ID_STAPEL = 100;

async function listKnowledgeObjectsByIds(ids = []) {
  // Deduplizieren und byte-stabil sortieren: zwei Laeufe mit derselben
  // Trefferliste erzeugen dieselben Anfragen in derselben Reihenfolge.
  const liste = [...new Set(
    (Array.isArray(ids) ? ids : [ids])
      .map((id) => (id == null ? "" : String(id)))
      .filter(Boolean)
  )].sort();
  if (!liste.length) return [];
  if (!v3StoreReady()) {
    throw new StorageReadError("knowledge_objects", new Error("v3-store nicht bereit"));
  }
  const out = [];
  try {
    for (let i = 0; i < liste.length; i += KO_ID_STAPEL) {
      const teil = liste.slice(i, i + KO_ID_STAPEL);
      // PostgREST-Konvention fuer `in.(...)`: jeder Wert doppelt gequotet.
      // Der Inhalt wird zusaetzlich prozentkodiert, damit weder ein Komma noch
      // ein Anfuehrungszeichen den Filter verlassen kann. Echte Kennungen
      // bestehen aus [a-z0-9-] — die Kodierung ist dort ein No-Op.
      const inList = teil.map((id) => `"${encodeURIComponent(id)}"`).join(",");
      const rows = await supabaseRequest(
        `/rest/v1/knowledge_objects?select=${V3_KO_READ_SELECT}&id=in.(${inList})&order=id.asc&limit=${teil.length}`
      );
      if (Array.isArray(rows)) out.push(...rows);
    }
    return out;
  } catch (error) {
    console.error("[v3Store] listKnowledgeObjectsByIds fehlgeschlagen:", error.message);
    throw new StorageReadError("knowledge_objects", error);
  }
}

// SPRINT 21: derselbe Lesepfad, aber SEITENWEISE und OHNE stille Kappung.
//
// WARUM ES DIESE ZWEITE FUNKTION BRAUCHT: `listKnowledgeObjects` setzt genau ein
// PostgREST-`limit`. PostgREST liefert aber hoechstens 1 000 Zeilen je Anfrage —
// ein Aufruf mit `limit=5000` bekommt still 1 000 und sieht aus wie ein
// vollstaendiger Bestand. Genau dieser Fehlermodus ist im Repo schon einmal
// aufgetreten (Nebenbefund W-1 bei `listRawDocuments`) und hat dort dazu
// gefuehrt, dass die Haelfte des Bestands unsichtbar blieb.
//
// Ein Bestandsvorgang wie die Nachklassifikation darf davon nicht betroffen
// sein: eine stille Teilmenge waere hier eine falsche Vorher/Nachher-Messung.
// Deshalb: feste Seitengroesse, `order` auf einer STABILEN Spalte (`id`, nicht
// `updated_at` — sonst kann ein paralleler Schreibvorgang Zeilen zwischen zwei
// Seiten verschieben), und ein echter Fehler wird GEWORFEN statt als Leerstand
// gemeldet.
async function listKnowledgeObjectsSeitenweise({ limit = 4000, status = null } = {}) {
  if (!v3StoreReady()) throw new StorageReadError("knowledge_objects", new Error("v3-store nicht bereit"));
  const safeLimit = Number.isFinite(Number(limit)) && Number(limit) > 0 ? Math.floor(Number(limit)) : 4000;
  const out = [];
  try {
    for (let offset = 0; offset < safeLimit; offset += LEBENSZYKLUS_SEITE) {
      const seite = Math.min(LEBENSZYKLUS_SEITE, safeLimit - offset);
      let endpoint = `/rest/v1/knowledge_objects?select=${V3_KO_READ_SELECT}&order=id.asc&limit=${seite}&offset=${offset}`;
      if (status) endpoint += `&status=eq.${encodeURIComponent(status)}`;
      const rows = await supabaseRequest(endpoint);
      if (!Array.isArray(rows) || !rows.length) break;
      out.push(...rows);
      if (rows.length < seite) break;
    }
    return out;
  } catch (error) {
    console.error("[v3Store] listKnowledgeObjectsSeitenweise fehlgeschlagen:", error.message);
    throw new StorageReadError("knowledge_objects", error);
  }
}

// --- Helmut Core V3 — C7a/C7c Storage-Naht (additiv, keine KI) ---------------
// Eigene Flags pro Engine (Default AUS). Steuern das VERHALTEN der Engines
// (matching.js / lazyUnderstanding.js). Die Storage-Writes unten
// gaten wie C5 auf v3StoreReady() -> Flag aus/kein Supabase = inert, kein Crash.
function v3MatchingEnabled() {
  return isFlagOn(process.env.HELMUT_V3_MATCHING);
}
// Sprint 23B-1: Rollout-Grenze der Matching-Auditpersistenz (Roadmap-Punkt 23).
// DEFAULT AUS. Solange das Flag nicht gesetzt ist, findet KEIN Zugriff auf
// matching_runs statt — kein Lesen, kein Schreiben, keine Sperre, keine neue
// Fehlerquelle; matching_results wird exakt wie bisher geschrieben.
// Voraussetzung fuer die Aktivierung: Migration 20260728_matching_audit
// angewendet. Aktivierung ist eine Freigabeentscheidung (CLAUDE.md §5).
// Zusaetzlich an den V3-Store gekoppelt: ohne Supabase-Store wird auch
// matching_results nicht geschrieben — es gaebe dann nichts zu protokollieren,
// und eine „aktive" Auditpersistenz ohne Ablage waere falsches Gruen.
function matchingAuditEnabled() {
  return isFlagOn(process.env.HELMUT_MATCHING_AUDIT) && v3StoreReady();
}
// Sprint M-8: Relevanzriegel im Matching. DEFAULT AUS. Aus = exakt das
// bisherige Top-N-Verhalten. An = es werden nur begruendbare Treffer
// veroeffentlicht, ohne Auffuellung (lib/helmut/matching-relevanz.js).
// Bewusst NICHT an v3StoreReady() gekoppelt: der Riegel ist eine reine
// Auswahlregel und wirkt in jedem Pfad gleich.
function matchingRelevanzGateEnabled() {
  return isFlagOn(process.env.HELMUT_MATCHING_RELEVANZ_GATE);
}
function v3LazyUnderstandingEnabled() {
  return isFlagOn(process.env.HELMUT_V3_LAZY_UNDERSTANDING);
}

// pgvector erwartet den Vektor als Literal '[a,b,c]' (nicht als JSON-Array).
function formatVector(arr) {
  return `[${(Array.isArray(arr) ? arr : []).map((n) => (Number.isFinite(Number(n)) ? Number(n) : 0)).join(",")}]`;
}

// C7a: Merkmalsvektor des Nutzerprofils EINMALIG speichern (bei Profiländerung neu).
// --- Tenant-Guard (P0-1, audit/fix-plan.md) ---------------------------------
// Zentrale Absicherung der Mandantentrennung: JEDE mandantenbezogene V3-Abfrage
// MUSS einen userId (= politicianId) tragen. Ein fehlender/leerer Tenant-Kontext
// ist ein Programmierfehler und wird HART abgewiesen — es gibt KEINEN stillen
// Fallback mehr auf "alle Mandanten". Ersetzt das frühere `if (userId) …`-Muster
// in listDecisions/listMatchingResults, das ohne userId ungefiltert alle Mandanten
// lieferte (latentes IDOR). Der Guard greift BEWUSST vor dem v3StoreReady-Gate,
// damit der Kontrakt unabhängig von der Store-Verfügbarkeit immer gilt (und offline
// testbar ist).
class TenantContextError extends Error {
  constructor(fn) {
    super(`[tenant-guard] ${fn}: userId (Mandantenkontext) ist erforderlich`);
    this.name = "TenantContextError";
    this.code = "TENANT_CONTEXT_REQUIRED";
  }
}

// Wirft, wenn kein belastbarer Mandantenkontext vorliegt; sonst der normalisierte String.
function assertTenant(userId, fn = "query") {
  if (userId == null || (typeof userId === "string" && userId.trim() === "")) {
    throw new TenantContextError(fn);
  }
  return String(userId);
}

// Mandantenuebergreifender Schreibversuch (Sprint-1-Sicherheit): eine Bulk-Write
// vermischt Zeilen mehrerer Mandanten ODER traegt einen fremden user_id.
class CrossTenantWriteError extends Error {
  constructor(fn, detail) {
    super(`[tenant-guard] ${fn}: mandantenuebergreifender Schreibversuch blockiert${detail ? " (" + detail + ")" : ""}`);
    this.name = "CrossTenantWriteError";
    this.code = "CROSS_TENANT_WRITE";
  }
}

// Schreib-Guard: eine mandantenbezogene Bulk-Write darf keine datentragende Zeile
// (mit id) ohne user_id enthalten. Statt sie STILL zu verwerfen (Datenverlust) oder
// tenant-los zu schreiben, wird der Fehler hart sichtbar gemacht.
//
// Sprint-1-Haertung (Cross-Tenant-Write, Testlücke c): zusaetzlich darf eine
// Bulk-Write NICHT Zeilen MEHRERER Mandanten mischen (typischer Cross-Tenant-Bug),
// und wenn der Aufrufer den erwarteten Mandanten kennt (expectedTenant), muss JEDE
// Zeile zu ihm gehoeren. Ohne expectedTenant bleibt das Verhalten rueckwaerts-
// kompatibel (nur die Praesenz-Pruefung + das Mischverbot). Da RLS heute inert ist
// (service_role), ist auch dies eine App-seitige Verteidigung.
function assertTenantRows(rows, fn = "write", expectedTenant = null) {
  const provided = Array.isArray(rows) ? rows : [];
  if (provided.some((r) => r && r.id && (r.user_id == null || String(r.user_id).trim() === ""))) {
    throw new TenantContextError(fn);
  }
  const owners = new Set();
  for (const r of provided) {
    if (r && r.user_id != null && String(r.user_id).trim() !== "") owners.add(String(r.user_id));
  }
  if (owners.size > 1) {
    throw new CrossTenantWriteError(fn, `gemischte Mandanten: ${[...owners].sort().join(", ")}`);
  }
  const exp = expectedTenant == null ? "" : String(expectedTenant).trim();
  if (exp && owners.size === 1 && !owners.has(exp)) {
    throw new CrossTenantWriteError(fn, `erwartet ${exp}, gefunden ${[...owners][0]}`);
  }
  return provided;
}

async function saveProfileEmbedding(entry = {}) {
  if (!v3StoreReady()) return { skipped: true, reason: v3SkipReason() };
  if (!entry.user_id) return { skipped: true, reason: "missing-user" };
  if (!Array.isArray(entry.embedding) || !entry.embedding.length) return { skipped: true, reason: "missing-embedding" };
  try {
    const row = {
      user_id: entry.user_id,
      embedding: formatVector(entry.embedding),
      profile_hash: entry.profile_hash || null,
      dim: entry.dim || entry.embedding.length,
      updated_at: new Date().toISOString()
    };
    const saved = await v3Upsert("profile_embeddings", row, "user_id");
    return { saved: true, userId: saved.user_id || entry.user_id };
  } catch (error) {
    console.error("[v3Store] saveProfileEmbedding fehlgeschlagen:", error.message);
    return { skipped: true, reason: "v3-store-error", error: error.message };
  }
}

async function getProfileEmbedding(userId) {
  const uid = assertTenant(userId, "getProfileEmbedding");
  if (!v3StoreReady()) return null;
  userId = uid;
  try {
    const rows = await supabaseRequest(`/rest/v1/profile_embeddings?user_id=eq.${encodeURIComponent(userId)}&select=*&limit=1`);
    return Array.isArray(rows) && rows.length ? rows[0] : null;
  } catch (error) {
    console.error("[v3Store] getProfileEmbedding fehlgeschlagen:", error.message);
    return null;
  }
}

// C7a: pgvector-Aehnlichkeitssuche via RPC (harte Filter Partei/Ausschuss/Wahlkreis
// laufen in SQL). Ohne Store/Supabase inert (kein Netzwerk).
async function matchKnowledgeObjectsByEmbedding(params = {}) {
  if (!v3StoreReady()) return { skipped: true, reason: v3SkipReason(), results: [] };
  const embedding = params.embedding;
  if (!Array.isArray(embedding) || !embedding.length) return { skipped: true, reason: "missing-embedding", results: [] };
  try {
    const body = {
      query_embedding: formatVector(embedding),
      match_count: Math.max(1, Math.floor(Number(params.matchCount) || 20)),
      filter_parties: params.filterParties && params.filterParties.length ? params.filterParties : null,
      filter_committees: params.filterCommittees && params.filterCommittees.length ? params.filterCommittees : null,
      filter_regions: params.filterRegions && params.filterRegions.length ? params.filterRegions : null
    };
    const rows = await supabaseRequest(`/rest/v1/rpc/match_knowledge_objects`, {
      method: "POST",
      body: JSON.stringify(body)
    });
    return { results: Array.isArray(rows) ? rows : [] };
  } catch (error) {
    console.error("[v3Store] matchKnowledgeObjectsByEmbedding fehlgeschlagen:", error.message);
    return { skipped: true, reason: "v3-store-error", error: error.message, results: [] };
  }
}

// C7a: erklaerbare Match-Ergebnisse pro Nutzer x Vorgang speichern (Bulk-Upsert).
async function saveMatchingResults(rows = [], expectedUserId = null) {
  assertTenantRows(rows, "saveMatchingResults(rows)", expectedUserId);
  if (!v3StoreReady()) return { skipped: true, reason: v3SkipReason(), saved: 0 };
  const list = (Array.isArray(rows) ? rows : []).filter((r) => r && r.id && r.user_id);
  if (!list.length) return { skipped: true, reason: "no-rows", saved: 0 };
  try {
    const payload = list.map((r) => {
      const base = {
        id: r.id,
        user_id: r.user_id,
        knowledge_object_id: r.knowledge_object_id || null,
        vorgang_id: r.vorgang_id || null,
        similarity: r.similarity != null ? r.similarity : null,
        rank: r.rank != null ? r.rank : null,
        matched_features: Array.isArray(r.matched_features) ? r.matched_features : [],
        filters: r.filters && typeof r.filters === "object" ? r.filters : {}
      };
      // Sprint 23B-1: Audit-Spalten NUR mitschreiben, wenn der Aufrufer sie
      // tatsaechlich mitliefert (also nur im aktivierten Auditpfad). Ohne
      // Auditpersistenz ist die geschriebene Nutzlast byte-identisch zu vorher —
      // und ein Aufruf gegen eine Datenbank OHNE die Migration kann keine
      // unbekannte Spalte ansprechen.
      if (!r.run_id) return base;
      return {
        ...base,
        run_id: r.run_id,
        profil_hash: r.profil_hash != null ? r.profil_hash : null,
        ko_eingabe_hash: r.ko_eingabe_hash != null ? r.ko_eingabe_hash : null,
        ko_version: r.ko_version != null ? r.ko_version : null,
        engine_version: r.engine_version != null ? r.engine_version : null,
        rezept_version: r.rezept_version != null ? r.rezept_version : null,
        vektor_version: r.vektor_version != null ? r.vektor_version : null,
        eingabe_fingerabdruck: r.eingabe_fingerabdruck != null ? r.eingabe_fingerabdruck : null,
        berechnet_am: r.berechnet_am != null ? r.berechnet_am : null,
        aktuell: true,
        abgeloest_am: null,
        signale: r.signale && typeof r.signale === "object" ? r.signale : {},
        begruendung: r.begruendung != null ? r.begruendung : null,
        updated_at: r.updated_at != null ? r.updated_at : null
      };
    });
    await v3Upsert("matching_results", payload, "id");
    return { saved: payload.length };
  } catch (error) {
    console.error("[v3Store] saveMatchingResults fehlgeschlagen:", error.message);
    return { skipped: true, reason: "v3-store-error", error: error.message, saved: 0 };
  }
}

// ── Sprint 23B-1: Auditprotokoll der Matching-Laeufe (matching_runs) ─────────
// Alle drei Funktionen erzwingen den Mandantenkontext (assertTenant/
// assertTenantRows) UND einen expliziten user_id=eq.<mandant>-Filter — genau
// wie fuer jede andere mandantenbezogene Tabelle (CLAUDE.md §4.1). RLS ist
// dabei ausdruecklich NICHT die Durchsetzung: service_role umgeht sie.
//
// Anders als die uebrigen v3-Schreibpfade schlucken sie Fehler NICHT: ein
// Auditfehler vor der Veroeffentlichung muss den Lauf abbrechen, damit keine
// unbelegbare Ergebnisgeneration entsteht (Fehlerpolitik: matching-audit.js).

// Sucht ausschliesslich einen VOLLSTAENDIGEN Lauf mit diesem Fingerabdruck.
// Ein 'laufend' oder 'fehlgeschlagen' gebliebener Lauf ist hier bewusst kein
// Treffer — er darf nicht als aktueller Stand gelten.
async function getCompletedMatchingRun({ userId = null, fingerprint = null } = {}) {
  const uid = assertTenant(userId, "getCompletedMatchingRun");
  if (!v3StoreReady()) return null;
  if (!fingerprint) return null;
  const endpoint = `/rest/v1/matching_runs?select=*`
    + `&user_id=eq.${encodeURIComponent(uid)}`
    + `&eingabe_fingerabdruck=eq.${encodeURIComponent(fingerprint)}`
    + `&status=eq.vollstaendig&order=gestartet_am.desc&limit=1`;
  const rows = await supabaseRequest(endpoint);
  return Array.isArray(rows) && rows.length ? rows[0] : null;
}

async function saveMatchingRun(row = {}) {
  assertTenantRows([row], "saveMatchingRun(row)", row && row.user_id);
  if (!v3StoreReady()) throw new Error("matching_runs: V3-Store nicht bereit");
  if (!row.id) throw new Error("matching_runs: Laufkennung fehlt");
  const rows = await supabaseRequest("/rest/v1/matching_runs", {
    method: "POST",
    headers: { Prefer: "return=representation" },
    body: JSON.stringify(row)
  });
  return Array.isArray(rows) && rows.length ? rows[0] : row;
}

// Fortschreiben einer Laufzeile. Der Mandantenfilter ist Pflicht — damit kann
// selbst ein falsch uebergebenes Laufkennzeichen keine fremde Zeile treffen.
// Der Unveraenderlichkeits-Trigger der Datenbank lehnt jede fachliche Aenderung
// an einem bereits abgeschlossenen Lauf zusaetzlich ab.
async function updateMatchingRun(runId, patch = {}, userId = null) {
  const uid = assertTenant(userId, "updateMatchingRun");
  if (!v3StoreReady()) throw new Error("matching_runs: V3-Store nicht bereit");
  if (!runId) throw new Error("matching_runs: Laufkennung fehlt");
  const endpoint = `/rest/v1/matching_runs?id=eq.${encodeURIComponent(runId)}`
    + `&user_id=eq.${encodeURIComponent(uid)}`;
  const rows = await supabaseRequest(endpoint, {
    method: "PATCH",
    headers: { Prefer: "return=representation" },
    body: JSON.stringify(patch)
  });
  if (!Array.isArray(rows) || !rows.length) {
    throw new Error(`matching_runs: Lauf ${runId} fuer Mandant ${uid} nicht aktualisierbar`);
  }
  return rows[0];
}

// ATOMARE Veroeffentlichung: Laufabschluss, Ergebnisprojektion und Abloesung
// in EINEM Aufruf und damit in EINER Datenbanktransaktion.
//
// Das ist bewusst KEINE Folge von drei Schreibvorgaengen. matching_results wird
// in place ueberschrieben — waere der Ergebnis-Upsert ein eigener Aufruf, haette
// ein Abbruch danach den letzten vollstaendigen Stand bereits zerstoert, ganz
// gleich in welcher Reihenfolge die Laufzeile folgt. Entweder wird alles
// sichtbar oder nichts.
//
// Die Datenbankfunktion prueft Mandant, Laufkennung und Laufzustand zusaetzlich
// selbst; hier davor stehen dieselben App-Guards wie an jedem anderen
// mandantenbezogenen Schreibpfad.
async function publishMatchingRun({ runId = null, userId = null, rows = [], abgeloestAm = null } = {}) {
  const uid = assertTenant(userId, "publishMatchingRun");
  const list = Array.isArray(rows) ? rows : [];
  assertTenantRows(list, "publishMatchingRun(rows)", uid);
  if (!v3StoreReady()) throw new Error("matching_runs: V3-Store nicht bereit");
  if (!runId) throw new Error("matching_runs: Laufkennung fehlt");
  if (list.some((r) => !r || r.run_id !== runId)) {
    throw new CrossTenantWriteError("publishMatchingRun(rows)", `Ergebniszeile verweist nicht auf Lauf ${runId}`);
  }
  const antwort = await supabaseRequest("/rest/v1/rpc/helmut_publish_matching_run", {
    method: "POST",
    body: JSON.stringify({
      p_run_id: runId,
      p_user_id: uid,
      p_results: list,
      p_abgeloest_am: abgeloestAm || new Date().toISOString()
    })
  });
  const ergebnis = Array.isArray(antwort) ? antwort[0] : antwort;
  if (!ergebnis || ergebnis.status !== "vollstaendig") {
    throw new Error(`matching_runs: Veroeffentlichung von ${runId} nicht bestaetigt`);
  }
  return {
    runId,
    status: ergebnis.status,
    veroeffentlicht: Number(ergebnis.veroeffentlicht) || 0,
    abgeloest: Number(ergebnis.abgeloest) || 0
  };
}

// HOTFIX (2026-07-29) — AKTIVER PILOTBLOCKER, nicht mehr latent.
// Seit `HELMUT_MATCHING_AUDIT` in Production aktiv ist, werden aus der Trefferliste
// gefallene Ergebnisse NICHT mehr geloescht, sondern mit `aktuell = false` +
// `abgeloest_am` erhalten (Sprint 23B-1). Der erste Production-Lauf hat damit 290
// Zeilen erzeugt: 271 aktuell, 19 abgeloest. Dieser Lesepfad ist der einzige
// produktive Konsument (lage.js -> "Aktuelle Lage", mittelbar das Briefing-Narrativ)
// und filterte bis hierher nicht darauf — abgeloeste Ergebnisse konnten dem
// Abgeordneten als aktuelle Lage erscheinen UND aktuelle Vorgaenge aus dem Limit
// verdraengen.
// Deshalb ist "nur aktuelle Ergebnisse" jetzt der DEFAULT. Der Aktualitaetsfilter
// wird SERVERSEITIG vor `limit` angewendet (PostgREST: where -> order -> limit),
// abgeloeste Zeilen koennen also keinen Platz im Nutzerlimit belegen.
// Altbestand ist nicht betroffen: die Migration setzt `aktuell` auf
// `not null default true`, Legacy-Zeilen mit `run_id = NULL` bleiben sichtbar.
// `includeAbgeloest: true` bleibt als ausdruecklicher Historien-/Auditzugang
// erhalten (kein stiller Verlust der Nachvollziehbarkeit); der Backup-Export liest
// die Tabelle ohnehin direkt und ist von der Aenderung unberuehrt.
async function listMatchingResults({ userId = null, limit = 50, includeAbgeloest = false } = {}, deps = {}) {
  const uid = assertTenant(userId, "listMatchingResults");
  const ready = deps.ready || v3StoreReady;
  // Live-Lesepfad (lage.js waehrend /api/app/start) -> tenantRequest, faellt ohne
  // Tenant-JWT-Modus transparent auf service_role zurueck. deps.request (Tests)
  // hat weiterhin Vorrang.
  const request = deps.request || ((endpoint) => tenantRequest(endpoint, uid));
  if (!ready()) return [];
  try {
    const safeLimit = Number.isFinite(Number(limit)) && Number(limit) > 0 ? Math.floor(Number(limit)) : 50;
    // Mandantenfilter ist PFLICHT (kein optionaler Anhang mehr). Der
    // Aktualitaetsfilter kommt zusaetzlich dazu und greift vor `limit`.
    const aktuellFilter = includeAbgeloest ? "" : "&aktuell=is.true";
    // REIHENFOLGE — Befund F-E2E (2026-08-08), korrigiert und NACHGESCHAERFT im
    // 500-Mandate-Korrektursprint (2026-09-01, Befund 1):
    // `created_at` friert beim ERSTEN Auftreten eines Paares ein (Migration
    // 20260728_matching_audit.sql, Schritt 2: "created_at bleibt bewusst
    // unangetastet"; der Publish-Upsert setzt es nie neu, `rank` dagegen bei
    // jedem Lauf). Eine created_at-primaere Ordnung ist deshalb KEINE aktuelle
    // Relevanzordnung: rein lesend belegt (2026-09-01) tragen die 140 aktuellen
    // Production-Zeilen aus 7 Laeufen gemischte created_at-Werte (bis 18
    // verschiedene je Lauf) mit 588 Rang-Zeitstempel-Inversionen — wichtigere,
    // aeltere Paare fielen hinter unwichtigere Neuzugaenge (und hinter ranglose
    // Altzeilen).
    // Die AKTUELLE Projektion sortiert deshalb primaer nach dem VOM MATCHER
    // BERECHNETEN RANG (`rank.asc.nullslast` — jede aktuelle Zeile traegt den
    // Rang des juengsten bestaetigenden Laufs; ranglose Altzeilen ans Ende),
    // `id.asc` macht die Ordnung TOTAL (deterministisch, PostgREST garantiert
    // bei Gleichstand keine Reihenfolge; nachgewiesen instabil in J8 unter
    // CPU-Knappheit, 1 Fehlschlag in 25 Laeufen). Der Historien-/Auditzugang
    // (`includeAbgeloest: true`) bleibt ZEITLICH sortiert — dort ist die
    // Entstehungsfolge die fachlich richtige Ordnung, nicht der Rang eines
    // einzelnen Laufs. Herleitung: docs/betrieb/skalierungsgrundlage-1000.md §15;
    // Regression: scripts/matching-reihenfolge-test.js.
    const order = includeAbgeloest
      ? "created_at.desc,rank.asc.nullslast,id.asc"
      : "rank.asc.nullslast,id.asc";
    const endpoint = `/rest/v1/matching_results?select=*&user_id=eq.${encodeURIComponent(uid)}${aktuellFilter}&order=${order}&limit=${safeLimit}`;
    const rows = await request(endpoint);
    return Array.isArray(rows) ? rows : [];
  } catch (error) {
    console.error("[v3Store] listMatchingResults fehlgeschlagen:", error.message);
    return [];
  }
}

// Nur einen parse-baren Zeitstempel als ISO durchlassen, sonst null (schützt den
// timestamptz-Spaltentyp vor Modell-Freitext wie "sofort").
function toTimestampOrNull(value) {
  if (value == null || value === "") return null;
  const t = new Date(value).getTime();
  return Number.isFinite(t) ? new Date(t).toISOString() : null;
}

// V3-Decision Engine: pro Nutzer x Vorgang die deterministische Bewertung +
// Entscheidung (ersetzt personalized_recommendations). Bulk-Upsert per stabiler id
// (dec-<user>-<ko>) -> ein erneuter Lauf aktualisiert dieselbe Zeile idempotent.
async function saveDecisions(rows = [], expectedUserId = null) {
  assertTenantRows(rows, "saveDecisions(rows)", expectedUserId);
  if (!v3StoreReady()) return { skipped: true, reason: v3SkipReason(), saved: 0 };
  const list = (Array.isArray(rows) ? rows : []).filter((r) => r && r.id && r.user_id);
  if (!list.length) return { skipped: true, reason: "no-rows", saved: 0 };
  try {
    const payload = list.map((r) => ({
      id: r.id,
      user_id: r.user_id,
      knowledge_object_id: r.knowledge_object_id || null,
      vorgang_id: r.vorgang_id || null,
      score: r.score != null ? r.score : 0,
      decision: r.decision || null,
      priority_type: r.priority_type || null,
      matched_features: Array.isArray(r.matched_features) ? r.matched_features : [],
      chance: r.chance != null ? r.chance : null,
      risk: r.risk != null ? r.risk : null,
      status_change: r.status_change != null ? r.status_change : null,
      // Defensive: ein ungültiger deadline-Wert (Modell-Freitext) darf nicht den
      // ganzen Batch-Upsert per 400 verwerfen -> nur valide Timestamps, sonst null.
      deadline: toTimestampOrNull(r.deadline),
      status: r.status || "new",
      updated_at: new Date().toISOString()
    }));
    await v3Upsert("decisions", payload, "id");
    return { saved: payload.length };
  } catch (error) {
    console.error("[v3Store] saveDecisions fehlgeschlagen:", error.message);
    return { skipped: true, reason: "v3-store-error", error: error.message, saved: 0 };
  }
}

async function listDecisions({ userId = null, limit = 50 } = {}, deps = {}) {
  const uid = assertTenant(userId, "listDecisions");
  const ready = deps.ready || v3StoreReady;
  // Aktuell kein Produktionsaufrufer (siehe docs/auth-service-role-matrix.md),
  // aus Konsistenz dennoch auf tenantRequest umgestellt. deps.request (Tests) hat Vorrang.
  const request = deps.request || ((endpoint) => tenantRequest(endpoint, uid));
  if (!ready()) return [];
  try {
    const safeLimit = Number.isFinite(Number(limit)) && Number(limit) > 0 ? Math.floor(Number(limit)) : 50;
    // Mandantenfilter ist PFLICHT (kein optionaler Anhang mehr).
    const endpoint = `/rest/v1/decisions?select=*&user_id=eq.${encodeURIComponent(uid)}&order=score.desc&limit=${safeLimit}`;
    const rows = await request(endpoint);
    return Array.isArray(rows) ? rows : [];
  } catch (error) {
    console.error("[v3Store] listDecisions fehlgeschlagen:", error.message);
    return [];
  }
}

// C7c: Vorgang als 'pending' vormerken (noch NICHT verstanden, KEIN KI-Call).
// Idempotent: ein bereits vorhandenes KO wird NIE ueberschrieben.
async function savePendingKnowledgeObject(vorgangId, meta = {}) {
  if (!v3StoreReady()) return { skipped: true, reason: v3SkipReason() };
  if (!vorgangId) return { skipped: true, reason: "missing-vorgang" };
  try {
    // P29-4: der Existenz-Check ist FAIL-CLOSED. Ein Lesefehler heisst "unbekannt,
    // ob ein (womoeglich fertiges) Wissensobjekt existiert" — dann darf hier NIE
    // geschrieben werden, sonst stuft der pending-Upsert ein fertig verstandenes
    // Objekt zurueck. Die Vormerkung wird nur vertagt (exakt das Verhalten, das
    // schon immer fuer Schreibfehler galt); der naechste Lauf holt sie nach.
    let existing;
    try {
      existing = await getKnowledgeObjectByVorgang(vorgangId, { throwOnError: true });
    } catch (leseFehler) {
      return { skipped: true, reason: "existenz-unbekannt", error: String((leseFehler && leseFehler.message) || "").slice(0, 200) };
    }
    if (existing) return { skipped: true, reason: "exists", id: existing.id, status: existing.status };
    const row = {
      id: `ko-${vorgangId}`,
      vorgang_id: vorgangId,
      status: "pending",
      understanding_status: "pending", // explizit (nicht nur DB-Default) -> C8 findet ihn
      source_document_count: Number(meta.source_document_count) || 0,
      headline: meta.headline ? String(meta.headline).slice(0, 300) : null
    };
    const saved = await v3Upsert("knowledge_objects", pickColumns(row, V3_KNOWLEDGE_OBJECT_COLUMNS), "id");
    return { saved: true, id: saved.id || row.id, status: "pending" };
  } catch (error) {
    console.error("[v3Store] savePendingKnowledgeObject fehlgeschlagen:", error.message);
    return { skipped: true, reason: "v3-store-error", error: error.message };
  }
}

// K4 (OP-25 E3, Bulk nach F-RT-Muster): Vormerkung VIELER zurueckgestellter Cluster in
// wenigen Anfragen statt in zwei seriellen Round-Trips je Cluster. Gemessen war der
// serielle Pfad die Ursache dafuer, dass bei ~1 213 Clustern Rueckstand die E3-Zusage
// strukturell unerfuellbar war (~1,7 Cluster/s; Ursachenanalyse §7.7.6, Befund 5).
//
// SEMANTIK, bewusst identisch zum Einzelpfad (savePendingKnowledgeObject + saveKoDocumentLinks):
//   * `resolution=ignore-duplicates` beim KO-Insert beruehrt vorhandene Zeilen NIE — ein
//     fertig verstandenes Objekt kann nicht zurueckgestuft werden (der P29-4-Schutz gilt
//     hier OHNE Vorab-Read, weil gar kein Update moeglich ist), und Wiederholungen
//     erzeugen keine Duplikate (idempotent, kein unkontrolliertes Wachstum).
//   * Die Dokumentverknuepfung (raw_documents sichern + ko_document_links) laeuft je Chunk
//     gebuendelt; OHNE Verknuepfung ist eine Vormerkung nicht wiederauffindbar (B4) und
//     zaehlt deshalb als FEHLGESCHLAGEN, nie als vorgemerkt.
//   * Die Bilanz geht auf: eintraege = vorgemerkt + bereitsVorhanden + fehlgeschlagen.
//     Ein Speicherfehler wird gezaehlt und gemeldet — nie als Erfolg gewertet (CLAUDE.md §4.10).
const PENDING_BULK_CHUNK = Math.max(1, Number(process.env.HELMUT_PENDING_BULK_CHUNK) || 200);

async function savePendingKnowledgeObjectsBulk(eintraege = [], { deadlineMs = 0, now = Date.now } = {}) {
  const bilanz = { vorgemerkt: 0, bereitsVorhanden: 0, fehlgeschlagen: 0, nichtVersucht: 0, verknuepfteDokumente: 0, anfragen: 0 };
  if (!v3StoreReady()) return { skipped: true, reason: v3SkipReason(), ...bilanz };
  const gueltige = (Array.isArray(eintraege) ? eintraege : []).filter((e) => e && e.vorgangId);
  if (!gueltige.length) return bilanz;
  for (let i = 0; i < gueltige.length; i += PENDING_BULK_CHUNK) {
    // Die Deadline gilt auch ZWISCHEN den Chunks: eine degradierte Datenbank (z. B. 10 s je
    // Anfrage) darf die Abschlussphase nicht ueber ihre Reserve hinaus halten. Der Rest wird
    // ehrlich als `nichtVersucht` gezaehlt — nie als Erfolg (CLAUDE.md §4.10).
    if (deadlineMs && now() > deadlineMs) {
      bilanz.nichtVersucht += gueltige.length - i;
      console.error(`[v3Store] savePendingKnowledgeObjectsBulk: Deadline erreicht — ${gueltige.length - i} Vormerkungen nicht mehr versucht.`);
      break;
    }
    const chunk = gueltige.slice(i, i + PENDING_BULK_CHUNK);
    let neu = 0;
    try {
      const rows = chunk.map((e) => pickColumns({
        id: `ko-${e.vorgangId}`,
        vorgang_id: e.vorgangId,
        status: "pending",
        understanding_status: "pending",
        source_document_count: Number(e.source_document_count) || 0,
        headline: e.headline ? String(e.headline).slice(0, 300) : null
      }, V3_KNOWLEDGE_OBJECT_COLUMNS));
      const eingefuegt = await supabaseRequest("/rest/v1/knowledge_objects?on_conflict=id", {
        method: "POST",
        headers: { Prefer: "resolution=ignore-duplicates,return=representation" },
        body: JSON.stringify(rows)
      });
      bilanz.anfragen += 1;
      neu = Array.isArray(eingefuegt) ? eingefuegt.length : 0;
    } catch (error) {
      bilanz.anfragen += 1;
      bilanz.fehlgeschlagen += chunk.length;
      console.error("[v3Store] savePendingKnowledgeObjectsBulk: KO-Chunk fehlgeschlagen:", error.message);
      continue;
    }
    // Verknuepfung des Chunks: erst FK-Ziele (raw_documents) sichern, dann die Kanten —
    // gebuendelt statt je Cluster. Scheitert sie, ist der GANZE Chunk fehlgeschlagen
    // (Vormerkung ohne Verknuepfung ist nicht wiederauffindbar, B4).
    try {
      const docsById = new Map();
      const links = [];
      for (const e of chunk) {
        for (const d of Array.isArray(e.dokumente) ? e.dokumente : []) {
          if (!d || !d.id) continue;
          docsById.set(d.id, pickColumns(d, V3_RAW_DOCUMENT_COLUMNS));
          links.push({ knowledge_object_id: `ko-${e.vorgangId}`, raw_document_id: d.id });
        }
      }
      if (docsById.size) {
        await ensureRawDocumentsForLinks([...docsById.values()], () => { bilanz.anfragen += 1; });
      }
      if (links.length) {
        await v3Upsert("ko_document_links", links, "knowledge_object_id,raw_document_id");
        bilanz.anfragen += 1;
        bilanz.verknuepfteDokumente += links.length;
      }
      bilanz.vorgemerkt += neu;
      bilanz.bereitsVorhanden += chunk.length - neu;
    } catch (error) {
      bilanz.fehlgeschlagen += chunk.length;
      console.error("[v3Store] savePendingKnowledgeObjectsBulk: Verknuepfungs-Chunk fehlgeschlagen:", error.message);
    }
  }
  return bilanz;
}

// C8: die von C7c vorgemerkten Vorgaenge holen, die C8 noch verstehen soll.
// status='pending' = noch nicht verstanden; understanding_status='failed' wird
// bewusst NICHT erneut versucht (geparkt), sonst laeuft ein kaputter Vorgang
// jeden Lauf erneut ins KI-Budget. 'failed-final' (terminal, OP-06/P1-4) ist
// ebenfalls ausgeschlossen — sonst wuerde ein aussortierter Vorgang jeden Lauf
// erneut geprueft und bei spaeter passendem Cluster sogar erneut verstanden.
// Inert wenn Flag/Supabase aus (kein Crash).
// Gate-Arm 2026-08-31: 'gate-geparkt' wird serverseitig ausgeschlossen (Fenster-
// schutz, s. listKnowledgeObjects) UND hier nochmals clientseitig — Gurt und
// Hosentraeger, damit ein geparkter Vorgang auch bei einem kuenftigen Aufrufer
// ohne ohneGateGeparkt-Flag nie erneut ins KI-Budget laeuft. Rueckweg ist
// ausschliesslich releaseUnderstandingGateGeparkt (Zustand -> pending).
async function listPendingKnowledgeObjects({ limit = 50, reihenfolge = "neueste" } = {}) {
  const rows = await listKnowledgeObjects({ status: "pending", limit, reihenfolge, ohneGateGeparkt: true });
  return (Array.isArray(rows) ? rows : []).filter((ko) => ko
    && ko.understanding_status !== "failed"
    && ko.understanding_status !== "gate-geparkt"
    && !isTerminalUnderstandingStatus(ko.understanding_status));
}

// --- W-1 (Werkzeug-Haertung 2026-07-27): Lesefehler sind KEINE leere Menge ---
// Bis zu diesem Sprint fing jede Lebenszyklus-List-Funktion ihre Fehler selbst
// und lieferte [] (listRawDocuments/listRecentRawDocuments) oder sogar eine
// stille TEILMENGE (listKoDocumentLinks/listKnowledgeObjectStates gaben das bis
// zum Fehler Gelesene zurueck). Ein DNS-, Timeout-, Auth- oder Storagefehler war
// fuer den Aufrufer von "erfolgreich, aber leer" nicht unterscheidbar — das
// Nachholwerkzeug meldete dann "Nichts nachzuholen" mit Exit 0 (falsches Gruen,
// Befund W-1). Jetzt gilt:
//   * [] bedeutet ausschliesslich "erfolgreich gelesen, null Zeilen".
//   * Ein technischer Fehler wird als typisierter StorageReadError GEWORFEN —
//     mit Quelle (Tabellenname) und inhaltsfreier Fehlerklasse, Meldung redigiert
//     (redactSensitive), nie mit Secrets oder Connection-Strings.
//   * v3StoreReady()===false bleibt bewusst [] — das ist ein KONFIGURATIONS-
//     zustand (Flag/Env fehlt, lokaler Betrieb, Tests), kein Laufzeitfehler.
//     Werkzeuge, die den Unterschied brauchen, pruefen v3StoreReady() vorab.
// Fehlermeldung samt cause-Kette einsammeln: Nodes fetch (undici) wirft bei
// DNS-/Verbindungsfehlern nur "fetch failed" — der eigentliche Grund
// (getaddrinfo ENOTFOUND, ECONNREFUSED …) steht in error.cause.
function lesefehlerKette(error) {
  const teile = [];
  let e = error;
  for (let tiefe = 0; tiefe < 4 && e; tiefe += 1) {
    if (typeof e === "string") { teile.push(e); break; }
    if (e.message) teile.push(String(e.message));
    if (e.code && !teile.join(" ").includes(String(e.code))) teile.push(String(e.code));
    e = e.cause;
  }
  return teile.join(" :: ") || "unbekannt";
}

function klassifiziereLesefehler(error) {
  const m = lesefehlerKette(error).toLowerCase();
  // Auth VOR der generischen 4xx-Klasse: ein abgelaufener/falscher Service-Key
  // ist betrieblich etwas anderes als eine kaputte Query.
  if (m.includes("401") || m.includes("403") || m.includes("unauthorized")
    || m.includes("permission denied") || m.includes("jwt") || m.includes("api key") || m.includes("apikey")) return "auth";
  // DNS/Verbindung VOR classifyPipelineError: dessen "supabase"->db-Heuristik
  // wuerde sonst jeden Fehler fangen, dessen HOSTNAME "supabase" enthaelt
  // (getaddrinfo ENOTFOUND xyz.supabase.co ist ein DNS-, kein DB-Fehler).
  if (m.includes("enotfound") || m.includes("eai_again") || m.includes("getaddrinfo")) return "dns";
  if (m.includes("econnrefused") || m.includes("econnreset")) return "connection";
  try { return require("./redact").classifyPipelineError(m); } catch (_) { return "unknown"; }
}

class StorageReadError extends Error {
  constructor(quelle, cause) {
    const fehlerklasse = klassifiziereLesefehler(cause);
    let meldung = lesefehlerKette(cause);
    try { meldung = require("./redact").redactSensitive(meldung); } catch (_) { /* Redaktion darf den Fehler nicht verdecken */ }
    super(`Lesefehler ${quelle} (${fehlerklasse}): ${meldung.slice(0, 240)}`);
    this.name = "StorageReadError";
    this.quelle = quelle;             // z. B. "raw_documents"
    this.fehlerklasse = fehlerklasse; // dns | timeout | auth | db | connection | http-4xx | http-5xx | ...
    this.cause = cause;
  }
}

// C8: minimierte raw_documents der letzten 30 Tage aus dem V3-Store holen.
// Liefert die Zeilen, die runPendingUnderstandingShadow als rawDocsOrItems benoetigt.
// Inert wenn v3StoreReady() false ist (kein Crash, leeres Array).
// PostgREST liefert serverseitig hoechstens `max-rows` Zeilen je Anfrage (hier
// 1000). Ein `limit=2000` wurde deshalb bisher STILL auf 1000 gekappt — der
// Aufrufer sah ein vollstaendiges Ergebnis, hatte aber die Haelfte nicht. Genau
// diese Art stiller Kappung ist der Kern von Betriebsbefund B4, deshalb wird hier
// seitenweise gelesen, bis das angeforderte Limit erreicht oder die Menge zu Ende ist.
const RAW_DOC_SEITE = 1000;

async function fetchRawDocumentPages(basePath, limit) {
  const ziel = Number.isFinite(Number(limit)) && Number(limit) > 0 ? Math.floor(Number(limit)) : RAW_DOC_SEITE;
  const out = [];
  for (let offset = 0; offset < ziel; offset += RAW_DOC_SEITE) {
    const seite = Math.min(RAW_DOC_SEITE, ziel - offset);
    const rows = await supabaseRequest(`${basePath}&limit=${seite}&offset=${offset}`);
    if (!Array.isArray(rows) || !rows.length) break;
    out.push(...rows);
    if (rows.length < seite) break;
  }
  return out;
}

async function listRecentRawDocuments(limit = 500, days = 30) {
  if (!v3StoreReady()) return [];
  try {
    const cutoffIso = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString();
    return await fetchRawDocumentPages(
      `/rest/v1/raw_documents?select=id,content_hash,canonical_url,title,summary,url,source_name,source_id,published_at,created_at&created_at=gte.${encodeURIComponent(cutoffIso)}&order=created_at.desc`,
      limit
    );
  } catch (error) {
    // W-1: NICHT mehr [] — ein Lesefehler darf nie wie "keine Dokumente" aussehen.
    console.error("[v3Store] listRecentRawDocuments fehlgeschlagen:", error.message);
    throw new StorageReadError("raw_documents", error);
  }
}

// Raw-Dokumente der letzten `days` Tage mit vollem Spaltensatz (fuer den
// Provenienz-Backfill: Clustering + best_source_url-Ableitung). Inert ohne Store.
async function listRawDocuments({ limit = 800, days = 45 } = {}) {
  if (!v3StoreReady()) return [];
  try {
    const cutoffIso = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString();
    // created_at ergaenzt (Betriebsbefund B4): ohne den Einsammel-Zeitpunkt laesst
    // sich der Endzustand eines Rohdokuments nicht gegen eine Karenzzeit pruefen —
    // `published_at` ist der Zeitpunkt der Veroeffentlichung, nicht des Einsammelns,
    // und fehlt bei einem Teil der Zeilen ganz.
    const cols = "id,content_hash,canonical_url,title,summary,url,source_name,source_id,source_type,confidence,link_type,published_at,retrieved_at,created_at,document_type,wahlperiode";
    return await fetchRawDocumentPages(
      `/rest/v1/raw_documents?select=${cols}&created_at=gte.${encodeURIComponent(cutoffIso)}&order=created_at.desc`,
      limit
    );
  } catch (error) {
    // W-1: NICHT mehr [] — ein Lesefehler darf nie wie "keine Dokumente" aussehen.
    console.error("[v3Store] listRawDocuments fehlgeschlagen:", error.message);
    throw new StorageReadError("raw_documents", error);
  }
}

// --- Lebenszyklus-Daten (Betriebsbefund B4, Phase 10) -----------------------
// Genau die drei Mengen, aus denen sich der Endzustand jedes Rohdokuments
// ABLEITEN laesst — ohne neue Tabelle, ohne neue Spalte, ausschliesslich lesend:
// die Rohdokumente eines Fensters, ihre Vorgangs-Verknuepfungen und der Zustand
// der beteiligten Vorgaenge. Auswertung: lib/helmut/vorgangs-lebenszyklus.js.
//
// MANDANTENNEUTRAL: alle drei Tabellen tragen kein `user_id`/`tenant_id` — ein
// Vorgang wird global genau einmal verstanden. Deshalb kein assertTenant; der
// Aufrufer darf daraus auch keine mandantenbezogene Aussage ableiten.
const LEBENSZYKLUS_SEITE = 1000;

async function listKoDocumentLinks({ limit = 4000 } = {}) {
  if (!v3StoreReady()) return [];
  const safeLimit = Number.isFinite(Number(limit)) && Number(limit) > 0 ? Math.floor(Number(limit)) : 4000;
  const out = [];
  try {
    for (let offset = 0; offset < safeLimit; offset += LEBENSZYKLUS_SEITE) {
      const seite = Math.min(LEBENSZYKLUS_SEITE, safeLimit - offset);
      const rows = await supabaseRequest(
        `/rest/v1/ko_document_links?select=knowledge_object_id,raw_document_id,created_at&order=created_at.desc&limit=${seite}&offset=${offset}`
      );
      if (!Array.isArray(rows) || !rows.length) break;
      out.push(...rows);
      if (rows.length < seite) break;
    }
    return out;
  } catch (error) {
    // W-1: bisher wurde hier die TEILMENGE `out` zurueckgegeben — schlimmer als
    // leer, weil unverknuepfte Dokumente dann faelschlich als Nachhol-Kandidaten
    // erschienen (unnoetige KI-Kosten) bzw. Rueckstaende unsichtbar wurden.
    console.error("[v3Store] listKoDocumentLinks fehlgeschlagen:", error.message);
    throw new StorageReadError("ko_document_links", error);
  }
}

// Zustandsfelder ALLER Vorgaenge — standardmaessig OHNE Inhaltsspalten (kein
// Text, kein Embedding): fuer die Endzustandsableitung genuegen Kennung und
// Zustand. `mitUeberschrift` ergaenzt die beiden Titelspalten; sie werden nur
// dort gebraucht, wo ein Bestand ohne verknuepfte Dokumente auf Gleichheit
// geprueft werden muss (Vergleichsmessung alt/neu).
async function listKnowledgeObjectStates({ limit = 4000, mitUeberschrift = false } = {}) {
  if (!v3StoreReady()) return [];
  const safeLimit = Number.isFinite(Number(limit)) && Number(limit) > 0 ? Math.floor(Number(limit)) : 4000;
  const spalten = `id,vorgang_id,status,understanding_status,ko_version,created_at,updated_at${mitUeberschrift ? ",headline,display_title" : ""}`;
  const out = [];
  try {
    for (let offset = 0; offset < safeLimit; offset += LEBENSZYKLUS_SEITE) {
      const seite = Math.min(LEBENSZYKLUS_SEITE, safeLimit - offset);
      const rows = await supabaseRequest(
        `/rest/v1/knowledge_objects?select=${spalten}&order=created_at.desc&limit=${seite}&offset=${offset}`
      );
      if (!Array.isArray(rows) || !rows.length) break;
      out.push(...rows);
      if (rows.length < seite) break;
    }
    return out;
  } catch (error) {
    // W-1: keine stille Teilmenge (siehe listKoDocumentLinks).
    console.error("[v3Store] listKnowledgeObjectStates fehlgeschlagen:", error.message);
    throw new StorageReadError("knowledge_objects", error);
  }
}

// C8: einen Vorgang als KI-Fehlschlag markieren, OHNE Analyse zu speichern.
// status bleibt 'pending' -> Matching (C7a) schliesst ihn weiter aus, er wird
// nie ausgeliefert. understanding_status='failed' parkt ihn (keine Endlos-Retries).
// Nur ein bereits existierendes (pending) KO wird so aktualisiert.
async function markUnderstandingFailed(vorgangId, meta = {}) {
  if (!v3StoreReady()) return { skipped: true, reason: v3SkipReason() };
  if (!vorgangId) return { skipped: true, reason: "missing-vorgang" };
  return saveKnowledgeObject({
    id: `ko-${vorgangId}`,
    vorgang_id: vorgangId,
    status: "pending",
    understanding_status: "failed",
    ...(meta.headline ? { headline: String(meta.headline).slice(0, 300) } : {}),
    ...(meta.understanding_model ? { understanding_model: String(meta.understanding_model).slice(0, 120) } : {})
  });
}

// SQL-Äquivalent: UPDATE knowledge_objects SET understanding_status='pending'
// WHERE understanding_status='failed'. Kein Limit, trifft alle failed KOs.
async function bulkResetUnderstandingFailed() {
  if (!v3StoreReady()) return { skipped: true, reason: v3SkipReason() };
  try {
    await supabaseRequest(
      `/rest/v1/knowledge_objects?understanding_status=eq.failed`,
      { method: "PATCH", headers: { Prefer: "return=minimal" }, body: JSON.stringify({ understanding_status: "pending" }) }
    );
    return { ok: true };
  } catch (error) {
    console.error("[v3Store] bulkResetUnderstandingFailed fehlgeschlagen:", error.message);
    return { skipped: true, reason: error.message };
  }
}

// --- P1-4: begrenzte Recovery fehlgeschlagener Wissensobjekte -------------------
// Primitiven für den bounded Auto-Retry (Orchestrierung in lib/helmut/ko-recovery.js).
// Der Retry-Zähler lebt im kleinen Auth-Store (KEINE Schema-Migration nötig).

// Die aktuell failed (nicht terminal) markierten KOs holen. 'failed-final' wird
// bewusst NICHT geliefert -> nie erneut versucht (Endlosschutz).
async function listFailedKnowledgeObjects({ limit = 50 } = {}) {
  if (!v3StoreReady()) return [];
  try {
    const rows = await supabaseRequest(
      `/rest/v1/knowledge_objects?understanding_status=eq.failed&select=id,vorgang_id,understanding_status,headline&order=updated_at.desc&limit=${Math.max(1, Number(limit) || 50)}`
    );
    return Array.isArray(rows) ? rows : [];
  } catch (error) {
    console.error("[v3Store] listFailedKnowledgeObjects fehlgeschlagen:", error.message);
    return [];
  }
}

// Einen einzelnen Vorgang failed -> pending zuruecksetzen (fuer den naechsten
// Understanding-Lauf). Idempotent.
async function resetUnderstandingToPending(vorgangId) {
  if (!v3StoreReady()) return { skipped: true, reason: v3SkipReason() };
  if (!vorgangId) return { skipped: true, reason: "missing-vorgang" };
  await supabaseRequest(
    `/rest/v1/knowledge_objects?vorgang_id=eq.${encodeURIComponent(vorgangId)}&understanding_status=eq.failed`,
    { method: "PATCH", headers: { Prefer: "return=minimal" }, body: JSON.stringify({ understanding_status: "pending" }) }
  );
  return { ok: true };
}

// Einen Vorgang ENDGUELTIG fehlgeschlagen markieren (failed-final) — nach
// erschoepften Retries. Wird von listFailedKnowledgeObjects/listPending nie wieder
// aufgegriffen. Kein Endlos-Retry.
async function markUnderstandingTerminal(vorgangId) {
  if (!v3StoreReady()) return { skipped: true, reason: v3SkipReason() };
  if (!vorgangId) return { skipped: true, reason: "missing-vorgang" };
  await supabaseRequest(
    `/rest/v1/knowledge_objects?vorgang_id=eq.${encodeURIComponent(vorgangId)}&understanding_status=eq.failed`,
    { method: "PATCH", headers: { Prefer: "return=minimal" }, body: JSON.stringify({ understanding_status: "failed-final" }) }
  );
  return { ok: true };
}

// OP-06: einen Alt-Rueckstands-Vorgang (pending ODER failed) terminal aussortieren.
// KONDITIONALES PATCH auf den erwarteten Vorstatus — hat sich der Status seit der
// Planung geaendert (z. B. inzwischen complete), trifft der Filter 0 Zeilen und es
// wird NICHTS geschrieben. understanding_model traegt die Rollback-Kennung
// (`… | aussortiert:<runId>:<vorstatus>`), vom Aufrufer (pending-terminal.js)
// vorberechnet. Kein Delete, keine weiteren Spalten. Freigabepflichtiger Pfad —
// einziger Aufrufer ist das doppelt gesperrte Aussortier-Skript.
async function markPendingUnderstandingTerminal(vorgangId, { vonStatus, understanding_model } = {}) {
  if (!v3StoreReady()) return { skipped: true, reason: v3SkipReason() };
  if (!vorgangId) return { skipped: true, reason: "missing-vorgang" };
  const prev = vonStatus === "failed" ? "failed" : vonStatus === "pending" ? "pending" : null;
  if (!prev) return { skipped: true, reason: "vonstatus-unzulaessig" };
  const body = { understanding_status: "failed-final" };
  if (understanding_model) body.understanding_model = String(understanding_model).slice(0, 120);
  try {
    const rows = await supabaseRequest(
      `/rest/v1/knowledge_objects?vorgang_id=eq.${encodeURIComponent(vorgangId)}&understanding_status=eq.${prev}`,
      { method: "PATCH", headers: { Prefer: "return=representation" }, body: JSON.stringify(body) }
    );
    return { ok: true, updated: Array.isArray(rows) ? rows.length : 0 };
  } catch (error) {
    console.error("[v3Store] markPendingUnderstandingTerminal fehlgeschlagen:", error.message);
    return { skipped: true, reason: error.message };
  }
}

// Retry-Zähler (vorgangId -> Anzahl) aus dem Auth-Store. Bounded gehalten.
async function getUnderstandingRetries() {
  try {
    const store = await readAuthStore();
    return (store.understandingRetries && typeof store.understandingRetries === "object") ? store.understandingRetries : {};
  } catch (_) { return {}; }
}

async function saveUnderstandingRetries(map = {}) {
  try {
    const store = await readAuthStore();
    // Bounded halten: nur die letzten 1000 Einträge (Vorgänge werden nach Erfolg/
    // Terminal ohnehin entfernt).
    const entries = Object.entries(map || {}).slice(-1000);
    await writeAuthStore({ ...store, understandingRetries: Object.fromEntries(entries) });
    return true;
  } catch (error) {
    console.error("[v3Store] saveUnderstandingRetries fehlgeschlagen:", error && error.message);
    return false;
  }
}

// P29-3 (Fix-Sprint Punkt 29): Vormerkungen gescheiterter/vertagter KO-
// Aktualisierungen (vorgangId -> Zahl der Fehlversuche). Dasselbe Auth-Store-
// Muster wie understandingRetries — KEINE Schema-Migration. Erfolgreiche
// Aktualisierungen raeumen ihren Eintrag auf (lib/helmut/understanding.js).
async function getUpdateRetries() {
  try {
    const store = await readAuthStore();
    return (store.updateRetries && typeof store.updateRetries === "object") ? store.updateRetries : {};
  } catch (_) { return {}; }
}

async function saveUpdateRetries(map = {}) {
  try {
    const store = await readAuthStore();
    // Bounded halten: nur die letzten 1000 Einträge.
    const entries = Object.entries(map || {}).slice(-1000);
    await writeAuthStore({ ...store, updateRetries: Object.fromEntries(entries) });
    return true;
  } catch (error) {
    console.error("[v3Store] saveUpdateRetries fehlgeschlagen:", error && error.message);
    return false;
  }
}

// P1-1 KO-Anreicherung: schreibt gezielt NUR tags und/oder policy_field eines
// Knowledge-Objects (PATCH). Beruehrt KEINE anderen Felder -> kein Ueberschreiben
// von Analyse/Quellen/Inhalten. knowledge_objects ist mandantenlos (service_role).
// Idempotent; Rollback = beide Felder wieder auf '{}' setzen.
async function saveKnowledgeObjectEnrichment(id, patch = {}) {
  if (!v3StoreReady()) return { skipped: true, reason: v3SkipReason() };
  if (!id) return { skipped: true, reason: "no-id" };
  const body = {};
  if (Array.isArray(patch.tags)) body.tags = patch.tags;
  if (Array.isArray(patch.policy_field)) body.policy_field = patch.policy_field;
  // Klassifikations-Backfill (Sprint 2): nur gesetzte Felder patchen (additiv).
  // P1-2 Ebenen-Kanon: politische Ebenen IMMER klein schreiben (bund/land/…),
  // damit Alt-Daten ('Bund') und Neu-Daten ('bund') niemals auseinanderlaufen.
  if (typeof patch.decision_level === "string") body.decision_level = patch.decision_level.trim().toLowerCase();
  if (typeof patch.political_level === "string") body.political_level = patch.political_level.trim().toLowerCase();
  if (typeof patch.event_type === "string") body.event_type = patch.event_type;
  if (Array.isArray(patch.related_levels)) body.related_levels = patch.related_levels.map((l) => (typeof l === "string" ? l.trim().toLowerCase() : l));
  if (Array.isArray(patch.affected_geographies)) body.affected_geographies = patch.affected_geographies;
  if (Array.isArray(patch.mentioned_geographies)) body.mentioned_geographies = patch.mentioned_geographies;
  if (Array.isArray(patch.decision_entities)) body.decision_entities = patch.decision_entities;
  if (Array.isArray(patch.related_entities)) body.related_entities = patch.related_entities;
  if (patch.classification_confidence && typeof patch.classification_confidence === "object") {
    body.classification_confidence = patch.classification_confidence;
  }
  if (Array.isArray(patch.embedding) && patch.embedding.length) body.embedding = formatVector(patch.embedding);
  if (!Object.keys(body).length) return { skipped: true, reason: "no-fields" };
  await supabaseRequest(
    `/rest/v1/knowledge_objects?id=eq.${encodeURIComponent(id)}`,
    { method: "PATCH", headers: { Prefer: "return=minimal" }, body: JSON.stringify(body) }
  );
  return { ok: true, fields: Object.keys(body) };
}

// C7b: gerendertes Briefing pro Nutzer/Slot in die V3-briefings-Tabelle schreiben.
async function saveRenderedBriefingV3(entry = {}, deps = {}) {
  if (entry.slot === "briefing-aussagen") throw new Error("urteilsimport-getrennter-writer-erforderlich");
  if (!v3StoreReady()) return { skipped: true, reason: v3SkipReason() };
  if (!entry.id || !entry.user_id) return { skipped: true, reason: "missing-id-or-user" };
  try {
    if (entry.slot === "lage" && Object.hasOwn(deps, "expectedLage")) {
      const userId = assertTenant(entry.user_id, "saveLageCompareAndSet");
      const before = deps.expectedLage;
      if (before === null) return await insertRenderedBriefingV3(entry);
      if (!before || before.user_id !== userId || before.id !== entry.id || before.slot !== "lage"
        || !(Date.parse(entry.generated_at) > Date.parse(before.generated_at))
        || !require("node:util").isDeepStrictEqual(entry.payload?.vorherigerStand, before))
        throw new Error("lage-bedingter-schreibstand-ungueltig");
      const rows = await tenantRequest(`/rest/v1/briefings?id=eq.${encodeURIComponent(entry.id)}&user_id=eq.${encodeURIComponent(userId)}`
        + `&slot=eq.lage&generated_at=eq.${encodeURIComponent(before.generated_at)}&select=*`, userId, {
        method: "PATCH", headers: { Prefer: "return=representation" },
        body: JSON.stringify({ generated_at: entry.generated_at, payload: entry.payload })
      });
      if (!Array.isArray(rows) || rows.length !== 1 || rows[0].user_id !== userId || rows[0].id !== entry.id)
        throw new Error("lage-schreibkonflikt-oder-status-unklar");
      return { saved: true, id: entry.id };
    }
    const row = {
      id: entry.id,
      user_id: entry.user_id,
      slot: entry.slot || null,
      generated_at: entry.generated_at || new Date().toISOString(),
      payload: entry.payload && typeof entry.payload === "object" ? entry.payload : {}
    };
    // saveRenderedBriefingV3 wird sowohl vom Lage-Prewarm-Cron ALS AUCH inline
    // waehrend eines Live-GET /api/app/start bei Cache-Miss ausgeloest — in
    // beiden Faellen ist es ein praeziser Schreibvorgang auf genau EIN Mandat
    // (entry.user_id), daher unbedenklich fuer den Tenant-JWT-Modus.
    const saved = await v3Upsert("briefings", row, "id", entry.user_id);
    return { saved: true, id: saved.id || entry.id };
  } catch (error) {
    console.error("[v3Store] saveRenderedBriefingV3 fehlgeschlagen:", error.message);
    return { skipped: true, reason: "v3-store-error", error: error.message };
  }
}

// Kontrollierter Nachlauf: fehlenden Tagessatz atomar einfuegen. Ein Rennen
// mit Appstart oder Cron darf einen vorhandenen Text niemals ueberschreiben.
async function insertRenderedBriefingV3(entry = {}, deps = {}) {
  const userId = assertTenant(entry.user_id, "insertRenderedBriefingV3");
  if (!(deps.bereit === undefined ? v3StoreReady() : deps.bereit === true)) throw new Error("briefing-speicher-nicht-bereit");
  if (!entry.id || !["lage", "mandatsbriefing"].includes(entry.slot)) throw new Error("briefing-eintrag-ungueltig");
  const request = deps.request || ((url, options) => tenantRequest(url, userId, options));
  const rows = await request(`/rest/v1/briefings?on_conflict=id&user_id=eq.${encodeURIComponent(userId)}&select=*`, {
    method: "POST", headers: { Prefer: "resolution=ignore-duplicates,return=representation" },
    body: JSON.stringify(entry)
  });
  if (!Array.isArray(rows) || rows.length > 1) throw new Error("briefing-schreibquittung-ungueltig");
  if (!rows.length) return { saved: false, reason: "existing-result" };
  assertTenantRows(rows, "insertRenderedBriefingV3", userId);
  if (rows[0].id !== entry.id) throw new Error("briefing-schreibquittung-abweichend");
  return { saved: true, id: entry.id };
}

// Streng begrenzte fachliche Neuanlage. Weder generischer Upsert noch die
// Writer fuer ausgelieferte Texte duerfen diesen Slot schreiben.
async function insertBriefingFachurteil(entry = {}, deps = {}) {
  const userId = assertTenant(entry.user_id, "insertBriefingFachurteil");
  require("./briefing-urteilsimport").pruefeZeile(entry, deps.result);
  if (!(deps.bereit === undefined ? v3StoreReady() : deps.bereit === true))
    throw new Error("urteilsimport-speicher-nicht-bereit");
  const request = deps.request || ((url, options) => tenantRequest(url, userId, options));
  const rows = await request(`/rest/v1/briefings?on_conflict=id&user_id=eq.${encodeURIComponent(userId)}&select=*`, {
    method: "POST", headers: { Prefer: "resolution=ignore-duplicates,return=representation" },
    body: JSON.stringify(entry)
  });
  if (!Array.isArray(rows) || rows.length > 1) throw new Error("urteilsimport-schreibquittung-ungueltig");
  if (!rows.length) return { saved: false, reason: "existing-result" };
  const r = rows[0];
  if (r.user_id !== userId || r.id !== entry.id || r.slot !== entry.slot
    || Date.parse(r.generated_at) !== Date.parse(entry.generated_at)
    || !require("node:util").isDeepStrictEqual(r.payload, entry.payload))
    throw new Error("urteilsimport-schreibquittung-abweichend");
  return { saved: true, id: entry.id };
}

// Ausschliesslich private Entwurfsbelege; keine Erweiterung des Writers fuer
// ausgelieferte Lage-/Briefing-Slots. Jeder Zugriff bleibt mandatsgebunden.
async function insertLageEntwurfsbeleg(entry = {}, deps = {}) {
  const userId = assertTenant(entry.user_id, "insertLageEntwurfsbeleg");
  if (!(deps.bereit === undefined ? v3StoreReady() : deps.bereit === true)) throw new Error("entwurfsbeleg-speicher-nicht-bereit");
  const p = entry.payload;
  if (entry.slot !== "lage-pruefentwurf" || p?.auslieferbar !== false || p?.qualitaetBestanden !== false
    || !/^nachlauf500-[0-9]{5,20}$/.test(p.runId || "") || !["entwurf", "pruefung"].includes(p.phase)
    || !/^\d{4}-\d{2}-\d{2}$/.test(p.tag || "")
    || entry.id !== `bf-${userId}-lage-pruefentwurf-${p.tag}-${p.runId}-${p.phase}`)
    throw new Error("entwurfsbeleg-eintrag-ungueltig");
  const request = deps.request || ((url, options) => tenantRequest(url, userId, options));
  const rows = await request(`/rest/v1/briefings?on_conflict=id&user_id=eq.${encodeURIComponent(userId)}&select=*`, {
    method: "POST", headers: { Prefer: "resolution=ignore-duplicates,return=representation" }, body: JSON.stringify(entry)
  });
  if (!Array.isArray(rows) || rows.length > 1) throw new Error("entwurfsbeleg-schreibquittung-ungueltig");
  if (!rows.length) return { saved: false, reason: "existing-result" };
  assertTenantRows(rows, "insertLageEntwurfsbeleg", userId);
  if (rows[0].id !== entry.id) throw new Error("entwurfsbeleg-schreibquittung-abweichend");
  return { saved: true, id: entry.id };
}
async function getLageEntwurfsbeleg(userId, id, deps = {}) {
  userId = assertTenant(userId, "getLageEntwurfsbeleg");
  if (!(deps.bereit === undefined ? v3StoreReady() : deps.bereit === true)) throw new Error("entwurfsbeleg-speicher-nicht-bereit");
  if (typeof id !== "string" || !id.startsWith(`bf-${userId}-lage-pruefentwurf-`)) throw new Error("entwurfsbeleg-ziel-ungueltig");
  const request = deps.request || ((url, options) => tenantRequest(url, userId, options));
  const rows = await request(`/rest/v1/briefings?id=eq.${encodeURIComponent(id)}&user_id=eq.${encodeURIComponent(userId)}&slot=eq.lage-pruefentwurf&select=*&limit=2`);
  if (!Array.isArray(rows) || rows.length > 1) throw new Error("entwurfsbeleg-lesequittung-ungueltig");
  assertTenantRows(rows, "getLageEntwurfsbeleg", userId);
  if (rows.length && (rows[0].id !== id || rows[0].slot !== "lage-pruefentwurf")) throw new Error("entwurfsbeleg-lesequittung-abweichend");
  return rows[0] || null;
}

// Nur ein nachweislich unvollstaendiger Briefingstand darf gezielt ergaenzt
// werden. Sein kompletter bisheriger Inhalt bleibt im neuen Payload erhalten.
async function ergaenzeUnvollstaendigesBriefing(before, entry, deps = {}) {
  const userId = assertTenant(entry?.user_id, "ergaenzeUnvollstaendigesBriefing");
  if (!(deps.bereit === undefined ? v3StoreReady() : deps.bereit === true)) throw new Error("briefing-speicher-nicht-bereit");
  if (!before || before.user_id !== userId || before.id !== entry.id || before.slot !== "mandatsbriefing"
    || entry.slot !== before.slot || before.payload?.pruefung?.strukturellVollstaendig !== false
    || !/^[a-f0-9]{64}$/.test(before.payload.inhaltHash || "")
    || !require("node:util").isDeepStrictEqual(entry.payload?.vorherigerStand, before))
    throw new Error("briefing-ergaenzung-nicht-zulaessig");
  const request = deps.request || ((url, options) => tenantRequest(url, userId, options));
  const rows = await request(`/rest/v1/briefings?id=eq.${encodeURIComponent(entry.id)}&user_id=eq.${encodeURIComponent(userId)}`
    + `&slot=eq.mandatsbriefing&generated_at=eq.${encodeURIComponent(before.generated_at)}`
    + `&payload->>inhaltHash=eq.${before.payload.inhaltHash}&select=*`, {
    method: "PATCH", headers: { Prefer: "return=representation" },
    body: JSON.stringify({ generated_at: entry.generated_at, payload: entry.payload })
  });
  if (!Array.isArray(rows) || rows.length !== 1 || rows[0].id !== entry.id || rows[0].user_id !== userId)
    throw new Error("briefing-ergaenzung-konflikt-oder-unklar");
  return { saved: true, id: entry.id };
}

// Nur Testteilnahme; kein saveProfile mit Identitaets-/Kontenschreibvorgaengen.
// Bedingter PATCH schuetzt vor einer seit dem Lesen veraenderten Profilzeile.
async function setTestProfileActive(userId, active, deps = {}) {
  userId = assertTenant(userId, "setTestProfileActive");
  if (!require("./testkohorte-betrieb").istKohortenKennung(userId) || typeof active !== "boolean")
    throw new Error("testprofil-ziel-ungueltig");
  if (!(deps.bereit === undefined ? profileDbExclusiveEnabled() && v3StoreReady() : deps.bereit === true))
    throw new Error("testprofil-speicher-nicht-bereit");
  const request = deps.request || ((url, options) => tenantRequest(url, userId, options));
  const base = "/rest/v1/mandate_profiles?user_id=eq." + encodeURIComponent(userId);
  const before = await request(base + "&select=*&limit=2", { method: "GET" });
  if (!Array.isArray(before) || before.length !== 1 || before[0].user_id !== userId
    || before[0].geloescht_at !== null || typeof before[0].aktiv !== "boolean"
    || !before[0].updated_at || before[0].profil_extras?.provisionedBy !== "helmut-provisioning")
    throw new Error("testprofil-bestand-ungueltig");
  if (before[0].aktiv === active) return { ok: true, geaendert: false };
  const rows = await request(base + "&aktiv=eq." + before[0].aktiv
    + "&updated_at=eq." + encodeURIComponent(before[0].updated_at) + "&geloescht_at=is.null&select=*", {
    method: "PATCH", headers: { Prefer: "return=representation" },
    body: JSON.stringify({ aktiv: active, updated_at: new Date().toISOString() })
  });
  if (!Array.isArray(rows) || rows.length !== 1 || rows[0].user_id !== userId || rows[0].aktiv !== active)
    throw new Error("testprofil-schreibstatus-unklar-keine-wiederholung");
  const after = await request(base + "&select=*&limit=2", { method: "GET" });
  const inhalt = row => { const { aktiv, updated_at, ...rest } = row; return rest; };
  if (!Array.isArray(after) || after.length !== 1 || after[0].aktiv !== active
    || !require("node:util").isDeepStrictEqual(inhalt(before[0]), inhalt(after[0])))
    throw new Error("testprofil-nachkontrolle-fehlgeschlagen");
  return { ok: true, geaendert: true, kontoUnveraendert: true, identitaetUnveraendert: true };
}

// Lage-Briefing-Cache lesen (Gegenstueck zu saveRenderedBriefingV3). Deterministische
// id = bf-<userId>-<slot>-<day>, damit ein bereits erzeugtes Briefing pro Tag/Slot
// wiederverwendet wird (kein KI-Call bei jedem Laden). Inert ohne Store (null).
async function getRenderedBriefingV3(userId, slot, day, opts = {}) {
  if (!v3StoreReady() || !userId || !slot || !day) return null;
  try {
    userId = assertTenant(userId, "getRenderedBriefingV3");
    const id = opts.profilHash === undefined ? `bf-${userId}-${slot}-${day}`
      : require("./briefing-profilkontext").kennung(userId, day, opts.profilHash);
    if (opts.profilHash !== undefined && slot !== "mandatsbriefing") throw new Error("briefing-lesequittung-ungueltig");
    const rows = await tenantRequest(`/rest/v1/briefings?id=eq.${encodeURIComponent(id)}&user_id=eq.${encodeURIComponent(userId)}&select=*&limit=2`, userId);
    if (!Array.isArray(rows) || rows.length > 1) throw new Error("briefing-lesequittung-ungueltig");
    assertTenantRows(rows, "getRenderedBriefingV3", userId);
    if (rows[0] && rows[0].id !== id) throw new Error("briefing-lesequittung-abweichend");
    return Array.isArray(rows) && rows.length ? rows[0] : null;
  } catch (error) {
    if (opts.strict) throw error;
    console.error("[v3Store] getRenderedBriefingV3 fehlgeschlagen:", error.message);
    return null;
  }
}

// GEBUENDELTER Frischebeleg-Lesevorgang fuer MEHRERE Mandate (Watchdog 26.08.).
// Der Gesundheitsbericht braucht je Mandat zwei Belegzeilen (Erfolg/Fehler). Einzeln
// gelesen waeren das 2xN Abfragen — bei 100 Mandaten 200. Hier ist es EINE Abfrage je
// Stapel von 100 Zeilenkennungen, also 2 Abfragen bei 100 Mandaten.
//
// MANDANTENTRENNUNG (CLAUDE.md §4.1): die Mandatsliste wird EXPLIZIT aufgezaehlt —
// kein `select *` ueber alle Mandanten, kein stiller Rueckfall. Jede Kennung laeuft
// durch assertTenant, die Abfrage filtert zusaetzlich auf `user_id=in.(...)`, und der
// Aufrufer prueft JEDE Zeile erneut gegen Mandat und Berliner Tag
// (briefing-lauf.ausZeile verwirft eine fremde Zeile und protokolliert das).
// Die Stapelgrenze ist bewusst gesetzt: eine `in.()`-Liste waechst in der URL, und
// eine zu lange URL wuerde als 414 scheitern statt ehrlich zu lesen.
async function listRenderedBriefingsV3ForTenants(tenantIds = [], slots = [], day = null) {
  if (!v3StoreReady() || !day) return [];
  const ids = [...new Set((Array.isArray(tenantIds) ? tenantIds : [])
    .map((t) => assertTenant(t, "listRenderedBriefingsV3ForTenants")))];
  const slotListe = [...new Set((Array.isArray(slots) ? slots : []).filter(Boolean).map(String))];
  if (!ids.length || !slotListe.length) return [];
  const zeilenIds = [];
  for (const t of ids) for (const sl of slotListe) zeilenIds.push(`bf-${t}-${sl}-${day}`);
  const nutzerListe = ids.map((t) => `"${t}"`).join(",");
  const out = [];
  const stapel = 100;
  for (let i = 0; i < zeilenIds.length; i += stapel) {
    const teil = zeilenIds.slice(i, i + stapel).map((x) => `"${x}"`).join(",");
    const rows = await supabaseRequest(
      `/rest/v1/briefings?id=in.(${encodeURIComponent(teil)})`
      + `&user_id=in.(${encodeURIComponent(nutzerListe)})&select=*`
    );
    if (Array.isArray(rows)) out.push(...rows);
  }
  return out;
}

// Push-Uebersicht eines Mandanten aus EINEM Speicherzugriff: Ereignisse UND Abos
// liegen im selben Mandantenspeicher (`pKey`). Getrennt gelesen waere das ein
// zweiter Zugriff je Mandat, ohne dass er etwas Neues sehen wuerde.
async function getPushUebersicht(politicianId, { limit = 200 } = {}) {
  const tenantId = assertTenant(politicianId, "getPushUebersicht"); // Sprint-1-Haertung
  const pStore = await readStore(pKey(tenantId));
  return pushUebersichtAusSpeicher(pStore, tenantId, { limit });
}

// Provenienz (C6/C7): die Quell-Dokumente eines Vorgangs mit dem KO verknuepfen.
// Sichert zuerst die raw_documents (idempotent, FK-Ziel von ko_document_links),
// dann die N:M-Kanten. Erst dadurch liefert getSourcesForVorgang echte Quellen,
// Chronologie und Dokumente. Inert ohne Store (kein Crash).
async function saveKoDocumentLinks(knowledgeObjectId, rawDocuments = []) {
  if (!v3StoreReady()) return { skipped: true, reason: v3SkipReason(), saved: 0 };
  if (!knowledgeObjectId) return { skipped: true, reason: "missing-ko", saved: 0 };
  const docs = (Array.isArray(rawDocuments) ? rawDocuments : []).filter((d) => d && d.id);
  if (!docs.length) return { skipped: true, reason: "no-documents", saved: 0 };
  try {
    const docRows = docs.map((d) => pickColumns(d, V3_RAW_DOCUMENT_COLUMNS)).filter((r) => r.id);
    if (docRows.length) await ensureRawDocumentsForLinks(docRows);
    const links = docs.map((d) => ({ knowledge_object_id: knowledgeObjectId, raw_document_id: d.id }));
    await v3Upsert("ko_document_links", links, "knowledge_object_id,raw_document_id");
    return { saved: links.length };
  } catch (error) {
    console.error("[v3Store] saveKoDocumentLinks fehlgeschlagen:", error.message);
    return { skipped: true, reason: "v3-store-error", error: error.message, saved: 0 };
  }
}

// Quellenmetadaten fuer das bereits begrenzte Lagefenster. Keine neuen Quellen,
// keine Modelltexte und kein groesserer KO Scan. Der Zeitfilter liegt auf der
// echten Publikation; !inner entfernt Verknuepfungen ohne passende Rohquelle.
// Bestehende globale KO Tabellen enthalten keine Mandatsdaten. Die persoenliche
// Trefferliste wird weiterhin ausschliesslich mit verpflichtendem userId gelesen.
async function listAktuelleLageQuellen(ids = [], jetzt = new Date(), deps = {}) {
  const liste = [...new Set(ids)].sort();
  if (!liste.length) return [];
  const ready = deps.ready || v3StoreReady, request = deps.request || supabaseRequest;
  try {
    if (!ready()) throw new Error("v3-store nicht bereit");
    if (liste.some(id => typeof id !== "string" || !id)) throw new Error("ungueltige-kennung");
    const ende = new Date(jetzt).toISOString();
    const beginn = new Date(Date.parse(ende) - require("./briefing-frische").relevanzTage() * 86400000).toISOString();
    const select = "knowledge_object_id,raw_documents!inner(id,title,url,canonical_url,published_at)";
    const out = [], gesehen = new Set();
    for (let i = 0; i < liste.length; i += KO_ID_STAPEL) {
      const teil = liste.slice(i, i + KO_ID_STAPEL);
      const inList = teil.map(id => `"${encodeURIComponent(id)}"`).join(",");
      const base = `/rest/v1/ko_document_links?select=${select}&knowledge_object_id=in.(${inList})`
        + `&raw_documents.published_at=gte.${encodeURIComponent(beginn)}`
        + `&raw_documents.published_at=lte.${encodeURIComponent(ende)}&order=knowledge_object_id.asc,raw_document_id.asc`;
      for (let offset = 0; ; offset += RAW_DOC_SEITE) {
        const rows = await request(`${base}&limit=${RAW_DOC_SEITE}&offset=${offset}`);
        if (!Array.isArray(rows) || rows.length > RAW_DOC_SEITE) throw new Error("ungueltige-quellenantwort");
        // Obergrenze entspricht 40 Quellen je Kennung im bestehenden Leser.
        // Ueberlauf wird laut verworfen, niemals als vollstaendige Menge geliefert.
        if (offset + rows.length > KO_ID_STAPEL * 40) throw new Error("lage-quellen-lesegrenze");
        for (const r of rows) {
          const key = r?.knowledge_object_id + "|" + r?.raw_documents?.id;
          if (!teil.includes(r?.knowledge_object_id) || typeof r?.raw_documents?.id !== "string"
            || gesehen.has(key)) throw new Error("ungueltige-quellenantwort");
          gesehen.add(key); out.push(r);
        }
        if (rows.length < RAW_DOC_SEITE) break;
      }
    }
    return out;
  } catch (cause) { throw new StorageReadError("lage-quellen", cause); }
}

// Die Originalquellen eines Vorgangs: ko_document_links -> raw_documents (PostgREST-
// Embedding ueber den FK), nach published_at absteigend. Backt Quellen (N),
// Chronologie und Dokumente im Vorgang-Detail. Inert ohne Store ([]).
async function getSourcesForVorgang(vorgangId, { limit = 40, lageQuellen = null, lageKoId = null } = {}) {
  if (lageQuellen !== null) return getGebundeneLageQuellen(vorgangId, lageKoId, lageQuellen);
  if (!v3StoreReady() || !vorgangId) return [];
  try {
    const koId = `ko-${vorgangId}`;
    const select = "raw_documents(id,title,url,canonical_url,source_name,source_type,published_at,document_type,link_type,confidence,summary)";
    const rows = await supabaseRequest(
      `/rest/v1/ko_document_links?knowledge_object_id=eq.${encodeURIComponent(koId)}&select=${select}&limit=${limit}`
    );
    const docs = (Array.isArray(rows) ? rows : []).map((r) => r && r.raw_documents).filter(Boolean);
    docs.sort((a, b) => String(b.published_at || "").localeCompare(String(a.published_at || "")));
    return docs;
  } catch (error) {
    console.error("[v3Store] getSourcesForVorgang fehlgeschlagen:", error.message);
    return [];
  }
}

// Nur die bereits ausgewaehlten Lagebelege. Die N:M-Verknuepfung wird erneut
// mitgelesen: getRawDocumentsByIds allein bestaetigt die Vorgangsbindung nicht.
// Ein verschwundener oder geaenderter Beleg ist eine Stoerung, kein Leerzustand.
async function getGebundeneLageQuellen(vorgangId, koId, erwartet) {
  try {
    if (!v3StoreReady() || typeof vorgangId !== "string" || !vorgangId || typeof koId !== "string" || !koId
      || !Array.isArray(erwartet) || !erwartet.length || erwartet.length > require("./lage-quellenbeleg").MAX_BELEGE
      || erwartet.some(d => !d || typeof d.id !== "string" || !d.id)
      || new Set(erwartet.map(d => d.id)).size !== erwartet.length) throw new Error("ungueltige-lage-quellenbindung");
    const byId = new Map(erwartet.map(d => [d.id, d]));
    const select = "knowledge_object_id,raw_document_id,raw_documents!inner(id,title,url,canonical_url,source_name,source_type,published_at,document_type,link_type,confidence,summary)";
    const rows = await supabaseRequest(`/rest/v1/ko_document_links?knowledge_object_id=eq.${encodeURIComponent(koId)}`
      + `&raw_document_id=in.(${erwartet.map(d => encodeURIComponent(JSON.stringify(d.id))).join(",")})&select=${select}`
      + `&order=raw_document_id.asc&limit=${erwartet.length + 1}`);
    if (!Array.isArray(rows) || rows.length !== erwartet.length) throw new Error("lage-quellenbindung-unvollstaendig");
    const gelesen = new Map();
    for (const r of rows) {
      const d = r?.raw_documents, vor = byId.get(r?.raw_document_id);
      if (r?.knowledge_object_id !== koId || !vor || !d || Array.isArray(d)
        || d.id !== vor.id || gelesen.has(d.id)
        || ["title", "url", "canonical_url", "published_at"].some(f => String(d[f] || "") !== String(vor[f] || "")))
        throw new Error("lage-quellenbindung-abweichend");
      gelesen.set(d.id, d);
    }
    return erwartet.map(d => gelesen.get(d.id));
  } catch (cause) { throw new StorageReadError("lage-quellenbindung", cause); }
}

// --- Helmut Core V3 — C9: Buero-Engine-Outputs (hinter HELMUT_V3_OFFICE) -------
// Speichert / liest generierte Kommunikations-Outputs (Rede, PM, Social usw.).
// Inert wenn v3StoreReady() false ist. Idempotent: PK = office-{userId}-{vorgangId}-{channel}.
// DSGVO: kein Freitext-Prompt, keine PII ausser user_id (RLS-geschuetzt).

const V3_OFFICE_OUTPUT_COLUMNS = ["id", "user_id", "knowledge_object_id", "decision_id", "channel", "content", "model"];

function officeOutputId(userId, vorgangId, channel) {
  return `office-${userId}-${vorgangId}-${channel}`.slice(0, 200);
}

function officeDailyLimit() {
  const raw = Number(process.env.HELMUT_OFFICE_DAILY_LIMIT);
  return Number.isFinite(raw) && raw > 0 ? Math.floor(raw) : 10;
}

async function saveOfficeOutput(entry = {}) {
  if (!v3StoreReady()) return { skipped: true, reason: v3SkipReason() };
  if (!entry.id || !entry.user_id || !entry.channel || !entry.content) {
    return { skipped: true, reason: "missing-fields" };
  }
  try {
    // Live-Nutzer-Schreibpfad (POST /api/office/generate) -> tenantId durchreichen,
    // damit v3Upsert bei aktiviertem Tenant-JWT-Modus authenticated statt
    // service_role nutzt (sonst unveraendert).
    const saved = await v3Upsert("office_outputs", pickColumns(entry, V3_OFFICE_OUTPUT_COLUMNS), "id", entry.user_id);
    return { saved: true, id: saved.id || entry.id };
  } catch (error) {
    console.error("[v3Store] saveOfficeOutput fehlgeschlagen:", error.message);
    return { skipped: true, reason: "v3-store-error" };
  }
}

async function getOfficeOutput(userId, vorgangId, channel) {
  assertTenant(userId, "getOfficeOutput");
  if (!v3StoreReady() || !vorgangId || !channel) return null;
  const id = officeOutputId(userId, vorgangId, channel);
  try {
    const rows = await tenantRequest(`/rest/v1/office_outputs?id=eq.${encodeURIComponent(id)}&select=*&limit=1`, userId);
    return Array.isArray(rows) && rows.length ? rows[0] : null;
  } catch (error) {
    console.error("[v3Store] getOfficeOutput fehlgeschlagen:", error.message);
    return null;
  }
}

async function listOfficeOutputsByUser(userId, vorgangId = null, deps = {}) {
  const uid = assertTenant(userId, "listOfficeOutputsByUser");
  const ready = deps.ready || v3StoreReady;
  // Aktuell kein Produktionsaufrufer (siehe docs/auth-service-role-matrix.md),
  // aus Konsistenz dennoch auf tenantRequest umgestellt. deps.request (Tests) hat Vorrang.
  const request = deps.request || ((endpoint) => tenantRequest(endpoint, uid));
  if (!ready()) return [];
  try {
    const koFilter = vorgangId ? `&knowledge_object_id=eq.${encodeURIComponent(`ko-${vorgangId}`)}` : "";
    const rows = await request(
      `/rest/v1/office_outputs?user_id=eq.${encodeURIComponent(uid)}${koFilter}&select=*&order=created_at.desc&limit=50`
    );
    return Array.isArray(rows) ? rows : [];
  } catch (error) {
    console.error("[v3Store] listOfficeOutputsByUser fehlgeschlagen:", error.message);
    return [];
  }
}

// Rate-Gate: Wie viele Office-Outputs hat dieser Nutzer heute generiert?
// Fail-OPEN: Bei Fehler oder fehlendem Store -> immer erlaubt (inert ohne DB).
async function canSpendOfficeOutput(userId, referenceIso = null) {
  assertTenant(userId, "canSpendOfficeOutput");
  const limit = officeDailyLimit();
  if (!v3StoreReady()) return { allowed: true, used: 0, limit, remaining: limit };
  try {
    const today = dayKey(referenceIso || new Date().toISOString());
    const todayNum = Number(today.slice(8, 10));
    const tomorrow = `${today.slice(0, 8)}${String(todayNum + 1).padStart(2, "0")}`;
    const rows = await tenantRequest(
      `/rest/v1/office_outputs?select=id&user_id=eq.${encodeURIComponent(userId)}&created_at=gte.${today}T00:00:00Z&created_at=lt.${tomorrow}T00:00:00Z&limit=${limit + 1}`,
      userId
    );
    const used = Array.isArray(rows) ? rows.length : 0;
    return { allowed: used < limit, used, limit, remaining: Math.max(0, limit - used) };
  } catch (_) {
    return { allowed: true, used: null, limit, remaining: null, reason: "check-failed-open" };
  }
}

const SUPABASE_REQUEST_TIMEOUT_MS = Number(process.env.HELMUT_SUPABASE_TIMEOUT_MS) || 10000;

// Kein Timeout hier bedeutete: ein einzelner haengender Supabase-Call (Netz-Hänger,
// Cold-Start, DNS) blockiert den kompletten aufrufenden Request unbegrenzt (bis zum
// Vercel-Function-Limit) -> z.B. /api/app/start liefert nie eine Antwort und die App
// startet scheinbar nicht. Die Frist umfasst auch den Antwortinhalt: fetch ist
// schon nach den Headern erfuellt, response.text() kann danach noch haengen.
//
// Gemeinsamer Fetch-Kern fuer BEIDE Identitaeten (service_role UND tenant-JWT,
// P0-2-Folgearbeit "Sprint 3"). Reines Refactoring der vorherigen supabaseRequest-
// Funktion — Verhalten fuer bestehende Aufrufer (Headers, Timeout, Fehler-Redaction)
// ist UNVERAENDERT, nur der Header-Aufbau ist jetzt austauschbar.
async function performSupabaseFetch(endpoint, headers, options = {}) {
  if (typeof fetch !== "function") {
    throw new Error("Supabase storage needs Node fetch. Use Node 18+ or Vercel runtime.");
  }
  const baseUrl = String(process.env.SUPABASE_URL || "").replace(/\/+$/, "");
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), SUPABASE_REQUEST_TIMEOUT_MS);
  try {
    const response = await fetch(`${baseUrl}${endpoint}`, { ...options, signal: controller.signal, headers });
    if (!response.ok) {
      const rawBody = await response.text().catch((error) => {
        // Ein Timeout beim Fehlerinhalt muss den gleichen begrenzten Fehlerpfad
        // nehmen wie ein Timeout beim erfolgreichen Inhalt.
        if (error && error.name === "AbortError") throw error;
        return "";
      });
      // SICHERHEIT: PostgREST/Postgres-Fehlertexte koennen bei NOT-NULL-/CHECK-Verletzungen
      // "Failing row contains (spalte1, spalte2, ...)" mit dem KOMPLETTEN Zeileninhalt
      // enthalten (nicht nur der verletzten Spalte) — das landet sonst ungefiltert in ~20
      // console.error-Aufrufen und teils im Rueckgabewert. Betroffene Tabellen koennen
      // besondere Kategorien nach Art. 9 DSGVO enthalten (politische Inhalte). Daher hier
      // am zentralen Punkt kappen + die bekannten Muster entfernen, bevor der Fehler ueberhaupt
      // entsteht.
      const body = String(rawBody || "")
        .replace(/Failing row contains \([^)]*\)/gi, "Failing row contains (redacted)")
        .replace(/Key \([^)]*\)=\([^)]*\)/gi, "Key (redacted)")
        .slice(0, 200);
      throw new Error(`Supabase storage failed (${response.status}): ${body || response.statusText}`);
    }

    if (response.status === 204) return null;
    const text = await response.text();
    return text ? JSON.parse(text) : null;
  } catch (error) {
    if (error && error.name === "AbortError") {
      throw new Error(`Supabase storage timed out after ${SUPABASE_REQUEST_TIMEOUT_MS}ms: ${endpoint}`);
    }
    throw error;
  } finally {
    clearTimeout(timeoutId);
  }
}

// service_role — unveraendertes Verhalten, weiterhin der Default fuer ALLE
// Backend-/Cron-Pfade (Crawl, Understanding, Matching-/Decision-Shadow,
// Profil-Embeddings) und fuer jeden Aufrufer ohne Tenant-JWT-Modus.
async function supabaseRequest(endpoint, options = {}) {
  const serviceRoleKey = supabaseServiceRoleKey();
  return performSupabaseFetch(
    endpoint,
    {
      apikey: serviceRoleKey,
      Authorization: `Bearer ${serviceRoleKey}`,
      "Content-Type": "application/json",
      ...(options.headers || {})
    },
    options
  );
}

function supabaseServiceRoleKey() {
  return process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_SERVICE_KEY || process.env.SUPABASE_SECRET_KEY || "";
}

// ── P0-2-Folgearbeit ("Sprint 3"): Tenant-JWT-Modus ─────────────────────────
// Zweite Halfte der Defense-in-Depth aus audit/fix-plan.md P0-2: die in
// supabase/migrations/20260712_tenant_rls_policies.sql entworfenen RLS-Policies
// greifen erst, wenn Requests mit der Rolle 'authenticated' + einem pro Request
// signierten JWT (Claim user_id) laufen statt mit dem RLS-umgehenden service_role.
// Default AUS (wie jedes andere HELMUT_V3_*-Flag) — bei fehlendem Flag oder
// fehlender Konfiguration ist dieser gesamte Block ein No-Op, JEDER Aufrufer
// faellt transparent auf supabaseRequest (service_role, unveraendertes
// Verhalten) zurueck. Betrifft NUR die klar abgegrenzten, bereits P0-1-Tenant-
// gescopten Live-Lesepfade (siehe docs/auth-service-role-matrix.md) — NICHT die
// Backend-/Cron-Bulk-Schreibpfade (saveDecisions/saveMatchingResults/
// saveProfileEmbedding) und NICHT den helmut_store-Blob (dokumentierte Luecke,
// eigener Folgeschritt).

// STILLGELEGT (2026-07-13): Das Supabase-Projekt hat von der Legacy-JWT-Secret-
// Signierung (symmetrisch, HS256) auf das neue Signing-Keys-System (asymmetrisch,
// RSA/EC) umgestellt. PostgREST verifiziert eingehende JWTs jetzt gegen den
// asymmetrischen Public-Key-Satz (JWKS); ein selbst signiertes HS256-Token hat
// dort keinen passenden Schluesseltyp und wird HART abgelehnt:
//   PGRST301 "None of the keys was able to decode the JWT" /
//            "No suitable key or wrong key type".
// Der private Schluessel des aktiven Signing-Keys liegt bei Supabase und wird nie
// exportiert -> eine App KANN kein von PostgREST akzeptiertes Token mehr selbst
// signieren (belegt: getProfileFromDb 401, secretMatchesLegacy=null, anon-Key ist
// jetzt der moderne publishable Key). Der offiziell unterstuetzte Weg fuer einen
// vertrauenswuerdigen Backend-Dienst, der den Mandanten serverseitig waehlt, ist
// service_role + verpflichtendes App-seitiges Tenant-Scoping (jeder Read ist auf
// die eigene id=eq.<tenant> gefiltert) — exakt das Muster, das der gesamte Rest
// der App bereits nutzt. Daher ist der Selbst-Signier-Pfad dauerhaft inert: es
// werden KEINE selbst gebauten Tokens mehr erzeugt, tenantRequest nutzt immer
// service_role. signTenantJWT/verifyTenantJWT bleiben nur fuer Tests/Historie.
// Reaktivierung erst mit echtem Supabase-Auth (GoTrue-Tokens, vom aktiven Key
// signiert) — eigener, groesserer Schritt (siehe docs).
function tenantJwtModeEnabled() {
  return false;
}

function base64url(input) {
  return Buffer.from(input).toString("base64url");
}

// Kurzlebiges (Default 60s), pro Aufruf frisch signiertes HS256-JWT mit dem
// Tenant-Claim 'user_id'. Kein externes Package (Node-crypto genuegt fuer HS256).
// PostgREST validiert dieses Token bei einem echten Supabase-Projekt gegen
// dasselbe Secret (Auth > JWT Settings) und setzt daraus die Rolle +
// request.jwt.claims-GUC, gegen die die RLS-Policies (auth.jwt()->>'user_id')
// pruefen. Liefert null, wenn Secret oder Tenant fehlt (Aufrufer MUSS das
// pruefen -> siehe tenantRequest).
function signTenantJWT(tenantId, opts = {}) {
  const secret = process.env.SUPABASE_JWT_SECRET || "";
  if (!secret || !tenantId) return null;
  // Jeder endliche Wert wird uebernommen (auch <=0, z.B. fuer Tests, die
  // gezielt ein bereits abgelaufenes Token erzeugen wollen) — nur bei
  // fehlendem/nicht-numerischem opts.ttlSeconds greift der 60s-Default.
  const ttlSeconds = Number.isFinite(Number(opts.ttlSeconds)) ? Number(opts.ttlSeconds) : 60;
  const nowSec = Math.floor(Date.now() / 1000);
  const header = { alg: "HS256", typ: "JWT" };
  const payload = {
    role: "authenticated",
    user_id: String(tenantId),
    iss: "helmut-app",
    iat: nowSec,
    exp: nowSec + ttlSeconds
  };
  const signingInput = `${base64url(JSON.stringify(header))}.${base64url(JSON.stringify(payload))}`;
  const signature = crypto.createHmac("sha256", secret).update(signingInput).digest("base64url");
  return `${signingInput}.${signature}`;
}

// Serverseitige Verifikation (fuer Tests + Dokumentation des Mechanismus).
// In Produktion verifiziert PostgREST das Token selbst gegen dasselbe Secret —
// diese Funktion bildet exakt denselben Algorithmus nach (HS256, exp-Pruefung,
// timing-safe Signaturvergleich) und wird NICHT im Request-Pfad der App
// aufgerufen (die App vertraut PostgREST/Supabase als Verifizierer).
function verifyTenantJWT(token, secretOverride) {
  const secret = secretOverride || process.env.SUPABASE_JWT_SECRET || "";
  if (!secret) return { valid: false, reason: "missing-secret" };
  if (typeof token !== "string" || !token) return { valid: false, reason: "missing-token" };
  const parts = token.split(".");
  if (parts.length !== 3) return { valid: false, reason: "malformed" };
  const [h, p, s] = parts;
  let expectedSig;
  try {
    expectedSig = crypto.createHmac("sha256", secret).update(`${h}.${p}`).digest("base64url");
  } catch (error) {
    return { valid: false, reason: "sign-error", error: error.message };
  }
  const sigBuf = Buffer.from(String(s));
  const expBuf = Buffer.from(expectedSig);
  if (sigBuf.length !== expBuf.length || !crypto.timingSafeEqual(sigBuf, expBuf)) {
    return { valid: false, reason: "bad-signature" };
  }
  let payload;
  try {
    payload = JSON.parse(Buffer.from(p, "base64url").toString("utf8"));
  } catch (error) {
    return { valid: false, reason: "bad-payload" };
  }
  const nowSec = Math.floor(Date.now() / 1000);
  if (typeof payload.exp === "number" && payload.exp < nowSec) {
    return { valid: false, reason: "expired", payload };
  }
  return { valid: true, payload };
}

// Admin-Diagnose fuer den PGRST301-Fall (Profil-Lesepfad). Belegt OHNE jede
// Secret-Ausgabe, ob unser HS256-Tenant-JWT noch zum aktiven Supabase-Signing-
// System passt. Gibt ausschliesslich Booleans/Algorithmus zurueck — NIE einen
// Secret-Wert. Kernidee: der oeffentliche anon-Key ist selbst ein HS256-JWT,
// das Supabase mit dem aktiven Legacy JWT Secret signiert hat. Verifiziert
// unser konfiguriertes SUPABASE_JWT_SECRET dessen Signatur, IST es das aktive
// Legacy Secret (=> HS256 korrekt, Ursache liegt woanders); verifiziert es sie
// nicht, ist der Secret-WERT die Ursache des 401/PGRST301.
//   secretMatchesLegacy: true/false/null (null = nicht bestimmbar, z.B. Secret
//     oder HS256-anon-Key fehlt lokal)
//   jwtAlgorithm: der alg-Header UNSERES erzeugten Tenant-Tokens (was die App
//     an PostgREST sendet), z.B. "HS256"; null wenn nicht signierbar.
function diagnoseTenantJwt() {
  const secret = process.env.SUPABASE_JWT_SECRET || "";
  const anonKey = process.env.SUPABASE_ANON_KEY || "";
  let jwtAlgorithm = null;
  try {
    const token = signTenantJWT("diagnose-probe", { ttlSeconds: 1 });
    if (token) {
      const header = JSON.parse(Buffer.from(token.split(".")[0], "base64url").toString("utf8"));
      jwtAlgorithm = header.alg || null;
    }
  } catch (_) { /* jwtAlgorithm bleibt null */ }
  let secretMatchesLegacy = null;
  // Nur mit HS256-Legacy-anon-JWT (eyJ...) als Referenz moeglich, nicht mit einem
  // modernen publishable Key (sb_...).
  if (secret && anonKey && !anonKey.startsWith("sb_")) {
    const parts = anonKey.split(".");
    if (parts.length === 3) {
      try {
        const header = JSON.parse(Buffer.from(parts[0], "base64url").toString("utf8"));
        if (header.alg === "HS256") {
          const expected = crypto.createHmac("sha256", secret).update(`${parts[0]}.${parts[1]}`).digest("base64url");
          const a = Buffer.from(String(parts[2]));
          const b = Buffer.from(expected);
          secretMatchesLegacy = a.length === b.length && crypto.timingSafeEqual(a, b);
        }
      } catch (_) { /* secretMatchesLegacy bleibt null */ }
    }
  }
  return { secretMatchesLegacy, jwtAlgorithm };
}

// authenticated-Rolle — nur genutzt, wenn tenantJwtModeEnabled() UND ein
// tenantId vorliegt (siehe tenantRequest). apikey ist der publishable
// SUPABASE_ANON_KEY (NICHT service_role) — Supabase/PostgREST leitet die
// tatsaechliche Rolle aus dem 'role'-Claim im signierten JWT ab.
async function supabaseAuthenticatedRequest(endpoint, tenantId, options = {}) {
  const token = signTenantJWT(tenantId);
  if (!token) {
    throw new Error("supabaseAuthenticatedRequest: JWT konnte nicht signiert werden (SUPABASE_JWT_SECRET/tenantId fehlt)");
  }
  const anonKey = process.env.SUPABASE_ANON_KEY || "";
  return performSupabaseFetch(
    endpoint,
    {
      apikey: anonKey,
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
      ...(options.headers || {})
    },
    options
  );
}

// Zentrale Weiche: tenant-JWT wenn aktiviert+konfiguriert+tenantId vorhanden,
// sonst transparent service_role (unveraendertes Verhalten). Das ist die
// EINZIGE Stelle, an der diese Entscheidung getroffen wird — die 8 dafuer
// vorgesehenen Funktionen (siehe docs/auth-service-role-matrix.md) rufen
// ausschliesslich tenantRequest()/tenantUpsert() auf, nie direkt supabaseRequest.
function tenantRequest(endpoint, tenantId, options = {}) {
  if (tenantJwtModeEnabled() && tenantId) {
    return supabaseAuthenticatedRequest(endpoint, tenantId, options);
  }
  return supabaseRequest(endpoint, options);
}

function normalizeStore(store = {}) {
  const parsed = { ...defaultStore(), ...store };
  return {
    ...parsed,
    sources: mergeSources(parsed.sources),
    profiles: parsed.profiles || {},
    rawItems: Array.isArray(parsed.rawItems) ? parsed.rawItems : [],
    briefings: Array.isArray(parsed.briefings) ? parsed.briefings : [],
    crawlRuns: Array.isArray(parsed.crawlRuns) ? parsed.crawlRuns : [],
    tasks: Array.isArray(parsed.tasks) ? parsed.tasks : [],
    interactions: Array.isArray(parsed.interactions) ? parsed.interactions : [],
    topicMemory: Array.isArray(parsed.topicMemory) ? parsed.topicMemory : [],
    mandateProfiles: parsed.mandateProfiles || {},
    politicalItems: Array.isArray(parsed.politicalItems) ? parsed.politicalItems : [],
    personalizedRecommendations: Array.isArray(parsed.personalizedRecommendations) ? parsed.personalizedRecommendations : [],
    dailyTasks: Array.isArray(parsed.dailyTasks) ? parsed.dailyTasks : [],
    communicationDrafts: Array.isArray(parsed.communicationDrafts) ? parsed.communicationDrafts : [],
    userNotes: Array.isArray(parsed.userNotes) ? parsed.userNotes : [],
    priorityChanges: Array.isArray(parsed.priorityChanges) ? parsed.priorityChanges : [],
    lageChecks: Array.isArray(parsed.lageChecks) ? parsed.lageChecks : [],
    pushSubscriptions: Array.isArray(parsed.pushSubscriptions) ? parsed.pushSubscriptions : [],
    pushEvents: Array.isArray(parsed.pushEvents) ? parsed.pushEvents : [],
    pipelineDebugReports: Array.isArray(parsed.pipelineDebugReports) ? parsed.pipelineDebugReports : [],
    users: Array.isArray(parsed.users) ? parsed.users : [],
    sessions: Array.isArray(parsed.sessions) ? parsed.sessions : [],
    assignments: Array.isArray(parsed.assignments) ? parsed.assignments : [],
    dailyInputs: Array.isArray(parsed.dailyInputs) ? parsed.dailyInputs : [],
    auditEvents: Array.isArray(parsed.auditEvents) ? parsed.auditEvents : [],
    systemErrors: Array.isArray(parsed.systemErrors) ? parsed.systemErrors : [],
    adminSettings: parsed.adminSettings && typeof parsed.adminSettings === "object" ? parsed.adminSettings : {}
  };
}

// Behaelt die neuesten Eintraege PRO MANDAT (politicianId bzw. user_id), statt
// global zu kappen. Verhindert, dass viele Mandate sich gegenseitig die Daten
// verdraengen. Ein Gesamtlimit deckelt zusaetzlich die Blob-Groesse.
function keepLatestPerOwner(items, primaryDate, fallbackDate, perOwnerLimit, totalLimit) {
  const sorted = sortByDate(items, primaryDate, fallbackDate);
  const counts = new Map();
  const kept = [];
  for (const item of sorted) {
    const owner = item?.politicianId ?? item?.user_id ?? "__shared__";
    const used = counts.get(owner) || 0;
    if (used >= perOwnerLimit) continue;
    counts.set(owner, used + 1);
    kept.push(item);
    if (totalLimit && kept.length >= totalLimit) break;
  }
  return kept;
}

// homeSections wird beim Lesen ohnehin auf <=3 Eintraege pro Sektion eingedampft
// (server.js compactHomeSections). Die volle, mehrere zehn KB grosse Variante zu
// persistieren ist reine Blob-Last ohne Output-Unterschied. Wir trimmen daher schon
// beim Speichern auf die ausgelieferte Groesse.
const HOME_SECTION_KEYS = [
  "topTasks", "changedSinceLastVisit", "needsAttention", "opportunities",
  "risks", "situational", "governmentPlans", "partyFaction"
];

function compactStoredBriefing(briefing) {
  if (!briefing || typeof briefing !== "object" || !briefing.homeSections) return briefing;
  const trimmed = {};
  for (const key of HOME_SECTION_KEYS) {
    if (Array.isArray(briefing.homeSections[key])) {
      trimmed[key] = briefing.homeSections[key].slice(0, 3);
    } else if (briefing.homeSections[key] !== undefined) {
      trimmed[key] = briefing.homeSections[key];
    }
  }
  return { ...briefing, homeSections: { ...briefing.homeSections, ...trimmed } };
}

// P0-2 (Beobachtbarkeit + DSGVO-Datensparsamkeit): compactStore verwendet fuer
// crawlRuns bewusst eine ALLOWLIST — es wird nur explizit benanntes, technisches
// Diagnose-Feld persistiert, alles andere wird beim Speichern verworfen. So kann
// keine spaeter am Lauf-Objekt haengende PII/kein Volltext versehentlich in die
// Telemetrie sickern (Data-Minimization by design).
//
// Bis zur Audit-Umsetzung fehlten in dieser Allowlist die Diagnosefelder
// durationMs / understanding / googleUrlResolution / sourceMode / runId — sie
// wurden bei JEDEM Schreiben sofort gestrippt. Folge: pipeline-status.durationMs
// blieb null, der Google-News-Monitor (server.js buildHealthReport) las ein nie
// vorhandenes Feld (toter Monitor, Audit R4), und Laufkennung/Quellenmodus waren
// nicht nachverfolgbar. Diese Felder sind reine technische Skalare/Zaehler —
// keine Dokumentinhalte, keine Namen, keine Kontaktdaten.
// VORFALL 2026-09-04 (SR §37): `CRAWL_RUN_RETENTION` war eine Modulkonstante
// `Math.max(1, Number(process.env.HELMUT_CRAWL_RUN_RETENTION) || 20)`. Ein
// fachlich voellig unbeteiligter Schreibvorgang — die inaktive Anlage von 20
// Profilen — hat damit den geteilten Ring `helmut_store.main.crawlRuns` von 36
// auf 20 Eintraege gekuerzt, weil in der ausfuehrenden Sitzung die Variable
// fehlte und der Code-Vorgabewert 20 griff. Die Kuerzung ist unumkehrbar: die
// entfernten Laufzeilen existieren nirgends sonst (SR §37.4).
//
// DARAUS FOLGEN ZWEI REGELN, die hier technisch durchgesetzt werden:
//
//  1. OHNE BELEGTE GRENZE WIRD NICHT GEKUERZT. Fehlt `HELMUT_CRAWL_RUN_RETENTION`
//     im Prozess oder ist sie ungueltig, uebernimmt `compactStore` den
//     VORGEFUNDENEN Stand unveraendert. Ein Vorgabewert, der Daten loescht, ist
//     kein sicherer Vorgabewert — fail closed heisst hier: nichts wegwerfen.
//  2. EINE WIRKSAME GRENZE LIEGT NIE UNTER DEM LESEFENSTER. Alle fuenf
//     Produktiv-Verbraucher lesen `listCrawlRuns(20)` (scheduler.js:267/:2249,
//     server.js:5071/:6371/:6874). Eine Aufbewahrung unter 20 wuerde den
//     Google-Cooldown nicht verkuerzen, sondern STILL ABSCHALTEN — die
//     Altersgrenzen dort sind eine Nachpruefung des ausgewaehlten Eintrags, kein
//     Listenfilter (google-news-hardening.js:397-422). Ein solcher Wert wird
//     deshalb als ungueltig behandelt und NICHT angewendet.
//
// Die Grenze wird bewusst PRO AUFRUF aus der Umgebung gelesen statt einmal beim
// Modulladen: nur so ist sie testbar und nur so kann ein Vorflug-Riegel sie
// ueberhaupt melden.
const CRAWL_RUN_LESEFENSTER = VORFLUG.CRAWL_RUN_LESEFENSTER;
const crawlRunAufbewahrung = VORFLUG.crawlRunAufbewahrung;

// `compactStore` SCHRUMPFT `crawlRuns` NICHT MEHR — in keiner Konfiguration.
//
// Erste Fassung dieser Aenderung kappte hier noch mit einer "belegten" Grenze.
// Das reichte nicht: ein Betreiber, der in seiner Sitzung ausgerechnet
// `HELMUT_CRAWL_RUN_RETENTION=20` gesetzt haette, haette den Ring erneut von 36
// auf 20 gezogen — mit gruenem Vorflugbericht, weil 20 formal gueltig ist. Der
// Vorfall waere also per Umgebungsvariable wiederholbar geblieben.
//
// Die tragfaehige Regel ist strenger und einfacher: der gemeinsame Transportweg
// jeder `main`-Schreibung darf eine Liste, die er fachlich nicht anfasst,
// UEBERHAUPT NICHT verkleinern. Die Aufbewahrung durchzusetzen ist Sache des
// Eigentuemers des Rings — und das ist `saveCrawlRun`, der einzige Schreiber.
//
// PREIS, ehrlich benannt: senkt ein Betreiber die Aufbewahrung, wirkt das erst
// beim naechsten `saveCrawlRun`, nicht mehr rueckwirkend beim naechsten
// beliebigen Schreibvorgang. Da seit dem 23.08. kein Cron mehr `saveCrawlRun`
// erreicht (Warteschlangenmotor, SR §37.3), heisst das in der heutigen
// Production: eine gesenkte Aufbewahrung wirkt vorerst gar nicht. Das ist die
// sichere Richtung — sie verliert nichts.
function kappeCrawlRuns(liste) {
  return sortByDate(liste, "createdAt");
}

function compactCrawlRunForStore(run) {
  // null/undefined bleiben null (ehrlich "unbekannt"), NICHT 0 — Number(null) waere 0.
  const num = (v) => (v == null || v === "" ? null : (Number.isFinite(Number(v)) ? Number(v) : null));
  const str = (v, max) => (v == null ? null : String(v).slice(0, max));
  const understanding = run && run.understanding && typeof run.understanding === "object"
    ? {
        processed: num(run.understanding.processed) || 0,
        deferred: num(run.understanding.deferred) || 0,
        reason: str(run.understanding.reason, 120)
      }
    : null;
  const gnr = run && run.googleUrlResolution && typeof run.googleUrlResolution === "object"
    ? { attempted: num(run.googleUrlResolution.attempted) || 0, resolved: num(run.googleUrlResolution.resolved) || 0 }
    : null;
  return {
    mode: run.mode || "full",
    // Mandats-Slug des Laufs (technische Kennung, kein Klarname): nötig für den
    // mandanten-bewussten Crawl-Abstands-Schutz der Google-News-Härtung.
    politicianId: str(run.politicianId, 80),
    checkedSources: run.checkedSources || 0,
    successfulSources: run.successfulSources || 0,
    failedSources: run.failedSources || 0,
    newCandidateItems: run.newCandidateItems || 0,
    savedItems: run.savedItems || 0,
    // P1-5: ehrlicher relationaler Durchsatz-Delta + Durchfluss-Zaehler (technische
    // Skalare, keine Inhalte). newRawDocuments null = in diesem Lauf unbekannt.
    newRawDocuments: num(run.newRawDocuments),
    loadedItems: num(run.loadedItems),
    discardedItems: num(run.discardedItems),
    duplicates: num(run.duplicates),
    sourcesByCategory: (run.sourcesByCategory && typeof run.sourcesByCategory === "object") ? run.sourcesByCategory : null,
    // DSGVO-Datensparsamkeit (Review-Fix): der rohe Crawl-Fehlertext enthält die
    // aufgelöste Publisher-/Google-News-URL (crawler baut "… for <url>"). Statt ihn
    // verbatim zu persistieren (und im Admin-Crawl-Report anzuzeigen), wird er hier
    // — wie die Pro-Quellen-Telemetrie — zu einem INHALTSFREIEN Fehlercode verdichtet.
    // sourceName ist ein öffentlicher Organisationsname (keine PII).
    errors: Array.isArray(run.errors) ? run.errors.slice(0, 20).map((e) => ({
      sourceName: str(e && e.sourceName, 120),
      error: require("./redact").classifyPipelineError(e && e.error)
    })) : [],
    createdAt: run.createdAt,
    // --- P0-2 Diagnosefelder (technische Metadaten, keine Inhalte) ---
    durationMs: num(run.durationMs),           // echte Wall-Clock-Dauer (P0-1); null wenn nicht gemessen
    runId: str(run.runId, 80),                 // stabile Laufkennung fuer Fehler-/Telemetrie-Korrelation
    sourceMode: str(run.sourceMode, 24),       // 'on'/'shadow'/'off' bzw. relational vs. Fallback des Laufs
    googleUrlResolution: gnr,                   // { attempted, resolved } — reanimiert den Google-News-Monitor (R4)
    understanding: understanding,               // { processed, deferred, reason } — reine Zaehler, kein KI-Text
    // --- Google-News-Härtung (Sprint 2026-07): ehrlicher Lauf-Zustand +
    // Provider-Trennung. Ausschliesslich Zaehler und stabile, inhaltsfreie Codes
    // (keine URLs, keine Titel, keine PII) — ohne diese Whitelist-Eintraege
    // wuerde compactStore die Felder beim naechsten Schreiben strippen. ---
    runState: str(run.runState, 32),           // gesund | teilweise-degradiert | stark-degradiert | fehlgeschlagen | aggregator-gedrosselt | cooldown-reduziert | unbekannt
    providerBreakdown: compactProviderBreakdown(run.providerBreakdown),
    errorCodes: compactErrorCodes(run.errorCodes),
    skippedSources: num(run.skippedSources),
    // Incident 2026-07-25: zentral vom Breaker abgebrochene Wege und bewusst
    // übersprungene geteilte Wege sind KEINE individuellen Quellenfehler — sie
    // brauchen eigene Zaehler (ohne Whitelist-Eintrag strippt compactStore sie).
    circuitOpenSources: num(run.circuitOpenSources),
    sharedSkippedSources: num(run.sharedSkippedSources),
    retriesTotal: num(run.retriesTotal),
    cooldown: run.cooldown && typeof run.cooldown === "object"
      ? { active: run.cooldown.active === true, skipGoogle: run.cooldown.skipGoogle === true, reason: str(run.cooldown.reason, 40) }
      : null,
    googleGate: run.googleGate && typeof run.googleGate === "object"
      ? { open: run.googleGate.open === true, observed: num(run.googleGate.observed) || 0, breakerFailures: num(run.googleGate.breakerFailures) || 0 }
      : null,
    // --- OP-25 E3 (2026-08-04): Nachweisfelder des globalen Pfads. Ohne diese
    // Allowlist-Eintraege strippte compactStore genau die Felder, die den Unterschied
    // zwischen `teilweise wegen Verstehensbudget` und `teilweise wegen Quellen-/
    // Persistenz-/Kontextfehler` belegen — der OP-25-Production-Nachweis waere aus der
    // Ablage nicht fuehrbar. Ausschliesslich Zaehler, Schrittnamen und Mandats-Slugs
    // (technische Kennungen, wie politicianId oben) — keine Texte, keine URLs. ---
    globalphase: run.globalphase === true ? true : null,
    globalLaufId: str(run.globalLaufId, 80),
    datenstandFrisch: typeof run.datenstandFrisch === "boolean" ? run.datenstandFrisch : null,
    datenstand: compactDatenstandVermerk(run.datenstand),
    datenstandDetail: compactDatenstandDetail(run.datenstandDetail),
    quellenVereinigung: compactQuellenVereinigung(run.quellenVereinigung),
    // K1-Folgefund (echtes-Laufpaar-Test 2026-08-05): der Nachweisvertrag prueft die
    // VOLLSTAENDIGKEIT einer Mandatsprojektion an `matching`/`decisions` — die
    // Kompaktierung strippte aber genau diese (reinen Zaehler-)Zusammenfassungen, sodass
    // selbst ein korrekt gebundener echter Mandatslauf als `mandatslauf-unvollstaendig`
    // durchgefallen waere. Strikte Allowlist wie ueberall: Zaehler + kurze Codes, keine Inhalte.
    matching: compactShadowSummary(run.matching),
    decisions: compactShadowSummary(run.decisions)
  };
}

// Zusammenfassung eines Schattenschritts (scheduler.shadowSummary): nur Zaehlfelder und
// kurze technische Codes — keine Titel, keine URLs, keine Nutzdaten.
function compactShadowSummary(value) {
  if (!value || typeof value !== "object") return null;
  const out = {};
  if (value.skipped === true) out.skipped = true;
  if (value.reason != null) out.reason = String(value.reason).slice(0, 80);
  for (const feld of ["candidates", "saved", "matched", "count", "processed", "updated"]) {
    if (Number.isFinite(Number(value[feld])) && value[feld] !== null && value[feld] !== "") {
      out[feld] = Number(value[feld]);
    }
  }
  return Object.keys(out).length ? out : {};
}

// OP-25 E3: Datenstands-Vermerk eines Mandatslaufs (Ausgabe von datenstandVermerk) —
// strikte Allowlist, nur Skalare.
function compactDatenstandVermerk(value) {
  if (!value || typeof value !== "object") return null;
  const num = (v) => (v == null || v === "" ? null : (Number.isFinite(Number(v)) ? Number(v) : null));
  const str = (v, max) => (v == null ? null : String(v).slice(0, max));
  return {
    laufId: str(value.laufId, 120),
    status: str(value.status, 24),
    versiegelt: value.versiegelt === true,
    frisch: value.frisch === true,
    beendetAt: num(value.beendetAt),
    quellen: num(value.quellen),
    rohdokumente: num(value.rohdokumente),
    verstanden: num(value.verstanden),
    budgetErschoepft: value.budgetErschoepft === true,
    fehler: num(value.fehler),
    buendelung: str(value.buendelung, 16),
    kontexte: num(value.kontexte),
    // OP-25 E3: VERSIEGELTE Dauer + Budget der globalen Phase. Ohne diese beiden Felder
    // muesste der Nachweis die Budgetgrenze am vor dem Versiegeln gebildeten `durationMs`
    // pruefen — das unterzeichnet die Phase systematisch.
    dauerMs: num(value.dauerMs),
    budgetMs: num(value.budgetMs)
  };
}

// OP-25 E3: Ursachenzerlegung des globalen Laufs — strikte Allowlist je Teilblock.
function compactDatenstandDetail(value) {
  if (!value || typeof value !== "object") return null;
  const num = (v) => (v == null || v === "" ? null : (Number.isFinite(Number(v)) ? Number(v) : null));
  const str = (v, max) => (v == null ? null : String(v).slice(0, max));
  const lazy = value.lazy && typeof value.lazy === "object" ? value.lazy : null;
  const eager = value.eager && typeof value.eager === "object" ? value.eager : null;
  const persistenz = value.persistenz && typeof value.persistenz === "object" ? value.persistenz : null;
  const kontext = value.kontext && typeof value.kontext === "object" ? value.kontext : null;
  return {
    budgetMs: num(value.budgetMs),
    nichtAbgerufen: num(value.nichtAbgerufen),
    fehlerSchritte: Array.isArray(value.fehlerSchritte)
      ? value.fehlerSchritte.slice(0, 20).map((f) => ({ schritt: str(f && f.schritt, 40), fatal: Boolean(f && f.fatal) }))
      : [],
    fehlerhafteProfile: Array.isArray(value.fehlerhafteProfile)
      ? value.fehlerhafteProfile.slice(0, 50).map((id) => str(id, 80))
      : [],
    persistenz: persistenz
      ? {
        ergebnis: str(persistenz.ergebnis, 24),
        anfragen: num(persistenz.anfragen),
        einzelnNachgezogen: num(persistenz.einzelnNachgezogen),
        zaehlerVerfehlt: num(persistenz.zaehlerVerfehlt),
        bestandsTreffer: num(persistenz.bestandsTreffer)
      }
      : null,
    lazy: lazy
      ? {
        cluster: num(lazy.cluster),
        verarbeitet: num(lazy.verarbeitet),
        uebersprungeneStapel: num(lazy.uebersprungeneStapel),
        uebersprungeneDokumente: num(lazy.uebersprungeneDokumente)
      }
      : null,
    eager: eager
      ? {
        stapel: num(eager.stapel),
        verarbeitet: num(eager.verarbeitet),
        zurueckgestellt: num(eager.zurueckgestellt),
        vorgemerkt: num(eager.vorgemerkt),
        // K4: Bilanzfelder der Vormerkung in der Verstehensphase — ein Speicherfehler
        // (`vormerkFehlgeschlagen`) ist von "nicht erreicht" (`nichtVorgemerkt`) getrennt.
        bereitsVorhanden: num(eager.bereitsVorhanden),
        vormerkFehlgeschlagen: num(eager.vormerkFehlgeschlagen),
        nichtVorgemerkt: num(eager.nichtVorgemerkt),
        uebersprungeneStapel: num(eager.uebersprungeneStapel),
        uebersprungeneDokumente: num(eager.uebersprungeneDokumente),
        andereSkips: num(eager.andereSkips)
      }
      : null,
    // K4 (OP-25 E3): GESAMT-Vormerkbilanz der Abschlussphase (Lazy-Rest + uebersprungene
    // Stapel). Ohne diesen Allowlist-Block strippte compactStore genau die Zahlen, mit
    // denen der Nachweis die E3-Dauerhaftigkeit belegt. Reine Zaehler.
    vormerkung: value.vormerkung && typeof value.vormerkung === "object"
      ? {
        lazyRestCluster: num(value.vormerkung.lazyRestCluster),
        lazyRestKandidaten: num(value.vormerkung.lazyRestKandidaten),
        uebersprungeneDokumenteRoh: num(value.vormerkung.uebersprungeneDokumenteRoh),
        uebersprungeneDokumente: num(value.vormerkung.uebersprungeneDokumente),
        clusterAusUebersprungenen: num(value.vormerkung.clusterAusUebersprungenen),
        kandidaten: num(value.vormerkung.kandidaten),
        vorgemerkt: num(value.vormerkung.vorgemerkt),
        bereitsVorhanden: num(value.vormerkung.bereitsVorhanden),
        fehlgeschlagen: num(value.vormerkung.fehlgeschlagen),
        nichtVorgemerkt: num(value.vormerkung.nichtVorgemerkt),
        anfragen: num(value.vormerkung.anfragen),
        dauerMs: num(value.vormerkung.dauerMs)
      }
      : null,
    kontext: kontext
      ? {
        kontexte: num(kontext.kontexte),
        geteilt: num(kontext.geteilt),
        mandatseigen: num(kontext.mandatseigen),
        unbekannt: num(kontext.unbekannt),
        dokumente: num(kontext.dokumente),
        ohneSichtbarkeit: num(kontext.ohneSichtbarkeit),
        // K5: die ERKLAERBARE Zusammensetzung der Kontextzahl (statisch vs. dokument-
        // getrieben vs. unbekannt + Signaturgroessen-Histogramm). Reine Zaehler.
        zusammensetzung: kontext.zusammensetzung && typeof kontext.zusammensetzung === "object"
          ? {
            statisch: num(kontext.zusammensetzung.statisch),
            dokumentgetrieben: num(kontext.zusammensetzung.dokumentgetrieben),
            unbekannt: num(kontext.zusammensetzung.unbekannt),
            statischMoeglich: num(kontext.zusammensetzung.statischMoeglich),
            dipDokumente: num(kontext.zusammensetzung.dipDokumente),
            mehrfachHerkunft: num(kontext.zusammensetzung.mehrfachHerkunft),
            groessen: kontext.zusammensetzung.groessen && typeof kontext.zusammensetzung.groessen === "object"
              ? Object.fromEntries(Object.entries(kontext.zusammensetzung.groessen)
                .slice(0, 50).map(([k, v]) => [String(k).slice(0, 8), num(v)]))
              : null
          }
          : null
      }
      : null,
    buendelung: str(value.buendelung, 16)
  };
}

// OP-25 E3: Vereinigungsmenge des globalen Laufs — Zaehler + Mandats-Slugs.
function compactQuellenVereinigung(value) {
  if (!value || typeof value !== "object") return null;
  const num = (v) => (v == null || v === "" ? null : (Number.isFinite(Number(v)) ? Number(v) : null));
  return {
    gesamt: num(value.gesamt),
    gemeinsam: num(value.gemeinsam),
    mandatseigen: num(value.mandatseigen),
    doppelteAbrufwege: num(value.doppelteAbrufwege),
    fehlerhafteProfile: Array.isArray(value.fehlerhafteProfile)
      ? value.fehlerhafteProfile.slice(0, 50).map((id) => String(id).slice(0, 80))
      : [],
    mandate: num(value.mandate),
    // OP-25 E3: die geplanten Mandats-Slugs des Laufs (Identitaeten, nicht nur die Anzahl) —
    // Grundlage der identitaetsgenauen Pruefung gegen die eingefrorene Fenstermenge.
    mandateIds: Array.isArray(value.mandateIds)
      ? value.mandateIds.slice(0, 200).map((id) => String(id).slice(0, 80))
      : null
  };
}

// Provider-Aufschlüsselung strikt auf bekannte Zähl-Felder reduzieren (Allowlist).
function compactProviderBreakdown(value) {
  if (!value || typeof value !== "object") return null;
  const num = (v) => (Number.isFinite(Number(v)) ? Number(v) : 0);
  const bucket = (b) => (b && typeof b === "object"
    ? { checked: num(b.checked), ok: num(b.ok), failed: num(b.failed), skipped: num(b.skipped), http429: num(b.http429), timeout: num(b.timeout), circuitOpen: num(b.circuitOpen), otherErrors: num(b.otherErrors), retries: num(b.retries) }
    : null);
  return { googleNews: bucket(value.googleNews), direct: bucket(value.direct) };
}

// Fehlercode-Summen: nur kurze Code-Schlüssel + Zähler (max 12 Codes).
function compactErrorCodes(value) {
  if (!value || typeof value !== "object") return null;
  const out = {};
  for (const key of Object.keys(value).slice(0, 12)) {
    const n = Number(value[key]);
    if (Number.isFinite(n)) out[String(key).slice(0, 24)] = n;
  }
  return Object.keys(out).length ? out : null;
}

function compactStore(store) {
  const rawItems = compactRawItems(store.rawItems || []);
  return {
    ...store,
    rawItems,
    briefings: keepLatestPerOwner(store.briefings, "generatedAt", "date", 4, 320).map(compactStoredBriefing),
    // P0-5 Stufe 1: crawlRuns-Retention an saveCrawlRun angeglichen. Die eigentliche
    // Blob-Entlastung liefert Stufe 2 (crawl runs relational, freigabepflichtig).
    // SEIT 2026-09-04 (SR §37): `kappeCrawlRuns` kuerzt NUR mit belegter Grenze —
    // sonst bleibt der vorgefundene Stand vollstaendig erhalten. compactStore laeuft
    // bei JEDEM Schreibvorgang auf die geteilte Zeile `main`, also auch bei einem
    // reinen Profil-Schreibvorgang, der `crawlRuns` gar nicht anfasst.
    crawlRuns: kappeCrawlRuns(store.crawlRuns).map(compactCrawlRunForStore),
    interactions: keepLatestPerOwner(store.interactions, "createdAt", "createdAt", 80, 4000),
    topicMemory: keepLatestPerOwner(store.topicMemory, "updatedAt", "lastSeenAt", 120, 4000),
    politicalItems: keepLatestPerOwner(store.politicalItems, "created_at", "updated_at", 80, 4000),
    personalizedRecommendations: keepLatestPerOwner(store.personalizedRecommendations, "created_at", "updated_at", 80, 4000),
    dailyTasks: keepLatestPerOwner(store.dailyTasks, "createdAt", "dueDate", 60, 3000),
    communicationDrafts: keepLatestPerOwner(store.communicationDrafts, "createdAt", "createdAt", 40, 2000),
    userNotes: keepLatestPerOwner(store.userNotes, "createdAt", "createdAt", 80, 3000),
    priorityChanges: keepLatestPerOwner(store.priorityChanges, "created_at", "updated_at", 80, 3000),
    lageChecks: keepLatestPerOwner(store.lageChecks, "checkedAt", "createdAt", 10, 1000),
    pushSubscriptions: sortByDate(store.pushSubscriptions, "updatedAt", "createdAt").slice(0, 300),
    pushEvents: sortByDate(store.pushEvents, "createdAt").slice(0, 200),
    pipelineDebugReports: keepLatestPerOwner(store.pipelineDebugReports, "createdAt", "createdAt", 2, 200),
    sessions: sortByDate(store.sessions, "createdAt").slice(0, 500),
    auditEvents: sortByDate(store.auditEvents, "createdAt").slice(0, 1000),
    systemErrors: sortByDate(store.systemErrors, "createdAt").slice(0, 300),
    dailyInputs: sortByDate(store.dailyInputs, "createdAt").slice(0, 1000)
  };
}

function compactRawItems(rawItems) {
  const sanitized = rawItems.map(sanitizeStoredRawItem);
  const protectedPersonItems = sortByDate(
    sanitized.filter((item) => item.sourceType === "person" || isPersonNewsSourceId(item.sourceId)),
    "publishedAt",
    "retrievedAt"
  ).slice(0, 160);
  const protectedHashes = new Set(protectedPersonItems.map((item) => item.hash || item.id).filter(Boolean));
  const generalItems = sortByDate(
    sanitized.filter((item) => !protectedHashes.has(item.hash || item.id)),
    "publishedAt",
    "retrievedAt"
  ).slice(0, 440);
  return sortByDate([...protectedPersonItems, ...generalItems], "publishedAt", "retrievedAt").slice(0, 600);
}

function isPersonNewsSourceId(sourceId) {
  return /^[a-z0-9-]+-news$/i.test(String(sourceId || ""));
}

function sortByDate(items, primaryKey, fallbackKey = primaryKey) {
  return [...(Array.isArray(items) ? items : [])].sort((a, b) => {
    const left = new Date(b?.[primaryKey] || b?.[fallbackKey] || 0).getTime();
    const right = new Date(a?.[primaryKey] || a?.[fallbackKey] || 0).getTime();
    return (Number.isNaN(left) ? 0 : left) - (Number.isNaN(right) ? 0 : right);
  });
}

function sanitizeStoredRawItem(item) {
  const quality = articleUrlQuality(item?.url);
  if (quality === "direct") {
    return {
      ...item,
      linkType: item.linkType || quality,
      linkResolutionNote: item.linkResolutionNote || linkResolutionNote(item.linkType || quality)
    };
  }
  return {
    ...item,
    url: "",
    originalUrl: item.originalUrl || item.url,
    linkType: "missing",
    linkResolutionNote: linkResolutionNote("missing")
  };
}

function isBlockedStoredArticleUrl(value) {
  try {
    const parsed = new URL(String(value || ""));
    const hostname = parsed.hostname.toLowerCase();
    const pathname = parsed.pathname.toLowerCase();
    return (
      hostname.includes("google.") ||
      hostname.includes("googleapis.com") ||
      hostname.includes("google-analytics.com") ||
      hostname.includes("googleadservices.com") ||
      hostname.includes("googlesyndication.com") ||
      hostname.includes("googletagmanager.com") ||
      hostname === "www.w3.org" ||
      hostname === "w3.org" ||
      hostname.includes("gstatic.com") ||
      hostname.includes("googleusercontent.com") ||
      /\.(js|css|png|jpe?g|webp|gif|svg|ico)(\?|$)/i.test(pathname)
    );
  } catch {
    return true;
  }
}

function mergeSources(storedSources = []) {
  const storedById = new Map(storedSources.map((source) => [source.id, source]));
  const mergedDefaults = v1Sources.map((source) => ({
    ...source,
    ...(storedById.get(source.id) || {}),
    url: source.url,
    rssUrl: source.rssUrl,
    rssUrls: source.rssUrls,
    crawlMethod: source.crawlMethod,
    priority: source.priority,
    maxItems: source.maxItems,
    active: storedById.get(source.id)?.active ?? source.active
  }));
  // Nur explizit als custom markierte Quellen behalten. Verwaiste Eintraege (frueher
  // geseedet, jetzt nicht mehr in v1Sources) werden ignoriert -> Code ist die Wahrheit.
  // Damit greift die Quellen-Kuratierung auch bei bereits befuelltem Store (Supabase).
  const customSources = storedSources.filter(
    (source) => source.custom === true && !v1Sources.some((defaultSource) => defaultSource.id === source.id)
  );
  return [...mergedDefaults, ...customSources];
}

async function saveRawItems(items) {
  const store = await readStore();
  const knownHashes = new Set(store.rawItems.map((item) => item.hash));
  const newItems = items.filter((item) => item.hash && !knownHashes.has(item.hash));
  const incomingByHash = new Map(items.filter((item) => item.hash).map((item) => [item.hash, item]));
  store.rawItems = store.rawItems.map((item) => {
    const incoming = incomingByHash.get(item.hash);
    if (!incoming) return item;
    return {
      ...item,
      url: isBetterArticleUrl(item.url, incoming.url) ? incoming.url : item.url,
      originalUrl: item.originalUrl || incoming.originalUrl || "",
      linkType: betterLinkType(item, incoming),
      linkResolutionNote: incoming.linkResolutionNote || item.linkResolutionNote || linkResolutionNote(betterLinkType(item, incoming)),
      sourceName: isBetterSourceName(item.sourceName, incoming.sourceName) ? incoming.sourceName : item.sourceName,
      sourceUrl: isBetterSourceUrl(item.sourceUrl, incoming.sourceUrl) ? incoming.sourceUrl : item.sourceUrl,
      imageUrl: isBetterImageUrl(item.imageUrl, incoming.imageUrl) ? incoming.imageUrl : item.imageUrl || "",
      excerpt: item.excerpt || incoming.excerpt || ""
    };
  });
  store.rawItems = [...store.rawItems, ...newItems].sort((a, b) => new Date(b.publishedAt) - new Date(a.publishedAt));
  await writeStore(store);
  return newItems;
}

function isBetterArticleUrl(currentUrl, incomingUrl) {
  if (!incomingUrl || incomingUrl === currentUrl) return false;
  return articleUrlRank(incomingUrl) > articleUrlRank(currentUrl);
}

function betterLinkType(currentItem, incomingItem) {
  const currentRank = articleUrlRank(currentItem.url);
  const incomingRank = articleUrlRank(incomingItem.url);
  if (incomingRank > currentRank) return incomingItem.linkType || articleUrlQuality(incomingItem.url);
  return currentItem.linkType || articleUrlQuality(currentItem.url);
}

function articleUrlRank(url) {
  const quality = articleUrlQuality(url);
  if (quality === "direct") return 4;
  if (quality === "publisher") return 3;
  if (quality === "google_proxy") return 2;
  if (quality === "asset") return 1;
  return 0;
}

function articleUrlQuality(url) {
  if (!url) return "missing";
  if (isImageAssetUrl(url)) return "asset";
  if (isGoogleLink(url)) return "google_proxy";
  if (isLikelyPublisherHomepage(url)) return "publisher";
  if (!isBlockedStoredArticleUrl(url)) return "direct";
  return "missing";
}

function isLikelyPublisherHomepage(value) {
  try {
    const parsed = new URL(String(value || ""));
    const path = parsed.pathname.replace(/\/+$/, "");
    return !path || path === "/" || path.split("/").filter(Boolean).length === 0;
  } catch {
    return false;
  }
}

function linkResolutionNote(linkType) {
  if (linkType === "direct") return "Direkter Artikellink gefunden.";
  if (linkType === "publisher") return "Direkter Artikel nicht sicher auflösbar; Publisher-Quelle hinterlegt.";
  if (linkType === "google_proxy") return "Google-News-Link erkannt, direkter Artikel noch nicht auflösbar.";
  return "Kein belastbarer öffentlicher Link gefunden.";
}

function isGoogleLink(url) {
  try {
    const parsed = new URL(String(url || ""));
    return parsed.hostname.includes("google.");
  } catch {
    return false;
  }
}

function isBetterSourceName(currentName, incomingName) {
  if (!incomingName || incomingName === currentName) return false;
  return !currentName || String(currentName).includes("News-Suche");
}

function isBetterSourceUrl(currentUrl, incomingUrl) {
  if (!incomingUrl || incomingUrl === currentUrl) return false;
  return !currentUrl || isGoogleLink(currentUrl) || isImageAssetUrl(currentUrl);
}

function isBetterImageUrl(currentUrl, incomingUrl) {
  if (!incomingUrl || incomingUrl === currentUrl) return false;
  return !currentUrl || isImageAssetUrl(currentUrl);
}

function isImageAssetUrl(url) {
  try {
    const parsed = new URL(String(url || ""));
    const hostname = parsed.hostname.toLowerCase();
    return hostname.includes("googleusercontent.com") || hostname.includes("gstatic.com") || /\.(png|jpe?g|webp|gif|svg|ico)(\?|$)/i.test(parsed.pathname);
  } catch {
    return false;
  }
}

async function getRawItemsSince(date) {
  const since = new Date(date);
  const store = await readStore();
  return store.rawItems.filter((item) => new Date(item.publishedAt) >= since);
}

async function getSources() {
  return (await readStore()).sources;
}

async function updateSourceLastCrawled(sourceId, value = new Date().toISOString()) {
  const store = await readStore();
  store.sources = store.sources.map((source) => (source.id === sourceId ? { ...source, lastCrawledAt: value } : source));
  await writeStore(store);
}

async function saveBriefing(briefing) {
  const key = pKey(briefing.politicianId);
  const store = await readStore(key);
  const briefingWithMeta = {
    ...briefing,
    generatedAt: new Date().toISOString()
  };
  store.briefings = [briefingWithMeta, ...store.briefings.filter((entry) => entry.id !== briefing.id)].slice(0, 2000);
  await writeStore(store, key);
  return briefingWithMeta;
}

async function getLatestBriefing(politicianId) {
  // Tenant-Haertung (Sprint-1-Sicherheit): konsistent zu den 2026-07 gehaerteten
  // Blob-Lesern (getTasks/getUserNotes/…). Fehlender Kontext -> harter Fehler statt
  // stillem Main-Store-Fallback (RLS ist inert -> App-Schicht ist die einzige Linie).
  const tenantId = assertTenant(politicianId, "getLatestBriefing");
  const pStore = await readStore(pKey(tenantId));
  const found = (pStore.briefings || []).find((briefing) => briefing.politicianId === tenantId) || null;
  if (found) return found;
  // Fallback: Bestandsdaten aus dem Main-Store waehrend der Migration
  const mainStore = await readStore("main");
  return (mainStore.briefings || []).find((briefing) => briefing.politicianId === tenantId) || null;
}

async function getTopicMemory(politicianId) {
  const tenantId = assertTenant(politicianId, "getTopicMemory"); // Sprint-1-Haertung
  politicianId = tenantId;
  const pStore = await readStore(pKey(politicianId));
  const persisted = (pStore.topicMemory || []).filter((entry) => entry.politicianId === politicianId);
  let briefings = pStore.briefings || [];
  if (!briefings.length) {
    const mainStore = await readStore("main");
    briefings = mainStore.briefings || [];
  }
  const derived = buildTopicMemoryFromBriefings(briefings, politicianId);
  if (persisted.length) return mergeTopicMemoryEntries(persisted, derived);
  return derived;
}

async function updateTopicMemoryFromBriefing(briefing) {
  const key = pKey(briefing.politicianId);
  const store = await readStore(key);
  const existing = new Map((store.topicMemory || []).map((entry) => [`${entry.politicianId}:${entry.topicKey}`, entry]));
  const now = new Date().toISOString();

  (briefing.items || []).forEach((item) => {
    const topicKey = topicMemoryKey(item);
    const memoryKey = `${briefing.politicianId}:${topicKey}`;
    const previous = existing.get(memoryKey);
    existing.set(memoryKey, {
      id: previous?.id || `memory-${briefing.politicianId}-${topicKey}`,
      politicianId: briefing.politicianId,
      topicKey,
      title: item.title || previous?.title || "Politisches Thema",
      firstSeenAt: previous?.firstSeenAt || briefing.generatedAt || briefing.date || now,
      lastSeenAt: briefing.generatedAt || now,
      seenCount: (previous?.seenCount || 0) + 1,
      lastDecision: item.decision || previous?.lastDecision || "",
      lastAction: item.recommendedAction || previous?.lastAction || "",
      lastStatement: item.suggestedStatement || previous?.lastStatement || "",
      lastRisk: item.riskNote || previous?.lastRisk || "",
      lastOpportunity: item.opportunityNote || previous?.lastOpportunity || "",
      lastAssignee: item.taskTemplate?.assignee || previous?.lastAssignee || "",
      sourceCount: item.sourceCount || previous?.sourceCount || 0,
      sourceUrls: mergeUnique(previous?.sourceUrls, sourceUrlsForMemory(item)),
      sourceHashes: mergeUnique(previous?.sourceHashes, sourceHashesForMemory(item)),
      updatedAt: now
    });
  });

  store.topicMemory = Array.from(existing.values())
    .sort((a, b) => new Date(b.lastSeenAt) - new Date(a.lastSeenAt))
    .slice(0, 200);
  await writeStore(store, key);
  return store.topicMemory.filter((entry) => entry.politicianId === briefing.politicianId);
}

function buildTopicMemoryFromBriefings(briefings, politicianId) {
  const memory = new Map();
  [...briefings].reverse().forEach((briefing) => {
    if (politicianId && briefing.politicianId !== politicianId) return;
    (briefing.items || []).forEach((item) => {
      const topicKey = topicMemoryKey(item);
      const memoryKey = `${briefing.politicianId}:${topicKey}`;
      const previous = memory.get(memoryKey);
      memory.set(memoryKey, {
        id: previous?.id || `memory-${briefing.politicianId}-${topicKey}`,
        politicianId: briefing.politicianId,
        topicKey,
        title: item.title || previous?.title || "Politisches Thema",
        firstSeenAt: previous?.firstSeenAt || briefing.generatedAt || briefing.date,
        lastSeenAt: briefing.generatedAt || briefing.date,
        seenCount: (previous?.seenCount || 0) + 1,
        lastDecision: item.decision || previous?.lastDecision || "",
        lastAction: item.recommendedAction || previous?.lastAction || "",
        lastStatement: item.suggestedStatement || previous?.lastStatement || "",
        lastRisk: item.riskNote || previous?.lastRisk || "",
        lastOpportunity: item.opportunityNote || previous?.lastOpportunity || "",
        lastAssignee: item.taskTemplate?.assignee || previous?.lastAssignee || "",
        sourceCount: item.sourceCount || previous?.sourceCount || 0,
        sourceUrls: mergeUnique(previous?.sourceUrls, sourceUrlsForMemory(item)),
        sourceHashes: mergeUnique(previous?.sourceHashes, sourceHashesForMemory(item)),
        updatedAt: briefing.generatedAt || briefing.date
      });
    });
  });
  return Array.from(memory.values()).sort((a, b) => new Date(b.lastSeenAt) - new Date(a.lastSeenAt));
}

function mergeTopicMemoryEntries(persisted = [], derived = []) {
  const byKey = new Map((persisted || []).map((entry) => [`${entry.politicianId}:${entry.topicKey}`, entry]));
  for (const entry of derived || []) {
    const key = `${entry.politicianId}:${entry.topicKey}`;
    const previous = byKey.get(key);
    if (!previous) {
      byKey.set(key, entry);
      continue;
    }
    byKey.set(key, {
      ...entry,
      ...previous,
      sourceUrls: mergeUnique(previous.sourceUrls, entry.sourceUrls),
      sourceHashes: mergeUnique(previous.sourceHashes, entry.sourceHashes),
      sourceCount: Math.max(Number(previous.sourceCount || 0), Number(entry.sourceCount || 0)),
      firstSeenAt: previous.firstSeenAt || entry.firstSeenAt,
      lastSeenAt: previous.lastSeenAt || entry.lastSeenAt,
      updatedAt: previous.updatedAt || entry.updatedAt
    });
  }
  return Array.from(byKey.values()).sort((a, b) => new Date(b.lastSeenAt) - new Date(a.lastSeenAt));
}

function topicMemoryKey(item) {
  return String(item.topic || item.title || item.signalId || "topic")
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 80) || "topic";
}

function sourceUrlsForMemory(item = {}) {
  const direct = [item.itemUrl, item.url, item.originalUrl].filter(Boolean);
  const sourceUrls = (item.sources || [])
    .flatMap((source) => [source.itemUrl, source.url, source.originalUrl])
    .filter(Boolean);
  const primaryUrls = item.primarySource
    ? [item.primarySource.itemUrl, item.primarySource.url, item.primarySource.originalUrl].filter(Boolean)
    : [];
  return uniqueStrings([...direct, ...sourceUrls, ...primaryUrls].map(normalizeMemoryUrl).filter(Boolean)).slice(0, 40);
}

function sourceHashesForMemory(item = {}) {
  const direct = [item.hash, item.rawItemId, item.rawItemID, item.id].filter(Boolean);
  const sourceIds = (item.sources || [])
    .flatMap((source) => [source.rawItemId, source.id, source.hash])
    .filter(Boolean);
  return uniqueStrings([...direct, ...sourceIds].map((value) => String(value || "").trim()).filter(Boolean)).slice(0, 40);
}

function mergeUnique(previous = [], next = []) {
  return uniqueStrings([...(Array.isArray(previous) ? previous : []), ...(Array.isArray(next) ? next : [])]).slice(0, 80);
}

function uniqueStrings(values) {
  return Array.from(new Set((values || []).map((value) => String(value || "").trim()).filter(Boolean)));
}

function normalizeMemoryUrl(value) {
  try {
    const url = new URL(String(value || ""));
    url.hash = "";
    url.searchParams.delete("utm_source");
    url.searchParams.delete("utm_medium");
    url.searchParams.delete("utm_campaign");
    url.searchParams.delete("utm_term");
    url.searchParams.delete("utm_content");
    return url.toString().replace(/\/+$/, "");
  } catch {
    return "";
  }
}

async function saveCrawlRun(run) {
  const store = await readStore();
  // N1 (Health-Report-Skalierung, 2026-07-25): an die Aufbewahrung angeglichen
  // (vorher hart auf 20 gekappt) — der dokumentierte Schalter HELMUT_CRAWL_RUN_RETENTION
  // griff sonst nie, weil dieser Cut bereits VOR compactStore lag.
  //
  // SEIT 2026-09-04 (SR §37): Dies ist der EINZIGE Schreiber des Rings, also die
  // einzige Stelle, die ihn ueberhaupt begrenzen muss. Ohne belegte Grenze wird der
  // Ring auf seiner VORGEFUNDENEN Laenge gehalten (mindestens dem Lesefenster) —
  // er waechst dann nicht unbegrenzt, schrumpft aber auch nie.
  const aufbewahrung = crawlRunAufbewahrung();
  const bestand = Array.isArray(store.crawlRuns) ? store.crawlRuns : [];
  const grenze = aufbewahrung.gueltig
    ? aufbewahrung.wirksam
    : Math.max(CRAWL_RUN_LESEFENSTER, bestand.length);
  store.crawlRuns = [{ ...run, createdAt: new Date().toISOString() }, ...bestand].slice(0, grenze);
  await writeStore(store);
  const saved = store.crawlRuns[0];
  // P0-5 Stufe 2 (VORBEREITUNG, freigabepflichtig/Default AUS): Dual-Write in die
  // relationale crawl_runs-Tabelle. Ohne Flag+Migration = No-Op, fail-safe.
  await insertCrawlRunRelational(saved).catch(() => {});
  return saved;
}

// P0-5 Stufe 2: gated Dual-Write eines Crawl-Laufs nach public.crawl_runs.
// Default AUS (HELMUT_CRAWL_RUNS_RELATIONAL) + freigabepflichtige Migration
// (20260720). Ohne beides ein reiner No-Op; ein Write-Fehler beeinflusst den
// Blob-Pfad nie (der Blob bleibt bis Phase 3 die Lese-Wahrheit).
async function insertCrawlRunRelational(run) {
  const { crawlRunsRelationalEnabled, crawlRunToRelationalRow } = require("./blob-relational");
  if (!crawlRunsRelationalEnabled()) return { skipped: true, reason: "disabled" };
  if (!v3StoreReady()) return { skipped: true, reason: "relational-store-not-ready" };
  const row = crawlRunToRelationalRow(run);
  await supabaseRequest("/rest/v1/crawl_runs", {
    method: "POST",
    headers: { Prefer: "return=minimal" },
    body: JSON.stringify(row)
  });
  return { inserted: 1 };
}

async function getLatestCrawlRun() {
  return (await readStore()).crawlRuns[0] || null;
}

// P0-1 (freigabepflichtig, DEFAULT AUS): schreibt die Pro-Quellenabruf-Telemetrie
// in die NEUE relationale Tabelle source_crawl_telemetry. Nur aufgerufen, wenn der
// relationale Store konfiguriert ist; ohne angewendete Migration schlaegt der Write
// fehl und wird vom Aufrufer (source-telemetry.persist) verschluckt -> kein
// Production-Daten-Write ohne Freigabe. Reine technische Metadaten (kein Volltext).
async function insertSourceCrawlTelemetry(rows) {
  if (!v3StoreReady()) return { skipped: true, reason: "relational-store-not-ready" };
  await supabaseRequest("/rest/v1/source_crawl_telemetry", {
    method: "POST",
    headers: { Prefer: "return=minimal" },
    body: JSON.stringify(rows)
  });
  return { inserted: Array.isArray(rows) ? rows.length : 0 };
}

// Punkt 16 — LESEPFAD zur Pro-Quellenabruf-Telemetrie. Bis zu diesem Sprint gab
// es ausschliesslich den Write-Pfad (insertSourceCrawlTelemetry): 13 081 echte
// Laufzeilen in Production, im Code aber nie gelesen (Befund A-6). Die
// Stoerungserkennung leitet ihren Zustand ausschliesslich hieraus ab.
//
// REIN LESEND, defensiv: fehlt die Tabelle oder der relationale Store, kommt []
// zurueck -> der Bericht meldet ehrlich "keine Telemetrie" statt falschem Gruen.
// Es werden NUR die inhaltsfreien Felder geladen, die die Klassifikation braucht
// (keine Quellennamen, keine URLs) — Datensparsamkeit wie beim Write-Pfad.
async function listSourceCrawlTelemetry({ days = 14, limit = 20000 } = {}) {
  if (!v3StoreReady()) return [];
  const cutoffIso = new Date(Date.now() - Math.max(1, Number(days) || 14) * 24 * 60 * 60 * 1000).toISOString();
  const cols = "source_id,status,error_code,duration_ms,found_documents,new_documents,retry_count,created_at,run_id";
  const seite = 1000;
  const max = Math.max(0, Number(limit) || 0);
  const out = [];
  try {
    // Seitenweise (PostgREST deckelt eine einzelne Antwort) — neueste zuerst,
    // damit ein Limit immer das AKTUELLE Fenster behaelt, nie einen alten Rest.
    for (let offset = 0; offset < max; offset += seite) {
      const nehmen = Math.min(seite, max - offset);
      const rows = await supabaseRequest(
        `/rest/v1/source_crawl_telemetry?select=${cols}&created_at=gte.${encodeURIComponent(cutoffIso)}`
        + `&order=created_at.desc&offset=${offset}&limit=${nehmen}`
      );
      if (!Array.isArray(rows) || !rows.length) break;
      out.push(...rows);
      if (rows.length < nehmen) break;
    }
    return out;
  } catch (error) {
    console.error("[v3Store] listSourceCrawlTelemetry fehlgeschlagen:", error.message);
    // Teilergebnis verwerfen: ein halbes Fenster wuerde Fehlerserien und
    // "letzte Lieferung" verfaelschen und damit Fehlalarme erzeugen.
    return [];
  }
}

// Reine Lese-Hilfe: die letzten Crawl-Läufe (neueste zuerst). Für den robusten
// Admin-Morgenstatus (frühester erfolgreicher Tageslauf statt blind letzter Lauf).
async function listCrawlRuns(limit = 20) {
  const runs = (await readStore()).crawlRuns || [];
  return runs.slice(0, Math.max(0, Number(limit) || 0));
}

async function saveLageCheck(check) {
  const key = pKey(check.politicianId);
  const store = await readStore(key);
  const now = new Date().toISOString();
  const entry = {
    id: check.id || `lage-check-${check.politicianId || "unknown"}-${Date.now()}`,
    createdAt: check.createdAt || now,
    checkedAt: check.checkedAt || now,
    ...check
  };
  store.lageChecks = [entry, ...(store.lageChecks || []).filter((item) => item.id !== entry.id)].slice(0, 2000);
  await writeStore(store, key);
  return entry;
}

async function getLatestLageCheck(politicianId) {
  const tenantId = assertTenant(politicianId, "getLatestLageCheck"); // Sprint-1-Haertung
  const pStore = await readStore(pKey(tenantId));
  const eigen = lageCheckAusSpeicher(pStore, tenantId);
  if (eigen) return eigen;
  const mainStore = await readStore("main");
  return lageCheckAusSpeicher(pStore, tenantId, mainStore);
}

// ── REINE AUSWERTER auf einem BEREITS GELESENEN Mandantenspeicher ────────────
// Beide mandantenbezogenen Signale des Gesundheitsberichts (juengster Lage-Check,
// Push-Uebersicht) liegen in DERSELBEN helmut_store-Zeile `main-p-<mandat>`
// (readSupabaseStore, Zeile ~471). Sie getrennt zu lesen waere derselbe Zugriff,
// zweimal bezahlt. Diese beiden Funktionen tragen die Mandantenpruefung — der
// Filter `politicianId === tenantId` bleibt WOERTLICH derselbe wie im Einzelpfad,
// damit eine gebuendelte Antwort kein Loch in die Mandantentrennung reisst.
function lageCheckAusSpeicher(store, tenantId, mainStore = null) {
  const id = assertTenant(tenantId, "lageCheckAusSpeicher");
  const eigen = ((store && store.lageChecks) || []).find((check) => check && check.politicianId === id);
  if (eigen) return eigen;
  return ((mainStore && mainStore.lageChecks) || []).find((check) => check && check.politicianId === id) || null;
}

function pushUebersichtAusSpeicher(store, tenantId, { limit = 200 } = {}) {
  const id = assertTenant(tenantId, "pushUebersichtAusSpeicher");
  const events = ((store && store.pushEvents) || []).filter((event) => event && event.politicianId === id);
  const subscriptions = ((store && store.pushSubscriptions) || [])
    .filter((item) => item && item.active !== false && item.politicianId === id);
  return { events: events.slice(0, Math.max(0, limit)), subscriptions };
}

// ── GEBUENDELTES LESEN MEHRERER MANDANTENSPEICHER ────────────────────────────
// Die Zeilen liegen alle in helmut_store und unterscheiden sich nur in der `id`
// (`main-p-<mandat>`). Eine `id=in.(...)`-Abfrage holt deshalb mehrere Mandate in
// EINEM Zugriff statt in einem je Mandat.
//
// WARUM NICHT ALLE AUF EINMAL: eine Mandantenzeile traegt den kompletten
// verdichteten Mandantenspeicher (compactPoliticianStore: bis zu 4 Briefings,
// 80 Interaktionen, 120 Themengedaechtnis-Eintraege, 300 Push-Abos, 200
// Push-Ereignisse …). Hundert davon in EINER Antwort waere ein Vielfaches an
// Nutzlast in einer Serverless-Funktion mit hartem Zeit- und Speicherlimit —
// aus 200 kleinen Zugriffen wuerde ein einzelner sehr grosser. Die Stapelgroesse
// ist deshalb bewusst begrenzt und ueber `stapel` einstellbar.
//
// KEIN SCHREIBVORGANG: readSupabaseStore legt eine fehlende Zeile an (Seeding).
// Der Gesundheitsbericht ist REIN LESEND — hier wird eine fehlende Zeile als
// leerer Standardspeicher behandelt, ohne sie anzulegen.
//
// FEHLER UND ZEITBUDGET: ein gescheiterter oder zu langsamer Stapel bricht den
// Lauf NICHT ab. Die betroffenen Mandate landen in `fehler` und werden vom
// Aufrufer als „Status nicht bestimmbar" ausgewiesen — nie als leerer Speicher.
async function leseMandantenSpeicherGebuendelt(tenantIds = [], {
  stapel = Number(process.env.HELMUT_STORE_BUNDLE_SIZE || 10),
  parallel = 2,
  zeitbudgetMs = Number(process.env.HELMUT_STORE_BUNDLE_BUDGET_MS || 20000),
  jetzt = () => Date.now()
} = {}) {
  const ids = [...new Set((Array.isArray(tenantIds) ? tenantIds : [])
    .map((t) => assertTenant(t, "leseMandantenSpeicherGebuendelt")))];
  const speicher = new Map();
  const fehler = new Map();
  if (!ids.length) return { speicher, fehler, abfragen: 0 };

  // Ohne Supabase (lokal/Test) gibt es keine gemeinsame Tabelle — dann bleibt es
  // beim Einzellesen je Datei. Das ist der Entwicklungspfad, nicht Production.
  if (!useSupabase()) {
    for (const id of ids) {
      try { speicher.set(id, await readStore(pKey(id))); }
      catch (error) { fehler.set(id, String((error && error.message) || "lesefehler").slice(0, 160)); }
    }
    return { speicher, fehler, abfragen: ids.length };
  }

  const groesse = Math.max(1, Number(stapel) || 10);
  const stapelListe = [];
  for (let i = 0; i < ids.length; i += groesse) stapelListe.push(ids.slice(i, i + groesse));
  const start = jetzt();
  let abfragen = 0;
  let index = 0;

  const arbeiter = async () => {
    while (index < stapelListe.length) {
      const meiner = stapelListe[index];
      index += 1;
      if (jetzt() - start > zeitbudgetMs) {
        for (const id of meiner) fehler.set(id, "zeitbudget-erschoepft");
        continue;
      }
      const inListe = meiner.map((id) => `"${supabaseStoreId}-${pKey(id)}"`).join(",");
      try {
        abfragen += 1;
        const rows = await withStoreRetry(
          () => supabaseRequest(`/rest/v1/helmut_store?id=in.(${encodeURIComponent(inListe)})&select=id,data`),
          { label: "blob-read-gebuendelt", storeKey: `stapel:${meiner.length}` }
        );
        const nachId = new Map();
        for (const row of Array.isArray(rows) ? rows : []) {
          if (row && row.id) nachId.set(String(row.id), row.data);
        }
        for (const id of meiner) {
          const daten = nachId.get(`${supabaseStoreId}-${pKey(id)}`);
          // Fehlende Zeile = leerer Speicher, NICHT angelegt (rein lesend).
          const store = daten ? normalizePoliticianStore(daten) : defaultPoliticianStore();
          speicher.set(id, store);
          storeCacheMap.set(pKey(id), { data: store, at: jetzt() });
        }
      } catch (error) {
        const grund = String((error && error.message) || "lesefehler").slice(0, 160);
        for (const id of meiner) fehler.set(id, grund);
      }
    }
  };

  await Promise.all(Array.from({ length: Math.max(1, Math.min(Number(parallel) || 2, stapelListe.length)) }, arbeiter));
  return { speicher, fehler, abfragen };
}

async function getLageChecks(politicianId, limit = 12) {
  // Tenant-Haertung (Audit-Fix 2026-07): Der weiche Filter '!politicianId ||'
  // gab bei fehlendem Mandanten-Kontext ALLE Zeilen (inkl. Main-Store-Fallback)
  // zurueck. Da RLS heute inert ist (service_role), ist die App-Schicht die
  // EINZIGE Verteidigung — fehlender Kontext ist jetzt ein harter Fehler
  // (TenantContextError) statt eines potenziellen Cross-Tenant-Leaks.
  const tenantId = assertTenant(politicianId, "getLageChecks");
  const pStore = await readStore(pKey(tenantId));
  const checks = (pStore.lageChecks || []).filter((check) => check.politicianId === tenantId);
  if (checks.length) return checks.slice(0, limit);
  const mainStore = await readStore("main");
  return (mainStore.lageChecks || []).filter((check) => check.politicianId === tenantId).slice(0, limit);
}

async function savePipelineDebugReport(report) {
  const key = pKey(report.politicianId);
  const store = await readStore(key);
  const entry = {
    id: report.id || `pipeline-debug-${Date.now()}`,
    createdAt: new Date().toISOString(),
    ...report
  };
  store.pipelineDebugReports = [entry, ...(store.pipelineDebugReports || []).filter((item) => item.id !== entry.id)].slice(0, 20);
  await writeStore(store, key);
  return entry;
}

async function getLatestPipelineDebugReport(politicianId) {
  const tenantId = assertTenant(politicianId, "getLatestPipelineDebugReport"); // Sprint-1-Haertung
  const pStore = await readStore(pKey(tenantId));
  return (pStore.pipelineDebugReports || []).find((report) => report.politicianId === tenantId) || null;
}

// P1-5 (Watchdog OUTPUT-Frische): jüngstes VERSTANDENES Knowledge-Object.
// Ersetzt die build-zeit-blinde `generatedAt`-Prüfung (briefingContract.js:743),
// die die Briefing-Frische immer als "frisch" meldete (false-green). Liefert den
// ISO-Timestamp des neuesten complete-KO (mandantenlos/global) oder null.
// Read-only, fail-safe (null bei jedem Fehler → Aufrufer behandelt als "unbekannt").
async function getLatestCompleteKnowledgeObjectAt() {
  try {
    const rows = await supabaseRequest(
      `/rest/v1/knowledge_objects?select=created_at&understanding_status=eq.complete&order=created_at.desc&limit=1`
    );
    const row = Array.isArray(rows) ? rows[0] : null;
    return row?.created_at || null;
  } catch {
    return null;
  }
}

// P1-4 (Watchdog Recovery-Hysterese): persistiert den zuletzt klassifizierten
// Betriebszustand pro Profil, damit der Zustand "Erholt" (vorher kritisch/veraltet,
// jetzt wieder gesund) über Zyklen hinweg erkannt werden kann. Kleiner Marker
// (analog lageChecks), fail-safe: Schreibfehler brechen den Health-Report NICHT ab.
async function saveWatchdogState(politicianId, state) {
  try {
    const key = pKey(politicianId);
    const store = await readStore(key);
    const entry = { state, createdAt: new Date().toISOString(), politicianId: politicianId || null };
    store.watchdogStates = [entry, ...(store.watchdogStates || [])].slice(0, 20);
    await writeStore(store, key);
    return entry;
  } catch {
    return null;
  }
}

// F5-Vorbereitung (Härtungs-Sprint): Zustellstatus des Monitoring-Webhooks im
// Auth-Store persistieren — nur technische Metadaten (eventId/Status/Versuche),
// nie Payload-Inhalte. Fail-safe: Fehler geben null zurück, kein Cron bricht ab.
async function saveMonitoringDeliveryState(entry = {}) {
  try {
    const store = await readAuthStore();
    const kompakt = {
      eventId: String(entry.eventId || "").slice(0, 80),
      eventType: String(entry.eventType || "").slice(0, 24),
      sent: entry.sent === true,
      status: Number.isFinite(Number(entry.status)) ? Number(entry.status) : null,
      reason: entry.reason == null ? null : String(entry.reason).slice(0, 200),
      attempts: Number.isFinite(Number(entry.attempts)) ? Number(entry.attempts) : 0,
      at: entry.at || new Date().toISOString(),
      // Zuletzt zugestellte Ereigniskennungen (Dedupe-Gedächtnis, max 20 ids).
      recentEventIds: Array.isArray(entry.recentEventIds)
        ? entry.recentEventIds.filter(Boolean).map((id) => String(id).slice(0, 80)).slice(0, 20)
        : []
    };
    await writeAuthStore({ ...store, monitoringWebhookDelivery: kompakt });
    return kompakt;
  } catch {
    return null;
  }
}

async function getMonitoringDeliveryState() {
  try {
    const store = await readAuthStore();
    return store.monitoringWebhookDelivery || null;
  } catch {
    return null;
  }
}

async function getLatestWatchdogState(politicianId) {
  try {
    const store = await readStore(pKey(politicianId));
    return (store.watchdogStates || [])[0] || null;
  } catch {
    return null;
  }
}

async function saveTask(task) {
  const key = pKey(task.politicianId);
  const store = await readStore(key);
  const taskWithMeta = {
    ...task,
    updatedAt: new Date().toISOString()
  };
  const existingIndex = store.tasks.findIndex((entry) => entry.id === taskWithMeta.id);
  if (existingIndex >= 0) store.tasks[existingIndex] = { ...store.tasks[existingIndex], ...taskWithMeta };
  else store.tasks.unshift(taskWithMeta);
  await writeStore(store, key);
  return taskWithMeta;
}

async function getTasks(politicianId) {
  // Tenant-Haertung (Audit-Fix 2026-07): Der weiche Filter '!politicianId ||'
  // gab bei fehlendem Mandanten-Kontext ALLE Zeilen (inkl. Main-Store-Fallback)
  // zurueck. Da RLS heute inert ist (service_role), ist die App-Schicht die
  // EINZIGE Verteidigung — fehlender Kontext ist jetzt ein harter Fehler
  // (TenantContextError) statt eines potenziellen Cross-Tenant-Leaks.
  const tenantId = assertTenant(politicianId, "getTasks");
  const pStore = await readStore(pKey(tenantId));
  const tasks = (pStore.tasks || []).filter((task) => task.politicianId === tenantId);
  if (tasks.length) return tasks;
  const mainStore = await readStore("main");
  return (mainStore.tasks || []).filter((task) => task.politicianId === tenantId);
}

async function updateTaskStatus(taskId, status, politicianId) {
  const key = pKey(politicianId);
  const store = await readStore(key);
  const task = store.tasks.find((entry) => entry.id === taskId);
  if (!task) {
    // Fallback: Task koennte noch im Main-Store liegen (Alt-/Pilotdaten vor der
    // Mandantentrennung). SICHERHEIT: wie in getTasks zusaetzlich auf politicianId
    // filtern — sonst koennte ein anderer Mandant per erratener/bekannter Legacy-taskId
    // eine fremde Aufgabe umschreiben (Mandantenbruch).
    const mainStore = await readStore("main");
    const mainTask = (mainStore.tasks || []).find(
      (entry) => entry.id === taskId && (!politicianId || entry.politicianId === politicianId)
    );
    if (!mainTask) return null;
    mainTask.status = status;
    mainTask.updatedAt = new Date().toISOString();
    await writeStore(mainStore, "main");
    return mainTask;
  }
  task.status = status;
  task.updatedAt = new Date().toISOString();
  await writeStore(store, key);
  return task;
}

async function saveInteraction(interaction) {
  const key = pKey(interaction.politicianId);
  const store = await readStore(key);
  const entry = {
    id: interaction.id || `interaction-${Date.now()}`,
    createdAt: new Date().toISOString(),
    ...interaction
  };
  store.interactions = [entry, ...store.interactions].slice(0, 4000);
  store.personalizedRecommendations = updateRecommendationFromInteraction(store.personalizedRecommendations || [], entry);
  await writeStore(store, key);
  return entry;
}

async function getInteractions(politicianId) {
  // Tenant-Haertung (Audit-Fix 2026-07): Der weiche Filter '!politicianId ||'
  // gab bei fehlendem Mandanten-Kontext ALLE Zeilen (inkl. Main-Store-Fallback)
  // zurueck. Da RLS heute inert ist (service_role), ist die App-Schicht die
  // EINZIGE Verteidigung — fehlender Kontext ist jetzt ein harter Fehler
  // (TenantContextError) statt eines potenziellen Cross-Tenant-Leaks.
  const tenantId = assertTenant(politicianId, "getInteractions");
  const pStore = await readStore(pKey(tenantId));
  const interactions = (pStore.interactions || []).filter((entry) => entry.politicianId === tenantId);
  if (interactions.length) return interactions;
  const mainStore = await readStore("main");
  return (mainStore.interactions || []).filter((entry) => entry.politicianId === tenantId);
}

// Feedback wird im Main-Store als flache Liste gehalten, damit der Admin alle
// Rueckmeldungen mandatsuebergreifend sehen kann. Additiv, kein bestehendes Feld.
async function saveFeedback(feedback = {}) {
  const store = await readStore("main");
  store.feedback = store.feedback || [];
  const entry = {
    id: `feedback-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    createdAt: new Date().toISOString(),
    done: false,
    ...feedback
  };
  store.feedback = [entry, ...store.feedback].slice(0, 2000);
  await writeStore(store, "main");
  return entry;
}

async function listFeedback(limit = 100) {
  const store = await readStore("main");
  return (store.feedback || []).slice(0, Math.max(0, limit));
}

async function setFeedbackDone(id, done = true) {
  const store = await readStore("main");
  store.feedback = store.feedback || [];
  const entry = store.feedback.find((item) => item.id === id);
  if (!entry) return null;
  entry.done = !!done;
  entry.updatedAt = new Date().toISOString();
  await writeStore(store, "main");
  return entry;
}

// Mehrmandantenfaehigkeit Phase 3: Default AUS (HELMUT_PROFILE_DB_MODE). Solange
// das Flag fehlt, liest/schreibt getProfile/saveProfile UNVERAENDERT nur den
// Blob (bytegleiches Verhalten wie vor diesem Sprint). Nach Aktivierung liest
// getProfile zuerst profiles+mandate_profiles (SQL); findet sich dort nichts,
// greift der bisherige Blob-Fallback unveraendert weiter. saveProfile schreibt
// danach IMMER weiter in den Blob (Fallback bleibt aktuell) UND zusaetzlich in
// die SQL-Tabellen, wenn das Flag an ist. Siehe docs/multitenancy-profilmodell.md.
function profileDbModeEnabled() {
  return isFlagOn(process.env.HELMUT_PROFILE_DB_MODE) && v3StoreReady();
}

// Stufe E (Exklusivmodus): Mandatsprofile liegen AUSSCHLIESSLICH relational
// (profiles + mandate_profiles). saveProfile schreibt dann KEINEN globalen
// helmut_store-Blob mehr, getProfile liest ohne Blob-Fallback. Implizit setzt
// dieser Modus profileDbModeEnabled() voraus (und damit v3StoreReady + Supabase).
// Default AUS -> byte-identisches Verhalten wie Stufe D (Dual Write). Rollback
// E -> D ist ein reiner Flag-Flip (HELMUT_PROFILE_DB_EXCLUSIVE=off).
function profileDbExclusiveEnabled() {
  return profileDbModeEnabled() && isFlagOn(process.env.HELMUT_PROFILE_DB_EXCLUSIVE);
}

// SR §37.5 (4): Ein Betreiberwerkzeug muss VOR dem scharfen Vorgang ausweisen
// koennen, WOHIN es tatsaechlich schreibt und mit welchen wirksamen Werten.
// Bis 2026-09-04 stand davon nichts in der Ausgabe — ein fehlendes
// HELMUT_STORAGE_BACKEND haette unbemerkt relationale Zeilen nach Production und
// Blob/Konten in lokale Dateien geschrieben.
//
// REIN LESEND: liest ausschliesslich process.env, keine Netz-, keine DB-Zugriffe,
// legt keine Zeile an. Die Regeln stehen in `speicherpfad-vorflug.js` — hier nur
// die Durchreiche, damit es keine zweite Wahrheit gibt.
const speicherziel = VORFLUG.speicherziel;


// Divergenz-/Fallback-Telemetrie (nur In-Prozess-Zaehler, KEIN persistenter Write
// auf dem Lesepfad): zaehlt, wie oft im Dual-Write-Modus (Stufe D) ein SQL-Miss
// auf den Blob zurueckfiel. Im Exklusivmodus (Stufe E) gibt es diesen Fallback
// nicht mehr -> ein dauerhaft steigender Zaehler in Stufe D signalisiert, dass der
// Backfill noch nicht vollstaendig ist (Freigabekriterium fuer den Cutover E).
let _profileBlobReadFallbacks = 0;
function getProfileTelemetry() {
  return { blobReadFallbacks: _profileBlobReadFallbacks };
}

async function getProfile(profileId, deps = {}) {
  if (profileDbModeEnabled()) {
    const fromDb = await getProfileFromDb(profileId, deps);
    if (fromDb) return fromDb;
    // Exklusivmodus: relationaler Store ist die alleinige Wahrheit. Ein SQL-Miss
    // heisst "Profil existiert nicht" — bewusst KEIN Blob-Read, damit das Lesen
    // nachweislich ohne helmut_store funktioniert (Voraussetzung: abgeschlossener
    // Backfill, Runbook). Im reinen DB-Modus (Stufe D) bleibt der Blob-Fallback.
    if (profileDbExclusiveEnabled()) return null;
    _profileBlobReadFallbacks += 1;
  }
  return (await readStore()).profiles?.[profileId] || null;
}

// Liest ALLE Mandatsprofile relational (profiles + mandate_profiles) fuer die
// Admin-Uebersicht/den Profil-Switcher. Legitimer mandantenuebergreifender
// Admin-Read -> service_role. Dualmodus: Fehler -> null fuer den Blob-Fallback.
// Exklusivmodus: Fehler weitergeben, niemals einen leeren Bestand vortaeuschen.
// Soft-geloeschte Zeilen (geloescht_at) werden ausgeblendet.
async function listFullProfilesFromDb(deps = {}) {
  if (!profileDbModeEnabled()) return null;
  const request = deps.request || supabaseRequest;
  try {
    const rows = await request("/rest/v1/profiles?select=*,mandate_profiles(*)&order=id.asc&limit=5000");
    if (!Array.isArray(rows)) throw new Error("Supabase profile list response is not an array");
    const out = [];
    for (const row of rows) {
      // K2: die Skip-Entscheidung (Orphan-/Trigger-Zeile ohne Mandatszeile, Soft-Delete)
      // laeuft ueber DIESELBE pure Projektion wie das Nachweis-CLI — eine Wahrheit.
      if (!relationalesProfilLebenszyklus(row)) continue;
      const mandateRow = Array.isArray(row.mandate_profiles) ? row.mandate_profiles[0] : row.mandate_profiles;
      out.push(fromMandateProfileRow(row, mandateRow));
    }
    return out;
  } catch (error) {
    console.error("[v3Store] listFullProfilesFromDb fehlgeschlagen:", error.message);
    if (profileDbExclusiveEnabled()) throw error;
    return null;
  }
}

// Vereint Blob- und SQL-Profile je id (SQL gewinnt). Im Dual-Write-Modus (Stufe D)
// ist der Blob die garantierte, VOLLSTAENDIGE Wahrheit und die SQL-Tabelle nur eine
// (waehrend des Backfills evtl. noch unvollstaendige) Teilmenge — deshalb MERGE statt
// SQL-only, damit backfill-ausstehende Mandate nicht still aus Switcher/Admin/Cron
// verschwinden (Review-Fix P1) und die Liste mit getProfile (per-id Blob-Fallback)
// konsistent bleibt.
function mergeProfileLists(blobProfiles, sqlProfiles) {
  const byId = new Map();
  for (const p of blobProfiles || []) if (p && p.id) byId.set(p.id, p);
  for (const p of sqlProfiles || []) if (p && p.id) byId.set(p.id, p); // SQL ueberschreibt Blob
  return [...byId.values()];
}

// Vollstaendige Mandatsprofile (alle Felder) fuer die Admin-Ansicht. Read-only.
//  - Exklusivmodus (Stufe E): ausschliesslich SQL (Blob ist per Definition leer).
//  - Dual-Write (Stufe D): Blob (vollstaendig) mit SQL (frisch) vereint.
//  - Flag aus: nur Blob (byte-identisch wie zuvor).
async function listFullProfiles(deps = {}) {
  if (profileDbModeEnabled()) {
    const fromDb = await listFullProfilesFromDb(deps);
    if (profileDbExclusiveEnabled()) return fromDb || [];
    const store = await readStore();
    return mergeProfileLists(Object.values(store.profiles || {}), fromDb || []);
  }
  const store = await readStore();
  return Object.values(store.profiles || {});
}

function toProfileSummary(profile = {}) {
  return {
    id: profile.id,
    fullName: profile.fullName || profile.name || profile.id,
    party: profile.party || "",
    updatedAt: profile.updatedAt || null
  };
}

async function listProfiles(deps = {}) {
  return (await listFullProfiles(deps)).map(toProfileSummary);
}

async function saveProfile(profile, deps = {}) {
  const profileWithMeta = {
    ...profile,
    updatedAt: new Date().toISOString()
  };
  // Stufe E (Exklusivmodus): Mandatsprofile werden AUSSCHLIESSLICH relational
  // gespeichert — KEIN globaler helmut_store-Blob-Write mehr. Da es hier keinen
  // Blob-Fallback beim Schreiben gibt, MUSS ein relationaler Fehler sichtbar
  // werden (strict). Sonst waere ein fehlgeschlagener Save stiller Datenverlust.
  // Damit schreibt PATCH /api/profile/current keinen globalen Blob mehr.
  if (profileDbExclusiveEnabled()) {
    const res = await saveProfileToDb(profileWithMeta, { ...deps, strict: true });
    if (!res || res.saved !== true) {
      throw new Error(`[profil-exklusiv] Relationaler Profil-Write fehlgeschlagen: ${(res && res.reason) || "unbekannt"} (Exklusivmodus, kein Blob-Fallback)`);
    }
    return profileWithMeta;
  }
  // Stufe D / Baseline: Blob bleibt IMMER die erste, garantierte Schreiboperation
  // (Fallback-Treue). Der SQL-Schreibpfad ist rein additiv (Dual Write) und darf
  // den Blob-Erfolg nie verhindern (daher kein throw um den Rueckgabewert herum).
  const store = await readStore();
  store.profiles = store.profiles || {};
  store.mandateProfiles = store.mandateProfiles || {};
  store.profiles[profile.id] = profileWithMeta;
  store.mandateProfiles[profile.id] = toMandateProfile(profileWithMeta);
  await writeStore(store);
  if (profileDbModeEnabled()) await saveProfileToDb(profileWithMeta, deps);
  return profileWithMeta;
}

// Einmaliger Blob-Profil-Purge fuer den Wechsel in den Exklusivmodus (Stufe E).
// Entfernt eingefrorene Profilkopien (profiles/mandateProfiles) aus dem main-Blob,
// die nach dem Cutover nur noch tote Duplikate der relationalen Wahrheit sind.
//
// SICHERHEIT (fail-safe, kein Datenverlust): Es wird NUR eine Blob-Kopie entfernt,
// deren Profil relational NACHWEISLICH vorhanden ist (getProfileFromDb-Treffer).
// Fehlt ein Blob-Profil relational (Backfill noch nicht gelaufen), bleibt es
// UNANGETASTET und wird als skippedNoSql ausgewiesen -> zuerst Backfill fahren.
// Dry-Run ist Default; erst opts.execute=true schreibt. Erfordert aktiven DB-Modus
// (sonst laesst sich die relationale Praesenz nicht pruefen).
async function purgeBlobProfiles(opts = {}) {
  const execute = opts.execute === true;
  if (!profileDbModeEnabled()) {
    return { execute, error: "profile-db-mode-off", candidates: 0, purgeable: 0, skippedNoSql: [], purged: 0, written: false };
  }
  const getFromDb = opts.getFromDb || ((id) => getProfileFromDb(id));
  const store = await readStore("main");
  const blobIds = Object.keys(store.profiles || {});
  const report = { execute, candidates: blobIds.length, purgeable: 0, skippedNoSql: [], purged: 0, written: false };
  const removable = [];
  for (const id of blobIds) {
    const inSql = await getFromDb(id);
    if (inSql) removable.push(id);
    else report.skippedNoSql.push(id);
  }
  report.purgeable = removable.length;
  if (!execute || !removable.length) return report;
  for (const id of removable) {
    delete store.profiles[id];
    if (store.mandateProfiles) delete store.mandateProfiles[id];
  }
  report.purged = removable.length;
  await writeStore(store, "main");
  report.written = true;
  return report;
}

async function savePersonalizedRecommendations(politicianId, recommendations = []) {
  const key = pKey(politicianId);
  const store = await readStore(key);
  const others = (store.personalizedRecommendations || []).filter((entry) => entry.user_id !== politicianId);
  store.personalizedRecommendations = [...recommendations, ...others].slice(0, 4000);
  await writeStore(store, key);
  return recommendations;
}

async function savePoliticalItems(items = [], politicianId) {
  const key = pKey(politicianId);
  const store = await readStore(key);
  const byId = new Map((store.politicalItems || []).map((item) => [item.id, item]));
  items.forEach((item) => byId.set(item.id, { ...(byId.get(item.id) || {}), ...item }));
  store.politicalItems = Array.from(byId.values()).sort((a, b) => new Date(b.updated_at || b.created_at || 0) - new Date(a.updated_at || a.created_at || 0)).slice(0, 1000);
  await writeStore(store, key);
  return items;
}

async function savePriorityChanges(changes = [], politicianId) {
  if (!changes.length) return [];
  const key = pKey(politicianId);
  const store = await readStore(key);
  store.priorityChanges = [...changes, ...(store.priorityChanges || [])].slice(0, 500);
  await writeStore(store, key);
  return changes;
}

async function getUserNotes(politicianId) {
  // Tenant-Haertung (Audit-Fix 2026-07): Der weiche Filter '!politicianId ||'
  // gab bei fehlendem Mandanten-Kontext ALLE Zeilen (inkl. Main-Store-Fallback)
  // zurueck. Da RLS heute inert ist (service_role), ist die App-Schicht die
  // EINZIGE Verteidigung — fehlender Kontext ist jetzt ein harter Fehler
  // (TenantContextError) statt eines potenziellen Cross-Tenant-Leaks.
  const tenantId = assertTenant(politicianId, "getUserNotes");
  const pStore = await readStore(pKey(tenantId));
  const notes = (pStore.userNotes || []).filter((note) => note.user_id === tenantId);
  if (notes.length) return notes;
  const mainStore = await readStore("main");
  return (mainStore.userNotes || []).filter((note) => note.user_id === tenantId);
}

async function saveUserNote(note) {
  const ownerPoliticianId = note.user_id || note.politicianId;
  const key = pKey(ownerPoliticianId);
  const store = await readStore(key);
  const now = new Date().toISOString();
  const noteWithMeta = {
    id: note.id || `note-${Date.now()}`,
    user_id: ownerPoliticianId || "unknown",
    recommendation_id: note.recommendation_id || note.recommendationId || "",
    political_item_id: note.political_item_id || note.politicalItemId || "",
    type: note.type || "note",
    text: String(note.text || "").trim(),
    status: note.status || "open",
    created_at: note.created_at || now,
    updated_at: now
  };
  const existingIndex = store.userNotes.findIndex((entry) => entry.id === noteWithMeta.id);
  if (existingIndex >= 0) store.userNotes[existingIndex] = { ...store.userNotes[existingIndex], ...noteWithMeta };
  else store.userNotes.unshift(noteWithMeta);
  await writeStore(store, key);
  return noteWithMeta;
}

async function savePushSubscription(politicianId, subscription, meta = {}) {
  const key = pKey(politicianId);
  const store = await readStore(key);
  const now = new Date().toISOString();
  const endpoint = String(subscription?.endpoint || "").trim();
  if (!endpoint) { const e = new Error("Push subscription endpoint missing"); e.statusCode = 400; throw e; }
  // Ohne p256dh/auth kann spaeter NIE ein Push zugestellt werden. Frueher wurde
  // so ein kaputtes Abo als Erfolg gespeichert (Zustellung scheiterte still).
  // Jetzt: bei fehlenden Keys 400 statt Schein-Erfolg.
  const keys = subscription && subscription.keys;
  if (!keys || !String(keys.p256dh || "").trim() || !String(keys.auth || "").trim()) {
    const e = new Error("Push subscription keys missing"); e.statusCode = 400; throw e;
  }
  const entry = {
    id: `push-${politicianId}-${hashStable(endpoint).slice(0, 18)}`,
    politicianId,
    endpoint,
    subscription,
    userAgent: meta.userAgent || "",
    createdAt: meta.createdAt || now,
    updatedAt: now,
    active: true
  };
  store.pushSubscriptions = [
    entry,
    ...(store.pushSubscriptions || []).filter((item) => item.endpoint !== endpoint)
  ].slice(0, 300);
  await writeStore(store, key);
  return entry;
}

async function removePushSubscription(politicianId, endpoint) {
  const key = pKey(politicianId);
  const store = await readStore(key);
  const before = (store.pushSubscriptions || []).length;
  store.pushSubscriptions = (store.pushSubscriptions || []).filter((item) => {
    if (politicianId && item.politicianId !== politicianId) return true;
    return item.endpoint !== endpoint;
  });
  await writeStore(store, key);
  return { removed: before - store.pushSubscriptions.length };
}

async function getPushSubscriptions(politicianId) {
  const tenantId = assertTenant(politicianId, "getPushSubscriptions"); // Sprint-1-Haertung
  const pStore = await readStore(pKey(tenantId));
  return (pStore.pushSubscriptions || []).filter((item) => item.active !== false && item.politicianId === tenantId);
}

async function savePushEvent(event) {
  const key = pKey(event.politicianId);
  const store = await readStore(key);
  const entry = {
    id: event.id || `push-event-${event.politicianId || "unknown"}-${Date.now()}`,
    createdAt: new Date().toISOString(),
    ...event
  };
  store.pushEvents = [entry, ...(store.pushEvents || []).filter((item) => item.id !== entry.id)].slice(0, 200);
  await writeStore(store, key);
  return entry;
}

async function getPushEventByDedupeKey(politicianId, dedupeKey) {
  const tenantId = assertTenant(politicianId, "getPushEventByDedupeKey"); // Sprint-1-Haertung
  if (!dedupeKey) return null;
  const pStore = await readStore(pKey(tenantId));
  return (pStore.pushEvents || []).find((event) => event.politicianId === tenantId && event.dedupeKey === dedupeKey) || null;
}

async function listPushEvents(politicianId, limit = 200) {
  const tenantId = assertTenant(politicianId, "listPushEvents"); // Sprint-1-Haertung
  const pStore = await readStore(pKey(tenantId));
  const events = (pStore.pushEvents || []).filter((event) => event.politicianId === tenantId);
  return events.slice(0, Math.max(0, limit));
}

// ── DSGVO-Vollstaendigkeit (Audit-Fix 2026-07) ───────────────────────────────
// Export (Art. 15/20) und Loeschung (Art. 17) erfassten frueher NUR den Blob-Store.
// Die produktiven V3-Relationstabellen mit user_id-Daten (briefings, decisions,
// mandate_profiles, matching_results, profile_embeddings, office_outputs, ...)
// und der Auth-Store (Konto, Sessions, Zuweisungen, Audit, KI-Nutzungslog)
// blieben vollstaendig erhalten — der Nutzer erhielt trotzdem eine Erfolgsmeldung.
// Jetzt decken exportProfileData/deleteProfileData ALLE drei Speicherorte ab.
// Alle Nutzertabellen (Kinder) werden EXPLIZIT geloescht (idempotent, erfasst
// auch verwaiste Zeilen ohne profiles-Elternzeile); profiles zuletzt (deren
// on-delete-cascade ist damit nur noch Sicherheitsnetz).
const V3_PRIVACY_CHILD_TABLES = [
  { table: "mandate_profiles", key: "user_id" },
  { table: "briefings", key: "user_id" },
  { table: "decisions", key: "user_id" },
  { table: "matching_results", key: "user_id" },
  // Sprint 23B-1: Auditprotokoll. FK auf profiles mit ON DELETE CASCADE loescht
  // ohnehin mit; der explizite Eintrag haelt die DSGVO-Loeschung vollstaendig
  // und unabhaengig von der Kaskade nachweisbar.
  { table: "matching_runs", key: "user_id" },
  { table: "profile_embeddings", key: "user_id" },
  { table: "office_outputs", key: "user_id" },
  { table: "matching_weights", key: "user_id" },
  { table: "topic_memory", key: "user_id" },
  { table: "interactions", key: "user_id" },
  { table: "user_notes", key: "user_id" },
  { table: "daily_tasks", key: "user_id" },
  { table: "communication_drafts", key: "user_id" },
  { table: "political_items", key: "user_id" },
  { table: "personalized_recommendations", key: "user_id" },
  { table: "priority_changes", key: "user_id" },
  // Kein FK auf profiles — MUSS explizit geloescht werden. Nur Meta-Daten
  // (Tokens/Kosten/Modell), keine Inhalte; drei moegliche Zuordnungsspalten.
  { table: "llm_usage", or: ["politician_id", "user_id", "profile_id"] }
];

function v3PrivacyFilter(t, politicianId) {
  const id = encodeURIComponent(politicianId);
  return t.or
    ? `or=(${t.or.map((k) => `${k}.eq.${id}`).join(",")})`
    : `${t.key || "user_id"}=eq.${id}`;
}

async function exportProfileDataV3(politicianId, deps = {}) {
  const ready = deps.ready !== undefined ? deps.ready : v3StoreReady();
  if (!ready) {
    // EHRLICHKEIT (Review-Fix, wie deleteProfileDataV3): Fehlkonfiguration
    // (Flag an, Supabase-Zugang fehlt) macht den Export sichtbar unvollstaendig.
    const reason = deps.reason !== undefined ? deps.reason : v3SkipReason();
    return { skipped: true, reason, vollstaendig: reason !== "v3-store-unavailable" };
  }
  const request = deps.request || supabaseRequest;
  const out = { skipped: false, vollstaendig: true, tabellen: {} };
  const tables = [...V3_PRIVACY_CHILD_TABLES, { table: "profiles", key: "id" }];
  // Paginiert lesen (Review-Fix): ein hartes limit=2000 hätte bei vielen Zeilen
  // (z. B. llm_usage/briefings) STILL abgeschnitten und den Export trotzdem als
  // vollständig gemeldet — ein DSGVO-Auskunftsfehler. Jetzt vollständige
  // Pagination je Tabelle; bei Read-Fehler wird die Tabelle ehrlich als
  // unvollständig markiert.
  const PAGE = 1000;
  for (const t of tables) {
    try {
      const rows = [];
      for (let offset = 0; ; offset += PAGE) {
        // order=id.asc (Review-Fix): LIMIT/OFFSET ueber mehrere separate Requests
        // ist OHNE ORDER BY nicht stabil — Zeilen koennten still doppelt oder gar
        // nicht exportiert werden. Alle Privacy-Tabellen haben id als PK.
        const page = await request(`/rest/v1/${t.table}?${v3PrivacyFilter(t, politicianId)}&order=id.asc&limit=${PAGE}&offset=${offset}`, { method: "GET" });
        if (!Array.isArray(page) || page.length === 0) break;
        rows.push(...page);
        if (page.length < PAGE) break;
        if (rows.length > 200000) { out.vollstaendig = false; break; } // Sicherheitsdeckel
      }
      out.tabellen[t.table] = rows;
    } catch (error) {
      // Ehrlichkeit vor Bequemlichkeit: ein fehlgeschlagener Tabellen-Read macht
      // den Export sichtbar UNVOLLSTAENDIG statt still leer.
      out.vollstaendig = false;
      out.tabellen[t.table] = { fehler: String(error && error.message || "read-failed").slice(0, 200) };
    }
  }
  return out;
}

async function deleteProfileDataV3(politicianId, deps = {}) {
  const ready = deps.ready !== undefined ? deps.ready : v3StoreReady();
  if (!ready) {
    // EHRLICHKEIT (Review-Fix): "Flag an, aber Supabase-Zugang fehlt" ist eine
    // FEHLKONFIGURATION — die V3-Zeilen blieben dann unangetastet, waehrend die
    // Loeschung frueher trotzdem ok:true meldete (fail-open). Nur das bewusst
    // deaktivierte V3 (lokaler Modus) ist ein legitimer Skip.
    const reason = deps.reason !== undefined ? deps.reason : v3SkipReason();
    return { skipped: true, reason, ok: reason !== "v3-store-unavailable" };
  }
  const request = deps.request || supabaseRequest;
  const result = { skipped: false, ok: true, geloescht: {}, fehler: [] };
  const tables = [...V3_PRIVACY_CHILD_TABLES, { table: "profiles", key: "id" }];
  for (const t of tables) {
    try {
      const rows = await request(`/rest/v1/${t.table}?${v3PrivacyFilter(t, politicianId)}`, {
        method: "DELETE",
        headers: { Prefer: "return=representation" }
      });
      result.geloescht[t.table] = Array.isArray(rows) ? rows.length : 0;
    } catch (error) {
      result.ok = false;
      result.fehler.push({ tabelle: t.table, fehler: String(error && error.message || "delete-failed").slice(0, 200) });
    }
  }
  return result;
}

async function exportProfileData(politicianId) {
  const [store, pStore] = await Promise.all([readStore("main"), readStore(pKey(politicianId))]);
  // SQL-aware, aber BLOB-TREU: Ist das Profil im Blob vorhanden (Flag aus ODER
  // Dual-Write, wo der Blob weiterhin vollstaendig geschrieben wird), wird der
  // EXAKTE Blob-Wert exportiert — byte-identisch zum bisherigen Export, ohne den
  // normalisierenden/lossy SQL-Roundtrip (faction<-party, leere Arrays gedroppt,
  // updatedAt aus DB). NUR im Exklusivmodus (Blob leer) wird relational gelesen.
  const profile = store.profiles?.[politicianId] || (profileDbModeEnabled() ? await getProfile(politicianId) : null) || null;
  // V3-Tabellen + Auth-Store gehoeren zum Export (Art. 15/20) — Fehler dort
  // machen den Export sichtbar unvollstaendig, verhindern ihn aber nicht.
  const accounts = require("./accounts");
  const [v3, authDaten] = await Promise.all([
    exportProfileDataV3(politicianId).catch((e) => ({ skipped: false, vollstaendig: false, fehler: String(e && e.message || "v3-export-failed").slice(0, 200) })),
    accounts.exportAuthDataForPolitician(politicianId).catch((e) => ({ vollstaendig: false, fehler: String(e && e.message || "auth-export-failed").slice(0, 200) }))
  ]);
  return {
    exportedAt: new Date().toISOString(),
    politicianId,
    // v3.vollstaendig traegt den Skip-Status ehrlich (bewusst aus = vollstaendig,
    // Fehlkonfiguration = unvollstaendig) — kein pauschales skipped-ist-ok mehr.
    vollstaendig: v3.vollstaendig !== false && authDaten.vollstaendig !== false,
    v3Tabellen: v3,
    authDaten,
    profile,
    mandateProfile: store.mandateProfiles?.[politicianId] || (profile ? toMandateProfile(profile) : null),
    briefings: profileRows(pStore.briefings, politicianId),
    tasks: profileRows(pStore.tasks, politicianId),
    interactions: profileRows(pStore.interactions, politicianId),
    topicMemory: profileRows(pStore.topicMemory, politicianId),
    politicalItems: userRows(pStore.politicalItems, politicianId),
    personalizedRecommendations: userRows(pStore.personalizedRecommendations, politicianId),
    dailyTasks: userRows(pStore.dailyTasks, politicianId),
    communicationDrafts: userRows(pStore.communicationDrafts, politicianId),
    userNotes: userRows(pStore.userNotes, politicianId),
    priorityChanges: userRows(pStore.priorityChanges, politicianId),
    lageChecks: profileRows(pStore.lageChecks, politicianId),
    pushSubscriptions: profileRows(pStore.pushSubscriptions, politicianId).map(redactPushSubscription),
    pushEvents: profileRows(pStore.pushEvents, politicianId),
    pipelineDebugReports: profileRows(pStore.pipelineDebugReports, politicianId),
    rawItems: profileRawItems(store.rawItems, profile, politicianId)
  };
}

async function deleteProfileData(politicianId) {
  const [store, pStore] = await Promise.all([readStore("main"), readStore(pKey(politicianId))]);
  // SQL-aware, aber BLOB-TREU (wie exportProfileData): Blob-Wert bevorzugen (Flag
  // aus/Dual-Write), nur im Exklusivmodus relational lesen. Die relationalen
  // Profilzeilen selbst loescht deleteProfileDataV3 (Cascade) weiter unten.
  const profile = store.profiles?.[politicianId] || (profileDbModeEnabled() ? await getProfile(politicianId) : null) || null;
  const before = dataCounts(store, pStore, politicianId, profile);

  // Folge-Fix (P0-Review): den grossen main-Blob NUR schreiben, wenn sich dort
  // tatsaechlich etwas aendert — es existierte eine (ggf. eingefrorene) Blob-
  // Profilkopie ODER dem Profil zugeordnete rawItems werden entfernt. Im
  // Exklusivmodus liegt das Profil relational; ohne Blob-Kopie und ohne eigene
  // rawItems ist der main-Write ein reiner No-op und entfaellt (kein unnoetiger
  // Profil-Blob-Zugriff). Die autoritative Profil-Loeschung erfolgt relational
  // (deleteProfileDataV3, Cascade) — davon unberuehrt.
  const hadBlobProfile = Boolean((store.profiles && store.profiles[politicianId]) || (store.mandateProfiles && store.mandateProfiles[politicianId]));
  if (store.profiles) delete store.profiles[politicianId];
  if (store.mandateProfiles) delete store.mandateProfiles[politicianId];
  const rawBefore = (store.rawItems || []).length;
  store.rawItems = (store.rawItems || []).filter((item) => !rawItemBelongsToProfile(item, profile, politicianId));
  if (hadBlobProfile || store.rawItems.length !== rawBefore) await writeStore(store, "main");
  // Politiker-Store nur leeren, wenn er ueberhaupt Daten traegt (sonst No-op-Write).
  const pStoreHadData = Object.values(pStore || {}).some((v) => Array.isArray(v) && v.length > 0);
  if (pStoreHadData) await writeStore({ ...pStore, ...defaultPoliticianStore() }, pKey(politicianId));

  // DSGVO-Vollstaendigkeit (Audit-Fix 2026-07): V3-Relationstabellen + Auth-Store
  // gehoeren zur Loeschung. Ein Teilfehler dort setzt ok=false — es gibt KEINE
  // Erfolgsmeldung mehr, waehrend Daten zurueckbleiben.
  const accounts = require("./accounts");
  const v3 = await deleteProfileDataV3(politicianId)
    .catch((e) => ({ skipped: false, ok: false, fehler: [{ tabelle: "*", fehler: String(e && e.message || "v3-delete-failed").slice(0, 200) }] }));
  const auth = await accounts.deleteAuthDataForPolitician(politicianId)
    .catch((e) => ({ ok: false, fehler: String(e && e.message || "auth-delete-failed").slice(0, 200) }));
  // OP-25: die Scheduler-Spur des Mandats (nur Metadaten) gehoert zur Loeschung.
  const fairness = await deleteCronFairnessTenant(politicianId);

  const emptyPStore = defaultPoliticianStore();
  const after = dataCounts(store, emptyPStore, politicianId, null);
  return {
    // v3.ok traegt den Skip-Status bereits ehrlich (bewusst deaktiviert = ok,
    // Fehlkonfiguration = nicht ok) — kein pauschales "skipped zaehlt als Erfolg" mehr.
    ok: Boolean(v3.ok && auth.ok && fairness.ok),
    deletedAt: new Date().toISOString(),
    politicianId,
    before,
    after,
    v3Tabellen: v3,
    authDaten: auth,
    schedulerSpur: fairness
  };
}

// STRIKT gescopte Mandanten-Entfernung (Sprint-1-Provisionierung: teardown/rollback).
// Anders als deleteProfileData entfernt sie NUR ausdruecklich EIGENE Daten:
// Profil-Identitaet, den eigenen Content-Store, die V3-Zeilen (user_id-gefiltert) und
// die Auth-Daten. Sie fasst BEWUSST NICHT die geteilten Main-Store-rawItems ueber den
// breiten person/news/term-Match an (rawItemBelongsToProfile) — dessen Termmatch
// koennte beim Entfernen EINES Mandanten auch Rohdaten ANDERER Mandanten
// mitloeschen. Hier werden rawItems nur bei EXPLIZITER Eigentuemerschaft
// (politicianId/profileId/user_id === id) entfernt.
async function deleteTenantScopedData(politicianId) {
  const uid = assertTenant(politicianId, "deleteTenantScopedData");
  const store = await readStore("main");
  const before = {
    profil: store.profiles && store.profiles[uid] ? 1 : 0,
    eigeneRawItems: (store.rawItems || []).filter((item) => item && (item.politicianId === uid || item.profileId === uid || item.user_id === uid)).length
  };
  const hadBlobProfile = Boolean((store.profiles && store.profiles[uid]) || (store.mandateProfiles && store.mandateProfiles[uid]));
  if (store.profiles) delete store.profiles[uid];
  if (store.mandateProfiles) delete store.mandateProfiles[uid];
  const rawBefore = (store.rawItems || []).length;
  store.rawItems = (store.rawItems || []).filter((item) => !(item && (item.politicianId === uid || item.profileId === uid || item.user_id === uid)));
  // Folge-Fix (P0-Review): main-Blob nur bei tatsaechlicher Aenderung schreiben
  // (Blob-Profilkopie vorhanden ODER eigene rawItems entfernt) — sonst No-op.
  if (hadBlobProfile || store.rawItems.length !== rawBefore) await writeStore(store, "main");
  // BEHOBEN 02.09. (adversariale Gegenpruefung, gemessener Befund): hier stand ein
  // UNBEDINGTES `writeStore(defaultPoliticianStore(), pKey(uid))`. Das ist ein
  // Upsert, kein Loeschen — fuer eine Kennung OHNE bestehenden Mandanten-Store
  // legte der Teardown die Zeile damit ERST AN. Eine "vollstaendige Entfernung"
  // der 400er-Testgruppe haette so 400 zusaetzliche Dauerzeilen in `helmut_store`
  // hinterlassen, also genau das Gegenteil ihres Zwecks.
  //
  // NACHGEBESSERT 02.09. (zweiter adversarialer Review): der erste Versuch pruefte
  // mit `readStore`. Das war im Supabase-Pfad KEINE Pruefung: `readSupabaseStore`
  // legte bis zum Lesepfad-Fix vom 06.09. fehlende Zeilen selbst an. Der "Fix" haette die 400 Zeilen
  // also weiterhin erzeugt, nur beim Lesen statt beim Schreiben. Jetzt entscheidet
  // eine Abfrage, die nichts anlegt und den Zwischenspeicher umgeht.
  const pStore = await readStore(pKey(uid), { fresh: true });
  const pStoreHatDaten = Object.values(pStore).some((v) => Array.isArray(v) && v.length > 0);
  if (pStoreHatDaten) await writeStore({ ...pStore, ...defaultPoliticianStore() }, pKey(uid));
  const v3 = await deleteProfileDataV3(uid).catch((e) => ({ ok: false, fehler: [{ tabelle: "*", fehler: String(e && e.message || "v3-delete-failed").slice(0, 200) }] }));
  const auth = await require("./accounts").deleteAuthDataForPolitician(uid).catch((e) => ({ ok: false, fehler: String(e && e.message || "auth-delete-failed").slice(0, 200) }));
  // OP-25: Scheduler-Spur (nur Metadaten) gehoert zum Teardown.
  const fairness = await deleteCronFairnessTenant(uid);
  return {
    ok: Boolean((v3.ok === undefined ? true : v3.ok) && (auth.ok === undefined ? true : auth.ok) && fairness.ok),
    politicianId: uid,
    before,
    v3Tabellen: v3,
    authDaten: auth,
    schedulerSpur: fairness
  };
}

function profileRows(rows = [], politicianId) {
  return (rows || []).filter((row) => row?.politicianId === politicianId || row?.profileId === politicianId);
}

function userRows(rows = [], politicianId) {
  return (rows || []).filter((row) => row?.user_id === politicianId || row?.userId === politicianId || row?.politicianId === politicianId);
}

function withoutProfileRows(rows = [], politicianId) {
  return (rows || []).filter((row) => row?.politicianId !== politicianId && row?.profileId !== politicianId);
}

function withoutUserRows(rows = [], politicianId) {
  return (rows || []).filter((row) => row?.user_id !== politicianId && row?.userId !== politicianId && row?.politicianId !== politicianId);
}

function profileRawItems(rawItems = [], profile, politicianId) {
  return (rawItems || []).filter((item) => rawItemBelongsToProfile(item, profile, politicianId));
}

function rawItemBelongsToProfile(item = {}, profile, politicianId) {
  if (!item || typeof item !== "object") return false;
  if (item.politicianId === politicianId || item.profileId === politicianId || item.user_id === politicianId) return true;
  // MANDANTENTRENNUNG: Ein Personen-Item gehoert NUR dem Mandat, dessen
  // Personenquelle es geliefert hat ("<mandats-id>-news" bzw. deren Legacy-
  // Mehrfachsuchen "<mandats-id>-news-<suffix>"). Frueher galt JEDES Personen-
  // Item als eigen — Export/DSGVO-Loeschung eines Mandanten haette damit die
  // Personen-Rohdaten ALLER Mandanten erfasst.
  if (isOwnPersonNewsItem(item, politicianId)) return true;
  const terms = profileTerms(profile, politicianId);
  const text = `${item.title || ""} ${item.content || ""} ${item.excerpt || ""} ${item.author || ""}`.toLowerCase();
  return terms.some((term) => term && text.includes(term));
}

function isOwnPersonNewsItem(item = {}, politicianId) {
  const own = String(politicianId || "").trim().toLowerCase();
  if (!own) return false;
  const sid = String(item.sourceId || "").trim().toLowerCase();
  // Deckt die dynamische Personenquelle ("<id>-news"), deren Legacy-
  // Mehrfachsuchen ("<id>-news-<suffix>") UND den relationalen Abrufweg-Alias
  // ("rp-<id>-news[-…]") ab — DSGVO-Export/-Loeschung erfasst die eigenen
  // Personen-Rohdaten unabhaengig vom Abrufpfad.
  return sid === `${own}-news` || sid.startsWith(`${own}-news-`)
    || sid === `rp-${own}-news` || sid.startsWith(`rp-${own}-news-`);
}

function profileTerms(profile, politicianId) {
  const fullName = String(profile?.fullName || readableProfileName(politicianId)).trim().toLowerCase();
  const parts = fullName.split(/\s+/).filter(Boolean);
  return Array.from(new Set([
    fullName,
    parts.length > 1 ? parts.at(-1) : "",
    String(politicianId || "").replace(/-/g, " ").toLowerCase()
  ].filter((term) => term && term.length >= 3)));
}

function readableProfileName(politicianId) {
  return String(politicianId || "").split("-").filter(Boolean).join(" ");
}

function redactPushSubscription(entry) {
  return {
    ...entry,
    subscription: entry.subscription ? {
      endpoint: entry.subscription.endpoint,
      keys: entry.subscription.keys ? { p256dh: "[redacted]", auth: "[redacted]" } : undefined
    } : undefined
  };
}

function dataCounts(mainStore, pStore, politicianId, profile) {
  return {
    profile: mainStore.profiles?.[politicianId] ? 1 : 0,
    mandateProfile: mainStore.mandateProfiles?.[politicianId] ? 1 : 0,
    briefings: profileRows(pStore.briefings, politicianId).length,
    tasks: profileRows(pStore.tasks, politicianId).length,
    interactions: profileRows(pStore.interactions, politicianId).length,
    topicMemory: profileRows(pStore.topicMemory, politicianId).length,
    politicalItems: userRows(pStore.politicalItems, politicianId).length,
    personalizedRecommendations: userRows(pStore.personalizedRecommendations, politicianId).length,
    dailyTasks: userRows(pStore.dailyTasks, politicianId).length,
    communicationDrafts: userRows(pStore.communicationDrafts, politicianId).length,
    userNotes: userRows(pStore.userNotes, politicianId).length,
    priorityChanges: userRows(pStore.priorityChanges, politicianId).length,
    lageChecks: profileRows(pStore.lageChecks, politicianId).length,
    pushSubscriptions: profileRows(pStore.pushSubscriptions, politicianId).length,
    pushEvents: profileRows(pStore.pushEvents, politicianId).length,
    pipelineDebugReports: profileRows(pStore.pipelineDebugReports, politicianId).length,
    rawItems: profileRawItems(mainStore.rawItems, profile, politicianId).length
  };
}

function hashStable(value) {
  let hash = 5381;
  const text = String(value || "");
  for (let index = 0; index < text.length; index += 1) {
    hash = ((hash << 5) + hash) + text.charCodeAt(index);
    hash &= 0xffffffff;
  }
  return Math.abs(hash).toString(36);
}

function toMandateProfile(profile) {
  return {
    user_id: profile.id,
    name: profile.fullName,
    partei: profile.party,
    fraktion: profile.faction,
    rolle: profile.function || profile.role,
    politische_ebene: profile.politicalLevel || "Bund",
    wahlkreis: profile.constituency,
    bundesland: profile.state,
    ausschuesse: profile.committees || [],
    berichterstatter_themen: profile.reportingTopics || [],
    fachpolitische_schwerpunkte: profile.focusTopics || [],
    aktuelle_kampagnen: profile.currentCampaigns || [],
    oeffentliche_positionen: profile.publicPositions || [],
    wichtige_zielgruppen: profile.keyAudiences || [],
    kommunikationsstil: profile.communicationStyle,
    risiko_themen: profile.riskTopics || [],
    chancen_themen: profile.opportunityTopics || [],
    no_go_themen: profile.noGoTopics || [],
    bevorzugte_kanaele: profile.preferredChannels || [],
    buero_uebergabe: profile.officeHandoffMethod || "share",
    naechste_termine: profile.upcomingAppointments || [],
    updated_at: profile.updatedAt
  };
}

// --- Mehrmandantenfaehigkeit Phase 3: profiles/mandate_profiles SQL-Pfad -------
// Eigene Spalten-Listen statt Wiederverwendung von toMandateProfile() oben: jene
// Funktion fuellt den Blob-internen store.mandateProfiles-Schluessel und traegt
// Felder (`name`, `buero_uebergabe`, `politische_ebene:"Bund"`), die in der
// REALEN SQL-Tabelle so nicht existieren bzw. deren CHECK-Constraints verletzen
// wuerden (politische_ebene erlaubt nur "bundestag"/"landtag"/NULL). Ein direktes
// Wiederverwenden haette den Upsert an der DB scheitern lassen.
const MANDATE_PROFILE_COLUMNS = [
  "partei", "fraktion", "rolle", "politische_ebene", "wahlkreis", "bundesland",
  "ausschuesse", "berichterstatter_themen", "fachpolitische_schwerpunkte",
  "aktuelle_kampagnen", "oeffentliche_positionen", "wichtige_zielgruppen",
  "kommunikationsstil", "risiko_themen", "chancen_themen", "no_go_themen",
  "bevorzugte_kanaele", "naechste_termine", "namensvarianten",
  "stellvertretende_ausschuesse", "regionale_themen", "regierungsrolle", "aktiv",
  "onboarding_status", "ki_budget_taeglich_cent", "ki_budget_monatlich_cent",
  "datenschutz_bestaetigt_at", "geloescht_at",
  // Phase 15 (Vollstaendigkeit): strukturierte Spalten fuer die uebrigen
  // funktional genutzten Blob-Felder + profil_extras-Auffangbehaelter.
  "relevante_ministerien", "gegner", "monitoring_ziele", "regionale_interessen",
  "themen_prioritaeten", "buero_uebergabe", "profil_extras"
];

// camelCase-Profilfelder, die bereits eine EIGENE Spalte haben (direkt ODER via
// Umbenennung). Alles was NICHT hier steht, wandert verlustfrei in profil_extras,
// damit beim DB-Pfad garantiert kein Feld verloren geht (auch kuenftige). "id" ist
// der Schluessel (profiles.id), "email"/"name" leben in profiles.
const MANDATE_KNOWN_PROFILE_KEYS = new Set([
  "id", "email", "name", "fullName", "party", "faction", "function", "role",
  "politicalLevel", "parliamentType", "constituency", "state", "committee",
  "committees", "focusTopics", "reportingTopics", "currentCampaigns",
  "publicPositions", "keyAudiences", "communicationStyle", "riskTopics",
  "opportunityTopics", "noGoTopics", "preferredChannels", "upcomingAppointments",
  "nameVariants", "deputyCommittees", "regionalTopics", "governmentRole",
  "profileActive", "onboardingStatus", "aiBudgetDailyCents", "aiBudgetMonthlyCents",
  "privacyConfirmedAt", "deletedAt", "updatedAt",
  "relevantMinistries", "opponents", "monitoringTargets", "regionalInterests",
  "topicPriorities", "officeHandoffMethod"
]);

// Sammelt alle Profilfelder OHNE eigene Spalte in ein reines Objekt (fuer
// profil_extras). Bewahrt localMedia/mainQuestion/officeFormats/outputNeeds/
// location/committeeUnknown/... + jedes kuenftige Feld 1:1.
function collectProfileExtras(profile = {}) {
  const extras = {};
  for (const key of Object.keys(profile)) {
    if (!MANDATE_KNOWN_PROFILE_KEYS.has(key) && profile[key] !== undefined) {
      extras[key] = profile[key];
    }
  }
  return extras;
}

function politicalLevelToEbene(profile = {}) {
  const explicit = String(profile.parliamentType || profile.politicalLevel || "").trim().toLowerCase();
  if (explicit.includes("landtag") || explicit.startsWith("land")) return "landtag";
  if (explicit.includes("bundestag") || explicit.startsWith("bund")) return "bundestag";
  return null;
}

// KI-Budget-Spalten (ki_budget_*_cent) sind integer mit CHECK (spalte is null OR
// spalte > 0), Migration 20260712_mandate_profile_fields.sql. Ein ungueltiger
// Nutzerwert (negativ, Dezimal, nicht-numerisch) wird vom toleranten Save-Pfad
// bewusst ROH durchgereicht (server.js budgetCentValue), damit validateProfile ihn
// als "fehlerhaft" melden kann. Wuerde dieser Rohwert 1:1 in die typisierte Spalte
// geschrieben, scheiterte der Upsert an CHECK/Typ — im strict-Exklusivmodus mit
// throw -> HTTP 500 + vollstaendigem Save-Verlust (P1). Daher: nur eine gueltige
// positive Ganzzahl wandert in die Spalte, alles andere -> null (Systemdefault,
// CHECK-konform). Der Rohwert geht NICHT verloren (siehe collectInvalidBudgetExtras
// + fromMandateProfileRow): er bleibt in profil_extras erhalten, sodass das Profil
// unveraendert gespeichert wird UND validateProfile den Fehler weiter anzeigt.
function sanitizeBudgetCent(value) {
  const num = Number(value);
  return Number.isFinite(num) && Number.isInteger(num) && num > 0 ? num : null;
}

// Rohwerte ungueltiger Budgets verlustfrei fuer profil_extras (jsonb, kein CHECK)
// sammeln. 0 ist das dokumentierte Reset-Signal (null=Systemdefault) und KEIN
// Fehler -> nicht aufbewahren. Nur echte Fehleingaben werden erhalten.
function collectInvalidBudgetExtras(profile = {}) {
  const out = {};
  const keep = (key, raw) => {
    if (raw == null || raw === 0) return;
    if (sanitizeBudgetCent(raw) === null) out[key] = raw;
  };
  keep("aiBudgetDailyCents", profile.aiBudgetDailyCents);
  keep("aiBudgetMonthlyCents", profile.aiBudgetMonthlyCents);
  return out;
}

// Internes Profil-Objekt (camelCase, Form wie saveProfile/scheduler-Defaults) -> Zeile
// fuer public.mandate_profiles. Nur Spalten aus MANDATE_PROFILE_COLUMNS, damit
// PostgREST nie an einer unbekannten Spalte scheitert.
function toMandateProfileRow(profile = {}) {
  const row = {
    partei: profile.party || null,
    fraktion: profile.faction || profile.party || null,
    rolle: profile.function || profile.role || null,
    politische_ebene: politicalLevelToEbene(profile),
    wahlkreis: profile.constituency || null,
    bundesland: profile.state || null,
    ausschuesse: profile.committees || (profile.committee ? [profile.committee] : []),
    berichterstatter_themen: profile.reportingTopics || [],
    fachpolitische_schwerpunkte: profile.focusTopics || [],
    aktuelle_kampagnen: profile.currentCampaigns || [],
    oeffentliche_positionen: profile.publicPositions || [],
    wichtige_zielgruppen: profile.keyAudiences || [],
    kommunikationsstil: profile.communicationStyle || null,
    risiko_themen: profile.riskTopics || [],
    chancen_themen: profile.opportunityTopics || [],
    no_go_themen: profile.noGoTopics || [],
    bevorzugte_kanaele: profile.preferredChannels || [],
    naechste_termine: profile.upcomingAppointments || [],
    namensvarianten: profile.nameVariants || [],
    stellvertretende_ausschuesse: profile.deputyCommittees || [],
    regionale_themen: profile.regionalTopics || [],
    regierungsrolle: profile.governmentRole || null,
    aktiv: profile.profileActive !== false,
    onboarding_status: profile.onboardingStatus || "neu",
    ki_budget_taeglich_cent: sanitizeBudgetCent(profile.aiBudgetDailyCents),
    ki_budget_monatlich_cent: sanitizeBudgetCent(profile.aiBudgetMonthlyCents),
    datenschutz_bestaetigt_at: profile.privacyConfirmedAt || null,
    geloescht_at: profile.deletedAt || null,
    // Phase 15 (Vollstaendigkeit): uebrige funktionale Felder + Auffangbehaelter.
    relevante_ministerien: profile.relevantMinistries || [],
    gegner: profile.opponents || [],
    monitoring_ziele: profile.monitoringTargets || [],
    regionale_interessen: profile.regionalInterests || [],
    themen_prioritaeten: (profile.topicPriorities && typeof profile.topicPriorities === "object") ? profile.topicPriorities : {},
    buero_uebergabe: profile.officeHandoffMethod || null,
    // Ungueltige Budget-Rohwerte (aus der typisierten Spalte verdraengt) verlustfrei
    // mit aufnehmen, damit kein Feld verloren geht (kein Datenverlust, Wiederlesen
    // zeigt den Fehler erneut). Gueltige/leere Budgets landen hier NIE (nur Spalte).
    profil_extras: { ...collectProfileExtras(profile), ...collectInvalidBudgetExtras(profile) }
  };
  return pickColumns(row, MANDATE_PROFILE_COLUMNS);
}

// SQL-Zeilen (profiles + mandate_profiles) -> internes Profil-Objekt. Nur belegte
// Felder werden gesetzt (leere Arrays/NULL werden weggelassen), damit
// mergeProfileDefaults()/blankProfile() (server.js, scheduler.js) unveraendert
// neutral auffuellen koennen, statt eine "leere" Personalisierung zu erzwingen.
function fromMandateProfileRow(profilesRow = {}, mandateRow = null) {
  const m = mandateRow || {};
  const arr = (v) => (Array.isArray(v) && v.length ? v : undefined);
  const str = (v) => (v != null && String(v).trim() ? String(v) : undefined);
  const ebene = m.politische_ebene === "landtag" ? "Land" : (m.politische_ebene === "bundestag" ? "Bund" : undefined);
  const parliamentType = m.politische_ebene === "landtag" ? "Landtag" : (m.politische_ebene === "bundestag" ? "Bundestag" : undefined);
  const committees = arr(m.ausschuesse);
  const obj = (v) => (v && typeof v === "object" && !Array.isArray(v) && Object.keys(v).length ? v : undefined);
  // profil_extras ZUERST zuruecksetzen (localMedia/mainQuestion/officeFormats/...);
  // die strukturierten Felder unten ueberschreiben sie bewusst, falls doppelt.
  const extras = obj(m.profil_extras) || {};
  const profile = {
    ...extras,
    id: profilesRow.id,
    fullName: str(profilesRow.name),
    party: str(m.partei),
    faction: str(m.fraktion),
    function: str(m.rolle),
    role: str(m.rolle),
    politicalLevel: ebene,
    parliamentType,
    constituency: str(m.wahlkreis),
    state: str(m.bundesland),
    committee: committees ? committees[0] : undefined,
    committees,
    deputyCommittees: arr(m.stellvertretende_ausschuesse),
    reportingTopics: arr(m.berichterstatter_themen),
    focusTopics: arr(m.fachpolitische_schwerpunkte),
    regionalTopics: arr(m.regionale_themen),
    currentCampaigns: arr(m.aktuelle_kampagnen),
    publicPositions: arr(m.oeffentliche_positionen),
    keyAudiences: arr(m.wichtige_zielgruppen),
    communicationStyle: str(m.kommunikationsstil),
    riskTopics: arr(m.risiko_themen),
    opportunityTopics: arr(m.chancen_themen),
    noGoTopics: arr(m.no_go_themen),
    preferredChannels: arr(m.bevorzugte_kanaele),
    upcomingAppointments: arr(m.naechste_termine),
    nameVariants: arr(m.namensvarianten),
    governmentRole: str(m.regierungsrolle),
    profileActive: m.aktiv !== false,
    onboardingStatus: str(m.onboarding_status),
    // Spalte gewinnt (gueltiger Wert); ist sie null, den ggf. in profil_extras
    // erhaltenen Rohwert (ungueltige Eingabe) wiederherstellen, statt ihn zu
    // verwerfen — so bleibt der tolerante Vertrag beim Round-Trip erhalten.
    aiBudgetDailyCents: m.ki_budget_taeglich_cent != null ? Number(m.ki_budget_taeglich_cent) : extras.aiBudgetDailyCents,
    aiBudgetMonthlyCents: m.ki_budget_monatlich_cent != null ? Number(m.ki_budget_monatlich_cent) : extras.aiBudgetMonthlyCents,
    privacyConfirmedAt: str(m.datenschutz_bestaetigt_at),
    // Phase 15 (Vollstaendigkeit): uebrige funktionale Felder rekonstruieren.
    relevantMinistries: arr(m.relevante_ministerien),
    opponents: arr(m.gegner),
    monitoringTargets: arr(m.monitoring_ziele),
    regionalInterests: arr(m.regionale_interessen),
    topicPriorities: obj(m.themen_prioritaeten),
    officeHandoffMethod: str(m.buero_uebergabe),
    updatedAt: m.updated_at || profilesRow.updated_at
  };
  Object.keys(profile).forEach((key) => { if (profile[key] === undefined) delete profile[key]; });
  return profile;
}

// Liest profiles+mandate_profiles ueber eine PostgREST-Embed-Query (ein
// Roundtrip). Dualmodus: Fehler -> null fuer den bestehenden Blob-Fallback.
// Exklusivmodus: Lesestoerungen weitergeben, damit kein neutrales Ersatzprofil
// aus einer kaputten Antwort entsteht. Eine echte leere Liste bleibt null.
async function getProfileFromDb(userId, deps = {}) {
  if (!userId || !profileDbModeEnabled()) return null;
  const request = deps.request || ((endpoint) => tenantRequest(endpoint, userId));
  try {
    const rows = await request(
      `/rest/v1/profiles?id=eq.${encodeURIComponent(userId)}&select=*,mandate_profiles(*)&limit=1`
    );
    if (!Array.isArray(rows)) throw new Error("Supabase profile response is not an array");
    const row = Array.isArray(rows) && rows.length ? rows[0] : null;
    if (!row) return null;
    const mandateRow = Array.isArray(row.mandate_profiles) ? row.mandate_profiles[0] : row.mandate_profiles;
    // Profiles-Zeile OHNE mandate_profiles-Zeile ist unvollstaendig: entweder eine
    // vom helmut_ensure_profile()-Trigger angelegte Identitaets-Zeile (nur wegen
    // Kind-Tabellen) ODER eine Orphan-Zeile aus einem Teilfehler (profiles-Upsert
    // ok, mandate_profiles-Upsert gescheitert). In BEIDEN Faellen wuerde
    // fromMandateProfileRow(row, null) ein "gueltiges, aber leeres" Profil liefern
    // (nur id/fullName), das leere Personalisierung ins Scoring speist. Deshalb wie
    // "nicht vorhanden" behandeln -> null (Stufe D: Blob-Fallback greift; Stufe E: blank).
    if (!mandateRow) return null;
    if (mandateRow.geloescht_at) return null; // Soft-geloescht: wie "nicht vorhanden" behandeln.
    return fromMandateProfileRow(row, mandateRow);
  } catch (error) {
    console.error("[v3Store] getProfileFromDb fehlgeschlagen:", error.message);
    if (profileDbExclusiveEnabled()) throw error;
    return null;
  }
}

// Schreibt profiles + mandate_profiles (zwei Upserts). Fail-safe: ein Fehler hier
// darf den umschliessenden saveProfile()-Aufruf (Blob-Schreiben ist dort bereits
// abgeschlossen) NIE zum Scheitern bringen.
// --- mandate_profiles.updated_at ---------------------------------------------------------------
//
// BELEGTER BEFUND (05.09.2026): die Aktivierung der 20 Stufe-A-Profile hat `aktiv` von false
// auf true gesetzt — `updated_at` stand danach bei allen 20 Zeilen unveraendert auf dem
// `created_at` vom 04.09. Ursache: `toMandateProfileRow` setzt `updated_at` NIE (die Spalte
// steht nicht in MANDATE_PROFILE_COLUMNS), und auf `mandate_profiles` liegt kein Trigger. Der
// Spaltendefault greift nur beim INSERT. Der relationale Zeitstempel taugte damit nicht als
// Nachweis, dass eine Zeile geaendert wurde — im Blob stand die Aenderung, relational nicht.
//
// BEHEBUNG OHNE MIGRATION (ein DB-Trigger waere eine): der Zeitstempel wird in der ANWENDUNG
// gesetzt, und zwar NUR bei einer tatsaechlichen Inhaltsaenderung. Ein Schreibvorgang, der
// nichts aendert (Cron-Laeufe schreiben Profile idempotent zurueck), laesst ihn unangetastet —
// sonst waere er nur eine „zuletzt geschrieben"-Uhr und wieder kein Aenderungsnachweis.
// `created_at` wird NIE geschrieben, und bestehende Zeilen werden NICHT nachtraeglich
// veraendert: der Zeitstempel entsteht erst beim naechsten echten Schreibvorgang.

// Kanonische, vergleichbare Form EINES Spaltenwerts. Arrays behalten ihre Reihenfolge (bei
// text[]-Spalten wie `ausschuesse` ist die Reihenfolge Inhalt), Objekte werden mit sortierten
// Schluesseln serialisiert (JSONB kennt keine Schluesselreihenfolge), Zeitstempel werden auf
// ihren Zeitwert normalisiert (Postgres liefert `+00`, JavaScript `Z`), und null/undefined/""
// fallen zusammen — PostgREST liefert fehlende Werte als null zurueck.
function kanonischerSpaltenwert(wert) {
  if (wert === null || wert === undefined || wert === "") return null;
  if (Array.isArray(wert)) return wert.map((eintrag) => kanonischerSpaltenwert(eintrag));
  if (wert instanceof Date) return Number.isNaN(wert.getTime()) ? null : wert.getTime();
  if (typeof wert === "object") {
    const sortiert = {};
    for (const schluessel of Object.keys(wert).sort()) sortiert[schluessel] = kanonischerSpaltenwert(wert[schluessel]);
    return sortiert;
  }
  if (typeof wert === "string") {
    // Zeitstempelspalten (`datenschutz_bestaetigt_at`, `geloescht_at`) kommen als Text zurueck.
    // Nur ISO-artige Zeichenketten werden als Zeit gedeutet — eine gewoehnliche Zeichenkette
    // wie "Berlin" darf hier nicht versehentlich zu einer Zahl werden.
    if (/^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}/.test(wert)) {
      const ms = Date.parse(wert);
      if (!Number.isNaN(ms)) return ms;
    }
    return wert;
  }
  return wert;
}

// Vergleicht die zu schreibende Zeile mit der BESTEHENDEN. `null` als Bestand heisst: es gibt
// noch keine Zeile -> es ist eine Aenderung (der INSERT setzt `updated_at` mit).
// Verglichen werden ausschliesslich die Spalten, die tatsaechlich geschrieben werden — eine
// Spalte, die dieser Schreibvorgang gar nicht anfasst, kann keine Aenderung sein.
function mandateProfileZeileGeaendert(neu = {}, bestand = null) {
  if (!bestand || typeof bestand !== "object") return { geaendert: true, felder: ["<neue-zeile>"] };
  const felder = [];
  for (const spalte of Object.keys(neu)) {
    if (spalte === "user_id" || spalte === "updated_at" || spalte === "created_at") continue;
    const a = JSON.stringify(kanonischerSpaltenwert(neu[spalte]));
    const b = JSON.stringify(kanonischerSpaltenwert(bestand[spalte]));
    if (a !== b) felder.push(spalte);
  }
  return { geaendert: felder.length > 0, felder };
}

async function saveProfileToDb(profile = {}, deps = {}) {
  // strict (Exklusivmodus/Stufe E): ein Fehler MUSS geworfen werden, weil es dann
  // keinen Blob-Fallback beim Schreiben gibt. Ohne strict (Stufe D, additiver
  // Dual Write) bleibt das bisherige fail-safe Verhalten byte-identisch.
  const strict = deps.strict === true;
  if (!profile.id) {
    if (strict) throw new Error("saveProfileToDb: profile.id fehlt (Exklusivmodus)");
    return { skipped: true, reason: "missing-id" };
  }
  if (!profileDbModeEnabled()) {
    if (strict) throw new Error(`saveProfileToDb: DB-Modus nicht bereit (${v3SkipReason()})`);
    return { skipped: true, reason: v3SkipReason() };
  }
  const upsert = deps.upsert || ((table, row, onConflict) => v3Upsert(table, row, onConflict, profile.id));
  try {
    // profiles ZUERST (Elternzeile/FK-Ziel), dann mandate_profiles. Beide Upserts
    // sind idempotent (on_conflict auf dem PK) -> wiederholte Saves erzeugen keine
    // Duplikate, ein Retry nach Teilfehler heilt sich selbst.
    await upsert("profiles", pickColumns({
      id: profile.id,
      name: profile.fullName || profile.id,
      email: profile.email || null
    }, ["id", "name", "email"]), "id");
    const zeile = { user_id: profile.id, ...toMandateProfileRow(profile) };
    // Bestandszeile lesen, um eine ECHTE Aenderung von einem idempotenten Rueckschreiben zu
    // unterscheiden. Mandantenfilter ausdruecklich gesetzt (CLAUDE.md §4.1) — service_role
    // umgeht RLS, die Trennung ist app-seitig. Ein Lesefehler ist KEIN Schreibfehler: dann
    // wird `updated_at` gesetzt (die sichere Richtung — lieber ein Zeitstempel zu viel als
    // eine unbelegte Aenderung), und der Grund steht im Log.
    let bestand = null;
    let bestandGelesen = true;
    try {
      const lesen = deps.leseZeile || ((id) => tenantRequest(
        `/rest/v1/mandate_profiles?user_id=eq.${encodeURIComponent(id)}&select=*&limit=1`, id
      ));
      const zeilen = await lesen(profile.id);
      // MANDANTENPRUEFUNG AUCH AUF DER ANTWORT (CLAUDE.md §4.1): der Filter steht in der
      // Anfrage, aber `service_role` umgeht RLS — eine Antwort mit fremden Zeilen darf hier
      // NICHT als Bestand durchgehen. Sonst verglichen wir gegen ein fremdes Profil und
      // setzten `updated_at` nach dessen Inhalt. Passt keine Zeile, gilt: kein Bestand.
      const passend = (Array.isArray(zeilen) ? zeilen : [])
        .filter((zeile) => zeile && String(zeile.user_id) === String(profile.id));
      bestand = passend.length ? passend[0] : null;
    } catch (error) {
      bestandGelesen = false;
      console.warn(`[v3Store] mandate_profiles Bestand nicht lesbar (${String((error && error.message) || "").slice(0, 120)}) — updated_at wird gesetzt.`);
    }
    const vergleich = bestandGelesen
      ? mandateProfileZeileGeaendert(zeile, bestand)
      : { geaendert: true, felder: ["<bestand-unlesbar>"] };
    // NUR bei tatsaechlicher Aenderung. `created_at` bleibt in jedem Fall unberuehrt.
    if (vergleich.geaendert) zeile.updated_at = new Date().toISOString();
    await upsert("mandate_profiles", zeile, "user_id");
    return { saved: true, geaendert: vergleich.geaendert, geaenderteFelder: vergleich.felder };
  } catch (error) {
    console.error("[v3Store] saveProfileToDb fehlgeschlagen:", error.message);
    if (strict) throw error;
    return { skipped: true, reason: "write-failed" };
  }
}

function updateRecommendationFromInteraction(recommendations, interaction) {
  const recommendationId = interaction.recommendationId || interaction.recommendation_id;
  const signalId = interaction.signalId;
  const type = interaction.type;
  if (!recommendationId && !signalId) return recommendations;
  return recommendations.map((recommendation) => {
    const matches = recommendation.id === recommendationId || recommendation.signal_id === signalId || recommendation.signalId === signalId;
    if (!matches) return recommendation;
    const status = type === "ignored" ? "ignored"
      : type === "snoozed" ? "snoozed"
        : ["task_copied", "delegated"].includes(type) ? "in_progress"
          : type === "done" ? "done"
            : ["marked_important", "marked_relevant"].includes(type) ? "relevant"
              : recommendation.status === "ignored" ? "seen"
                : recommendation.status || "seen";
    return {
      ...recommendation,
      status,
      feedback: ["marked_important", "marked_relevant", "ignored", "snoozed", "done"].includes(type) ? type : recommendation.feedback,
      last_seen_by_user: interaction.createdAt || new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
  });
}

// --- Admin Dashboard Stats (additiv, rein lesend) ---

// Ordnet einen LLM-callType einer Produktkategorie zu.
// intelligence: Vorgänge verstehen + KI-Scoring (V2/V3).
// briefing:     personalisierte Einschätzungen und Kommunikationsentwürfe.
// office:       Büro-Engine-Outputs (Reden, PM, Social).
function categorizeLlmCallType(callType) {
  const ct = String(callType || "").toLowerCase();
  if (ct === "understanding" || ct.includes("v2score") || ct.includes("parliament")) return "intelligence";
  if (ct.includes("briefing") || ct === "helmutassessment" || ct === "communicationdraft") return "briefing";
  if (ct.includes("office")) return "office";
  return "other";
}

// KI-Kostenauswertung über `days` Tage. Liest nur den Auth-Store (llmUsage).
// ─── BEFUND 02.09. (adversariale Analyse, bestaetigt): stille Fensterkuerzung ─
// `writeAuthStore` kappt das Nutzungslog bei LLM_USAGE_RING_MAX Eintraegen. Bei
// 5 Mandaten umspannten diese Eintraege belegt 62 Tage — ein `days:30`-Bericht
// war vollstaendig. Bei 500 Profilen liegt der Tagesanfall in derselben
// Groessenordnung 100x hoeher: der Ring ist in unter zwei Tagen gefuellt, und
// derselbe Bericht deckt dann weniger als einen Tag ab, OHNE dass irgendwo ein
// Hinweis darauf erscheint. Genau das ist ein falsches Gruen (CLAUDE.md §4.4),
// und die Kosten-Abbruchregel des Funktionstests rechnet gegen dasselbe
// verkuerzte Fenster.
//
// Diese Funktion beantwortet rein lesend: deckt das Log das angefragte Fenster
// ueberhaupt ab? Sie AENDERT nichts und kuerzt nichts — sie macht die Kuerzung
// nur sichtbar. `true` heisst: der Ring ist nicht voll ODER sein aeltester
// Eintrag ist aelter als der Fensterbeginn, das Fenster ist also vollstaendig.
function blobFensterVollstaendig(alle, vonMs) {
  const liste = Array.isArray(alle) ? alle : [];
  if (liste.length < LLM_USAGE_RING_MAX) {
    return { vollstaendig: true, grund: "ring-nicht-voll", eintraege: liste.length, aeltesterIso: null };
  }
  let aeltester = null;
  for (const e of liste) {
    const ms = new Date((e && e.createdAt) || 0).getTime();
    if (!Number.isFinite(ms) || ms <= 0) continue;
    if (aeltester === null || ms < aeltester) aeltester = ms;
  }
  if (aeltester === null) {
    // Voller Ring ohne einen einzigen brauchbaren Zeitstempel: nicht bewertbar,
    // also fail closed als unvollstaendig melden.
    return { vollstaendig: false, grund: "ring-voll-ohne-zeitstempel", eintraege: liste.length, aeltesterIso: null };
  }
  const von = Number(vonMs);
  const vollstaendig = Number.isFinite(von) ? aeltester <= von : false;
  return {
    vollstaendig,
    grund: vollstaendig ? "ring-voll-aber-fenster-abgedeckt" : "ring-voll-fenster-gekuerzt",
    eintraege: liste.length,
    aeltesterIso: new Date(aeltester).toISOString()
  };
}

async function getAdminStatsCosts({ days = 30, referenceIso = null } = {}) {
  const store = await readAuthStore();
  const allUsage = Array.isArray(store.llmUsage) ? store.llmUsage : [];
  const refMs = referenceIso ? new Date(referenceIso).getTime() : Date.now();
  const cutoffMs = refMs - days * 24 * 60 * 60 * 1000;
  const relevant = allUsage.filter((e) => {
    const ms = new Date(e.createdAt || 0).getTime();
    return ms >= cutoffMs && !String(e.callType || "").startsWith("skipped");
  });

  const totalCalls = relevant.length;
  const successfulCalls = relevant.filter((e) => e.success !== false).length;
  const totalCostUsd = Math.round(relevant.reduce((s, e) => s + (typeof e.estimatedCost === "number" ? e.estimatedCost : 0), 0) * 1e6) / 1e6;
  const totalTokens = relevant.reduce((s, e) => s + (typeof e.totalTokens === "number" ? e.totalTokens : 0), 0);

  const perModel = {};
  const perCategory = {};
  const byDay = {};

  for (const e of relevant) {
    const model = e.model || "unknown";
    if (!perModel[model]) perModel[model] = { calls: 0, successfulCalls: 0, estimatedCostUsd: 0, promptTokens: 0, completionTokens: 0, totalTokens: 0 };
    perModel[model].calls++;
    if (e.success !== false) perModel[model].successfulCalls++;
    if (typeof e.estimatedCost === "number") perModel[model].estimatedCostUsd += e.estimatedCost;
    if (typeof e.promptTokens === "number") perModel[model].promptTokens += e.promptTokens;
    if (typeof e.completionTokens === "number") perModel[model].completionTokens += e.completionTokens;
    if (typeof e.totalTokens === "number") perModel[model].totalTokens += e.totalTokens;

    const cat = categorizeLlmCallType(e.callType);
    if (!perCategory[cat]) perCategory[cat] = { calls: 0, successfulCalls: 0, estimatedCostUsd: 0 };
    perCategory[cat].calls++;
    if (e.success !== false) perCategory[cat].successfulCalls++;
    if (typeof e.estimatedCost === "number") perCategory[cat].estimatedCostUsd += e.estimatedCost;

    const d = dayKey(e.createdAt);
    if (!byDay[d]) byDay[d] = { day: d, calls: 0, successfulCalls: 0, estimatedCostUsd: 0, totalTokens: 0 };
    byDay[d].calls++;
    if (e.success !== false) byDay[d].successfulCalls++;
    if (typeof e.estimatedCost === "number") byDay[d].estimatedCostUsd += e.estimatedCost;
    if (typeof e.totalTokens === "number") byDay[d].totalTokens += e.totalTokens;
  }

  for (const v of Object.values(perModel)) v.estimatedCostUsd = Math.round(v.estimatedCostUsd * 1e6) / 1e6;
  for (const v of Object.values(perCategory)) v.estimatedCostUsd = Math.round(v.estimatedCostUsd * 1e6) / 1e6;
  const byDayArr = Object.values(byDay)
    .map((d) => ({ ...d, estimatedCostUsd: Math.round(d.estimatedCostUsd * 1e6) / 1e6 }))
    .sort((a, b) => b.day.localeCompare(a.day));

  return {
    periodDays: days,
    totalCalls,
    successfulCalls,
    failedCalls: totalCalls - successfulCalls,
    totalCostUsd,
    totalTokens,
    perModel,
    perCategory,
    byDay: byDayArr,
    priceTableUsd: llmPriceTable(),
    // Rein additiv: sagt, ob das angefragte Fenster vom Ringpuffer ueberhaupt
    // abgedeckt ist. `vollstaendig: false` heisst, die Summen oben decken
    // WENIGER als `periodDays` Tage ab.
    fenster: blobFensterVollstaendig(allUsage, cutoffMs)
  };
}

// Crawl-Statistik über `days` Tage. Liest Main-Store (crawlRuns, rawItems).
async function getAdminStatsCrawl({ days = 30, referenceIso = null } = {}) {
  const store = await readStore("main");
  const refMs = referenceIso ? new Date(referenceIso).getTime() : Date.now();
  const cutoffMs = refMs - days * 24 * 60 * 60 * 1000;

  const allRuns = store.crawlRuns || [];
  const allRawItems = store.rawItems || [];
  const recentRuns = allRuns.filter((r) => new Date(r.createdAt || 0).getTime() >= cutoffMs);
  const recentRawItems = allRawItems.filter((item) => new Date(item.retrievedAt || item.publishedAt || 0).getTime() >= cutoffMs);

  const crawlByDay = {};
  for (const run of recentRuns) {
    const d = dayKey(run.createdAt);
    if (!crawlByDay[d]) crawlByDay[d] = { day: d, runs: 0, checkedSources: 0, successfulSources: 0, failedSources: 0, newCandidateItems: 0, savedItems: 0 };
    const b = crawlByDay[d];
    b.runs++;
    b.checkedSources += run.checkedSources || 0;
    b.successfulSources += run.successfulSources || 0;
    b.failedSources += run.failedSources || 0;
    b.newCandidateItems += run.newCandidateItems || 0;
    b.savedItems += run.savedItems || 0;
  }

  const rawByDay = {};
  for (const item of recentRawItems) {
    const d = dayKey(item.retrievedAt || item.publishedAt || "");
    if (!d) continue;
    if (!rawByDay[d]) rawByDay[d] = { day: d, articles: 0 };
    rawByDay[d].articles++;
  }

  return {
    periodDays: days,
    totalCrawlRuns: recentRuns.length,
    totalCheckedSources: recentRuns.reduce((s, r) => s + (r.checkedSources || 0), 0),
    totalSuccessfulSources: recentRuns.reduce((s, r) => s + (r.successfulSources || 0), 0),
    totalFailedSources: recentRuns.reduce((s, r) => s + (r.failedSources || 0), 0),
    totalSavedArticles: recentRuns.reduce((s, r) => s + (r.savedItems || 0), 0),
    totalNewCandidateItems: recentRuns.reduce((s, r) => s + (r.newCandidateItems || 0), 0),
    recentRawItemCount: recentRawItems.length,
    totalRawItemCount: allRawItems.length,
    latestCrawlRun: allRuns[0] || null,
    crawlByDay: Object.values(crawlByDay).sort((a, b) => b.day.localeCompare(a.day)),
    rawByDay: Object.values(rawByDay).sort((a, b) => b.day.localeCompare(a.day))
  };
}

// Kombinierte Übersicht für tägliche/wöchentliche Stats. Inklusive V3-Daten (falls aktiv).
async function getAdminStatsOverview({ days = 1, referenceIso = null } = {}) {
  const [crawl, costs] = await Promise.all([
    getAdminStatsCrawl({ days, referenceIso }),
    getAdminStatsCosts({ days, referenceIso })
  ]);

  let v3 = null;
  if (v3StoreReady()) {
    try {
      const refMs = referenceIso ? new Date(referenceIso).getTime() : Date.now();
      const cutoffIso = new Date(refMs - days * 24 * 60 * 60 * 1000).toISOString();
      const [rawDocs, kos] = await Promise.all([
        supabaseRequest(`/rest/v1/raw_documents?select=id,created_at&created_at=gte.${cutoffIso}&limit=1000`).catch(() => []),
        supabaseRequest(`/rest/v1/knowledge_objects?select=id,status,understanding_status,created_at&created_at=gte.${cutoffIso}&limit=500`).catch(() => [])
      ]);
      const rawDocsArr = Array.isArray(rawDocs) ? rawDocs : [];
      const kosArr = Array.isArray(kos) ? kos : [];
      v3 = {
        newRawDocuments: rawDocsArr.length,
        newKnowledgeObjects: kosArr.length,
        kosByStatus: kosArr.reduce((acc, ko) => { acc[ko.status || "unknown"] = (acc[ko.status || "unknown"] || 0) + 1; return acc; }, {}),
        kosByUnderstandingStatus: kosArr.reduce((acc, ko) => { acc[ko.understanding_status || "unknown"] = (acc[ko.understanding_status || "unknown"] || 0) + 1; return acc; }, {})
      };
    } catch (error) {
      v3 = { error: error.message };
    }
  }

  return {
    period: days === 1 ? "daily" : days <= 7 ? "weekly" : "monthly",
    periodDays: days,
    generatedAt: new Date().toISOString(),
    crawl: {
      runs: crawl.totalCrawlRuns,
      checkedSources: crawl.totalCheckedSources,
      successfulSources: crawl.totalSuccessfulSources,
      failedSources: crawl.totalFailedSources,
      savedArticles: crawl.totalSavedArticles,
      newCandidateItems: crawl.totalNewCandidateItems,
      recentRawItems: crawl.recentRawItemCount,
      totalRawItemsInStore: crawl.totalRawItemCount,
      latestCrawlAt: crawl.latestCrawlRun?.createdAt || null
    },
    ai: {
      totalCalls: costs.totalCalls,
      successfulCalls: costs.successfulCalls,
      failedCalls: costs.failedCalls,
      totalCostUsd: costs.totalCostUsd,
      totalTokens: costs.totalTokens,
      perCategory: costs.perCategory,
      perModel: costs.perModel
    },
    v3: v3 || { note: "V3-Store nicht aktiv (HELMUT_V3_STORE nicht gesetzt)" }
  };
}

// Detaillierter Bericht für den letzten Crawl-Lauf.
// Kombiniert Store-Daten (Crawl-Metriken, Fehler) mit V3-Supabase-Abfragen
// (neue raw_documents, knowledge_objects). Kein KI-Call.
async function getAdminStatsCrawlReport() {
  const store = await readStore("main");
  const allRuns = store.crawlRuns || [];
  const latestRun = allRuns[0] || null;

  if (!latestRun) {
    return {
      generatedAt: new Date().toISOString(),
      lastCrawlAt: null,
      noData: true
    };
  }

  const scannedArticles = latestRun.newCandidateItems || 0;
  const deduplicatedArticles = latestRun.savedItems || 0;
  const errorCount = Array.isArray(latestRun.errors) ? latestRun.errors.length : 0;
  const errors = Array.isArray(latestRun.errors) ? latestRun.errors : [];

  let newRawDocuments = null;
  let newKnowledgeObjects = null;
  let newVorgaenge = null;
  let v3Note = null;

  if (v3StoreReady()) {
    try {
      const cutoffIso = latestRun.createdAt;
      const [rawDocs, kos] = await Promise.all([
        supabaseRequest(`/rest/v1/raw_documents?select=id,created_at&created_at=gte.${encodeURIComponent(cutoffIso)}&limit=2000`).catch(() => []),
        supabaseRequest(`/rest/v1/knowledge_objects?select=id,vorgang_id,created_at&created_at=gte.${encodeURIComponent(cutoffIso)}&limit=1000`).catch(() => [])
      ]);
      const rawDocsArr = Array.isArray(rawDocs) ? rawDocs : [];
      const kosArr = Array.isArray(kos) ? kos : [];
      newRawDocuments = rawDocsArr.length;
      newKnowledgeObjects = kosArr.length;
      const vorgangIds = new Set(kosArr.map((ko) => ko.vorgang_id).filter(Boolean));
      newVorgaenge = vorgangIds.size;
    } catch (error) {
      v3Note = error.message;
    }
  } else {
    v3Note = v3SkipReason();
  }

  return {
    generatedAt: new Date().toISOString(),
    lastCrawlAt: latestRun.createdAt,
    mode: latestRun.mode || "full",
    scannedArticles,
    deduplicatedArticles,
    checkedSources: latestRun.checkedSources || 0,
    successfulSources: latestRun.successfulSources || 0,
    failedSources: latestRun.failedSources || 0,
    newVorgaenge,
    newKnowledgeObjects,
    newRawDocuments,
    durationSec: null,
    errorCount,
    errors,
    ...(v3Note ? { v3Note } : {})
  };
}

// KI-Kosten aggregiert pro Nutzer (userId oder politicianId) über `days` Tage.
async function getAdminCostsPerUser({ days = 30 } = {}) {
  const store = await readAuthStore();
  const allUsage = Array.isArray(store.llmUsage) ? store.llmUsage : [];
  const cutoffMs = Date.now() - days * 24 * 60 * 60 * 1000;
  const relevant = allUsage.filter((e) => {
    const ms = new Date(e.createdAt || 0).getTime();
    return ms >= cutoffMs && !String(e.callType || "").startsWith("skipped");
  });

  const byUser = {};
  let totalCostUsd = 0;
  for (const e of relevant) {
    const uid = e.userId || e.politicianId || "unbekannt";
    if (!byUser[uid]) byUser[uid] = { userId: uid, totalCostUsd: 0, calls: 0 };
    const c = typeof e.estimatedCost === "number" ? e.estimatedCost : 0;
    byUser[uid].totalCostUsd += c;
    byUser[uid].calls++;
    totalCostUsd += c;
  }

  return {
    periodDays: days,
    totalCostUsd: Math.round(totalCostUsd * 1e6) / 1e6,
    perUser: Object.values(byUser)
      .map((u) => ({ ...u, totalCostUsd: Math.round(u.totalCostUsd * 1e6) / 1e6 }))
      .sort((a, b) => b.totalCostUsd - a.totalCostUsd),
    fenster: blobFensterVollstaendig(allUsage, cutoffMs)
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// ARBEITSWARTESCHLANGE (OP-30, Migration 20260808_scalable_job_queue.sql)
// ═══════════════════════════════════════════════════════════════════════════
// Duenne RPC-Huellen. Die gesamte Fachlogik (Schluesselbildung, Backoff,
// Fehlerbereinigung, Handlerauswahl) liegt in lib/helmut/jobqueue.js — hier
// steht ausschliesslich der Datenzugriff, wie bei jedem anderen Pfad auch.
//
// FAIL CLOSED: fehlt die Migration, ist die Warteschlange NICHT "leer",
// sondern NICHT VERFUEGBAR. Ein leerer Rueckgabewert waere die Falschaussage
// "nichts zu tun" (CLAUDE.md §4.4) — deshalb wird der Zustand ausdruecklich
// als `verfuegbar: false` gemeldet und der Aufrufer bricht ab.
function jobQueueBereit() {
  return Boolean(process.env.SUPABASE_URL) && Boolean(supabaseServiceRoleKey());
}

async function jobQueueRpc(name, params) {
  const rows = await supabaseRequest(`/rest/v1/rpc/${name}`, {
    method: "POST",
    body: JSON.stringify(params || {})
  });
  return Array.isArray(rows) ? rows : (rows == null ? [] : [rows]);
}

async function jobQueueEnqueue(auftrag) {
  if (!jobQueueBereit()) return { verfuegbar: false, grund: "supabase-nicht-konfiguriert" };
  try {
    const rows = await jobQueueRpc("helmut_enqueue_job", {
      p_job_type: auftrag.jobType,
      p_idempotency_key: auftrag.idempotencyKey,
      p_freshness_window: auftrag.freshnessWindow,
      p_payload: auftrag.payload || {},
      p_due_at: auftrag.dueAt || new Date().toISOString(),
      p_priority: Number.isFinite(auftrag.priority) ? auftrag.priority : 100,
      p_max_attempts: Number.isFinite(auftrag.maxAttempts) ? auftrag.maxAttempts : 5,
      p_tenant_id: auftrag.tenantId == null ? null : String(auftrag.tenantId)
    });
    const row = rows[0] || {};
    return { verfuegbar: true, id: row.id || null, neu: row.neu === true };
  } catch (error) {
    if (isMissingReservationRpcError(error)) {
      return { verfuegbar: false, grund: "migration-fehlt" };
    }
    return { verfuegbar: false, grund: String((error && error.message) || "unbekannt").slice(0, 200) };
  }
}

async function jobQueueClaim({ owner, limit = 10, leaseMs = 120000, types = null } = {}) {
  if (!jobQueueBereit()) return { verfuegbar: false, grund: "supabase-nicht-konfiguriert", auftraege: [] };
  try {
    const rows = await jobQueueRpc("helmut_claim_jobs", {
      p_owner: owner, p_limit: limit, p_lease_ms: leaseMs, p_types: types
    });
    return { verfuegbar: true, auftraege: rows };
  } catch (error) {
    if (isMissingReservationRpcError(error)) {
      return { verfuegbar: false, grund: "migration-fehlt", auftraege: [] };
    }
    return { verfuegbar: false, grund: String((error && error.message) || "unbekannt").slice(0, 200), auftraege: [] };
  }
}

async function jobQueueFinish({ id, owner, ok, error = null, retryDelayMs = 0 } = {}) {
  if (!jobQueueBereit()) return { verfuegbar: false, grund: "supabase-nicht-konfiguriert" };
  try {
    const rows = await jobQueueRpc("helmut_finish_job", {
      p_id: id, p_owner: owner, p_ok: Boolean(ok),
      p_error: error == null ? null : String(error),
      p_retry_delay_ms: Math.max(0, Number(retryDelayMs) || 0)
    });
    const row = rows[0] || {};
    return { verfuegbar: true, uebernommen: row.uebernommen === true, neuerStatus: row.neuer_status || null };
  } catch (err) {
    return { verfuegbar: false, grund: String((err && err.message) || "unbekannt").slice(0, 200) };
  }
}

async function jobQueueExtendLease({ id, owner, leaseMs = 120000 } = {}) {
  if (!jobQueueBereit()) return { verfuegbar: false, grund: "supabase-nicht-konfiguriert" };
  try {
    const rows = await jobQueueRpc("helmut_extend_job_lease", {
      p_id: id, p_owner: owner, p_lease_ms: leaseMs
    });
    const wert = rows[0];
    return { verfuegbar: true, verlaengert: wert === true || (wert && wert.helmut_extend_job_lease === true) };
  } catch (error) {
    return { verfuegbar: false, grund: String((error && error.message) || "unbekannt").slice(0, 200) };
  }
}

async function jobQueueMetrics(seitMinuten = 1440) {
  if (!jobQueueBereit()) return { verfuegbar: false, grund: "supabase-nicht-konfiguriert" };
  try {
    const rows = await jobQueueRpc("helmut_job_metrics", { p_seit_minuten: seitMinuten });
    return { verfuegbar: true, kennzahlen: rows[0] || null };
  } catch (error) {
    if (isMissingReservationRpcError(error)) return { verfuegbar: false, grund: "migration-fehlt" };
    return { verfuegbar: false, grund: String((error && error.message) || "unbekannt").slice(0, 200) };
  }
}

// --- V3-ANBINDUNG DES WARTESCHLANGENPFADS (OP-30, additiv) --------------------------------
// Rohdokumente nach Kennung lesen. Der Warteschlangenpfad transportiert im Auftrag NUR die
// Kennungen (`rd-<inhaltsfingerabdruck>`), nie den Inhalt — Datensparsamkeit und
// Nutzdatensparsamkeit in einem. Der Understanding-Handler holt die minimierten Zeilen hier.
// Genau derselbe Spaltensatz wie `listRawDocuments`, damit `toRawDocumentRow` dieselbe
// Kennung wieder erzeugt und das V3-Clustering unveraendert arbeitet.
const RAW_DOC_ID_CHUNK = 100;

async function getRawDocumentsByIds(ids = []) {
  if (!v3StoreReady()) return [];
  const liste = [...new Set((Array.isArray(ids) ? ids : []).map((i) => String(i || "").trim()).filter(Boolean))];
  if (!liste.length) return [];
  const cols = "id,content_hash,canonical_url,title,summary,url,source_name,source_id,source_type,"
    + "confidence,link_type,published_at,retrieved_at,created_at,document_type,wahlperiode";
  const out = [];
  for (let i = 0; i < liste.length; i += RAW_DOC_ID_CHUNK) {
    const teil = liste.slice(i, i + RAW_DOC_ID_CHUNK);
    try {
      const rows = await supabaseRequest(
        `/rest/v1/raw_documents?id=in.(${teil.map(inFilterWert).join(",")})&select=${cols}`);
      if (Array.isArray(rows)) out.push(...rows);
    } catch (error) {
      // W-1-Regel: ein Lesefehler darf NIE wie "keine Dokumente" aussehen.
      throw new StorageReadError("raw_documents", error);
    }
  }
  return out;
}

// Offene Vorbedingungen zaehlen: wie viele Auftraege der genannten Typen sind im selben
// Aktualitaetsfenster noch nicht abgeschlossen? Grundlage der Reihenfolgezusage
// "Projektion und Briefing erst nach ihren Voraussetzungen" (Migration
// 20260808_jobqueue_abhaengigkeiten.sql).
async function jobQueueOffeneVorbedingungen({ fenster = null, typen = null, mandat = null } = {}) {
  if (!jobQueueBereit()) return { verfuegbar: false, grund: "supabase-nicht-konfiguriert", offen: null };
  // `p_fenster` ist seit Befund O3 eine LISTE (siehe 20260808_jobqueue_abhaengigkeiten.sql).
  // Ein einzelner String wird hier eingepackt, damit Altaufrufer nicht auf eine leere
  // Menge laufen — eine falsche Null waere hier ein falsches Gruen.
  const fensterListe = fenster == null
    ? null
    : (Array.isArray(fenster) ? fenster.filter(Boolean).map(String) : [String(fenster)]);
  // MANDATSFILTER (Befund Z22, Migration 20260826190000). Nur eine nicht leere Zeichenkette
  // zaehlt als Mandatskennung. Alles andere — null, leer, Zahl, Objekt — fuehrt zur globalen
  // Zaehlung, also zu MEHR Warten. Fail closed: eine unbrauchbare Kennung darf niemals
  // stillschweigend zu weniger Vorbedingungen fuehren.
  const mandatsKennung = typeof mandat === "string" && mandat.trim() !== "" ? mandat.trim() : null;
  const argumente = {
    p_fenster: fensterListe && fensterListe.length ? fensterListe : null,
    p_typen: Array.isArray(typen) && typen.length ? typen : null
  };

  const frage = async (mitMandat) => {
    const rows = await jobQueueRpc("helmut_jobs_offen",
      mitMandat ? { ...argumente, p_mandat: mandatsKennung } : argumente);
    const zeile = rows[0] || {};
    return {
      verfuegbar: true,
      offen: Number(zeile.offen) || 0,
      wartend: Number(zeile.wartend) || 0,
      laufend: Number(zeile.laufend) || 0,
      mandatsfilter: Boolean(mitMandat)
    };
  };

  try {
    if (!mandatsKennung) return await frage(false);
    try {
      return await frage(true);
    } catch (error) {
      // MIGRATION NOCH NICHT ANGEWENDET. PostgREST beantwortet einen Aufruf mit unbekanntem
      // Argumentnamen mit `PGRST202`. Dann wird GENAU EINMAL ohne `p_mandat` nachgefragt —
      // das ist exakt das bisherige, konservativere Verhalten (global). Ohne diesen Rueckfall
      // haette ein Deployment ohne angewendete Migration die Reihenfolgezusage still
      // ABGESCHALTET (`migration-fehlt` -> `verfuegbar:false` -> gar keine Pruefung mehr).
      // Genau diese Reihenfolge — Code zuerst, Migration spaeter — ist bei Helmut der
      // Normalfall (Merge = Deployment, Migrationen sind freigabepflichtig).
      if (!isMissingReservationRpcError(error)) throw error;
      const global = await frage(false);
      return { ...global, mandatsfilter: false, grund: "mandatsfilter-migration-fehlt" };
    }
  } catch (error) {
    if (isMissingReservationRpcError(error)) return { verfuegbar: false, grund: "migration-fehlt", offen: null };
    return { verfuegbar: false, grund: String((error && error.message) || "unbekannt").slice(0, 200), offen: null };
  }
}

// Einen laufenden Auftrag EHRLICH zurueckstellen (Vorbedingung offen, Budget erschoepft).
// Kein Fehlversuch: `helmut_defer_job` nimmt den Versuch zurueck. Der Unterschied zu
// `jobQueueFinish(ok:false)` ist der Unterschied zwischen "wartet" und "gescheitert".
async function jobQueueDefer({ id, owner, delayMs = 60000, grund = null } = {}) {
  if (!jobQueueBereit()) return { verfuegbar: false, grund: "supabase-nicht-konfiguriert" };
  try {
    const rows = await jobQueueRpc("helmut_defer_job", {
      p_id: id, p_owner: owner,
      p_delay_ms: Math.max(1000, Number(delayMs) || 60000),
      p_grund: grund == null ? null : String(grund).slice(0, 200)
    });
    const z = rows[0] || {};
    return { verfuegbar: true, uebernommen: Boolean(z.uebernommen), neueFaelligkeit: z.neue_faelligkeit || null };
  } catch (error) {
    if (isMissingReservationRpcError(error)) return { verfuegbar: false, grund: "migration-fehlt" };
    return { verfuegbar: false, grund: String((error && error.message) || "unbekannt").slice(0, 200) };
  }
}

// --- WIEDERVORLAGE endgueltig gescheiterter Auftraege (OP-30/O5, Migration 20260809) ------
// Der Idempotenzschluessel des Verstehens traegt bewusst kein Fenster. Ein endgueltig
// gescheiterter Verstehensauftrag wuerde dieselbe Dokumentmenge sonst DAUERHAFT blockieren.
// Diese Huelle ruft die begrenzte Wiedervorlage auf — der Fehlerbeleg bleibt erhalten.
async function jobQueueWiedervorlage({
  typen = ["document_understanding"], aelterAlsStunden = 24,
  maxWiedervorlagen = 2, maxZeilen = 500, trockenlauf = true
} = {}) {
  if (!jobQueueBereit()) return { verfuegbar: false, grund: "supabase-nicht-konfiguriert" };
  try {
    const rows = await jobQueueRpc("helmut_jobs_wiedervorlage", {
      p_typen: Array.isArray(typen) && typen.length ? typen : null,
      p_aelter_als_stunden: Math.max(1, Number(aelterAlsStunden) || 24),
      p_max_wiedervorlagen: Math.max(0, Number(maxWiedervorlagen) || 0),
      p_max_zeilen: Math.max(1, Number(maxZeilen) || 500),
      p_trockenlauf: trockenlauf !== false
    });
    const z = rows[0] || {};
    return {
      verfuegbar: true,
      gefunden: Number(z.gefunden) || 0,
      wiedervorgelegt: Number(z.wiedervorgelegt) || 0,
      trockenlauf: z.trockenlauf !== false
    };
  } catch (error) {
    if (isMissingReservationRpcError(error)) return { verfuegbar: false, grund: "migration-fehlt" };
    return { verfuegbar: false, grund: String((error && error.message) || "unbekannt").slice(0, 200) };
  }
}

// Dauerhaft blockierte Auftraege: die Menge, die von selbst NICHT zurueckkommt. Sie gehoert
// in die Betriebsanzeige, sonst waere „keine offenen Auftraege" ein falsches Gruen.
async function jobQueueBlockiert({ maxWiedervorlagen = 2 } = {}) {
  if (!jobQueueBereit()) return { verfuegbar: false, grund: "supabase-nicht-konfiguriert" };
  try {
    const rows = await jobQueueRpc("helmut_jobs_blockiert", {
      p_max_wiedervorlagen: Math.max(0, Number(maxWiedervorlagen) || 0)
    });
    const z = rows[0] || {};
    return {
      verfuegbar: true,
      blockiert: Number(z.blockiert) || 0,
      nachTyp: z.nach_typ || {},
      aeltester: z.aeltester || null
    };
  } catch (error) {
    if (isMissingReservationRpcError(error)) return { verfuegbar: false, grund: "migration-fehlt" };
    return { verfuegbar: false, grund: String((error && error.message) || "unbekannt").slice(0, 200) };
  }
}

// Zurueckstellgruende der WARTENDEN Auftraege (Warteschlangenwache V2, 2026-08-17). Nur die
// technische Spalte `last_error` (beim Schreiben bereits durch `bereinigeFehler` gekuerzt),
// keine Nutzdaten. Die Wache unterscheidet damit „Abhaengigkeit blockiert / Anbietergrenze"
// von „Verbraucher festgefahren" — zwei Befunde mit entgegengesetzter Betreiberaktion.
// FAIL CLOSED: ein Lesefehler ist „nicht verfuegbar", nie eine leere Grundmenge.
async function jobQueueZurueckgestellteGruende({ limit = 1000 } = {}) {
  if (!jobQueueBereit()) return { verfuegbar: false, grund: "supabase-nicht-konfiguriert" };
  try {
    const wirksamesLimit = Math.max(1, Math.min(5000, Number(limit) || 1000));
    const rows = await supabaseRequest(
      `/rest/v1/helmut_jobs?status=eq.wartend&last_error=not.is.null&select=last_error`
      + `&limit=${wirksamesLimit}`);
    const zeilen = Array.isArray(rows) ? rows : [];
    const texte = zeilen
      .map((r) => String((r && r.last_error) || "")).filter(Boolean);
    // Ohne Count-Header kann `rows.length === limit` NICHT unterscheiden, ob exakt so
    // viele oder noch weitere Zeilen existieren. Deshalb konservativ `vollstaendig:false`:
    // eine gedeckelte, ungeordnete Teilmenge darf nie als Verteilung des Gesamtbestands
    // auftreten. Bei weniger Zeilen ist der Filter dagegen nachweislich ausgeschoepft.
    return {
      verfuegbar: true,
      anzahl: texte.length,
      gelesen: zeilen.length,
      limit: wirksamesLimit,
      vollstaendig: zeilen.length < wirksamesLimit,
      texte
    };
  } catch (error) {
    return { verfuegbar: false, grund: String((error && error.message) || "unbekannt").slice(0, 200) };
  }
}

// --- TRANSAKTIONALE OUTBOX (OP-30-Zielarchitektur, Migration 20260813, additiv) ------------
// Duenne RPC-Huellen wie oben; die Fachlogik (Transportwahl, Payload-Riegel, Dispatcher)
// liegt in lib/helmut/job-dispatch.js. FAIL CLOSED: fehlt die Migration, ist die Outbox
// NICHT "leer", sondern NICHT VERFUEGBAR — der Aufrufer faellt auf den Cron-Rueckfallweg.

async function jobQueueEnqueueMitOutbox(auftrag) {
  if (!jobQueueBereit()) return { verfuegbar: false, grund: "supabase-nicht-konfiguriert" };
  try {
    const rows = await jobQueueRpc("helmut_enqueue_job_mit_outbox", {
      p_job_type: auftrag.jobType,
      p_idempotency_key: auftrag.idempotencyKey,
      p_freshness_window: auftrag.freshnessWindow,
      p_payload: auftrag.payload || {},
      p_due_at: auftrag.dueAt || new Date().toISOString(),
      p_priority: Number.isFinite(auftrag.priority) ? auftrag.priority : 100,
      p_max_attempts: Number.isFinite(auftrag.maxAttempts) ? auftrag.maxAttempts : 5,
      p_tenant_id: auftrag.tenantId == null ? null : String(auftrag.tenantId),
      p_schema_version: Number.isFinite(auftrag.schemaVersion) ? auftrag.schemaVersion : 1
    });
    const row = rows[0] || {};
    return {
      verfuegbar: true,
      id: row.id || null,
      neu: row.neu === true,
      versandabsicht: row.versandabsicht || null
    };
  } catch (error) {
    if (isMissingReservationRpcError(error)) {
      return { verfuegbar: false, grund: "migration-fehlt" };
    }
    return { verfuegbar: false, grund: String((error && error.message) || "unbekannt").slice(0, 200) };
  }
}

async function jobOutboxNaechste({ limit = 50, transport = null } = {}) {
  if (!jobQueueBereit()) return { verfuegbar: false, grund: "supabase-nicht-konfiguriert", absichten: [] };
  try {
    const rows = await jobQueueRpc("helmut_outbox_naechste", {
      p_limit: Math.max(0, Number(limit) || 0),
      p_transport: transport == null ? null : String(transport).slice(0, 40)
    });
    return {
      verfuegbar: true,
      absichten: rows.map((z) => ({
        outboxId: z.outbox_id,
        jobId: z.job_id,
        schemaVersion: Number(z.schema_version) || 1,
        attempts: Number(z.attempts) || 0
      }))
    };
  } catch (error) {
    if (isMissingReservationRpcError(error)) return { verfuegbar: false, grund: "migration-fehlt", absichten: [] };
    return { verfuegbar: false, grund: String((error && error.message) || "unbekannt").slice(0, 200), absichten: [] };
  }
}

async function jobQueueClaimById({ jobId, owner, leaseMs = 300000 } = {}) {
  if (!jobQueueBereit()) return { verfuegbar: false, grund: "supabase-nicht-konfiguriert" };
  try {
    const rows = await jobQueueRpc("helmut_claim_job_by_id", {
      p_job_id: jobId,
      p_owner: owner,
      p_lease_ms: Math.max(1000, Number(leaseMs) || 300000)
    });
    const z = rows[0] || {};
    return {
      verfuegbar: true,
      uebernommen: z.uebernommen === true,
      grund: z.grund || null,
      id: z.id || null,
      jobType: z.job_type || null,
      tenantId: z.tenant_id || null,
      payload: z.payload || null,
      attempts: Number(z.attempts) || 0,
      maxAttempts: Number(z.max_attempts) || 5,
      leaseExpiresAt: z.lease_expires_at || null
    };
  } catch (error) {
    if (isMissingReservationRpcError(error)) return { verfuegbar: false, grund: "migration-fehlt" };
    return { verfuegbar: false, grund: String((error && error.message) || "unbekannt").slice(0, 200) };
  }
}

async function jobOutboxZuruecklegen({ outboxId, warteSekunden = 60 } = {}) {
  if (!jobQueueBereit()) return { verfuegbar: false, grund: "supabase-nicht-konfiguriert" };
  try {
    const rows = await jobQueueRpc("helmut_outbox_zuruecklegen", {
      p_outbox_id: outboxId,
      p_warte_sekunden: Math.max(0, Number(warteSekunden) || 60)
    });
    const z = rows[0] || {};
    return { verfuegbar: true, uebernommen: z.uebernommen === true, grund: z.grund || null };
  } catch (error) {
    if (isMissingReservationRpcError(error)) return { verfuegbar: false, grund: "migration-fehlt" };
    return { verfuegbar: false, grund: String((error && error.message) || "unbekannt").slice(0, 200) };
  }
}

// Legt die Versandabsicht eines wieder WARTENDEN Auftrags erneut vor — fällig genau zu
// seiner neuen Fälligkeit. Trägt Wiederholungen und Zurückstellungen im Ereignis-Antrieb,
// ohne auf das Mindestalter des Abgleichs zu warten (Korrekturlauf 2026-08-14/3).
async function jobOutboxErneutVorlegen({ jobId } = {}) {
  if (!jobQueueBereit()) return { verfuegbar: false, grund: "supabase-nicht-konfiguriert" };
  try {
    const rows = await jobQueueRpc("helmut_outbox_erneut_vorlegen", { p_job_id: jobId });
    const z = rows[0] || {};
    return {
      verfuegbar: true,
      uebernommen: z.uebernommen === true,
      grund: z.grund || null,
      faelligAb: z.faellig_ab || null,
      sofort: z.sofort === true
    };
  } catch (error) {
    if (isMissingReservationRpcError(error)) return { verfuegbar: false, grund: "migration-fehlt" };
    return { verfuegbar: false, grund: String((error && error.message) || "unbekannt").slice(0, 200) };
  }
}

async function klasseErneuere({ slot, owner, ttlMs = 60000 } = {}) {
  if (!jobQueueBereit()) return { verfuegbar: false, grund: "supabase-nicht-konfiguriert" };
  try {
    const rows = await jobQueueRpc("helmut_klasse_erneuere", {
      p_slot: slot, p_owner: owner, p_ttl_ms: Math.max(1000, Number(ttlMs) || 60000)
    });
    const z = rows[0] || {};
    return { verfuegbar: true, erneuert: z.erneuert === true, grund: z.grund || null };
  } catch (error) {
    if (isMissingReservationRpcError(error)) return { verfuegbar: false, grund: "migration-fehlt" };
    return { verfuegbar: false, grund: String((error && error.message) || "unbekannt").slice(0, 200) };
  }
}

async function anbieterReserviere({ schluessel, menge = 1, grenzeMinute = 0, grenzeTag = 0 } = {}) {
  if (!jobQueueBereit()) return { verfuegbar: false, grund: "supabase-nicht-konfiguriert" };
  try {
    const rows = await jobQueueRpc("helmut_anbieter_reserviere", {
      p_schluessel: schluessel,
      p_menge: Math.max(1, Number(menge) || 1),
      p_grenze_minute: Math.max(0, Number(grenzeMinute) || 0),
      p_grenze_tag: Math.max(0, Number(grenzeTag) || 0)
    });
    const z = rows[0] || {};
    return {
      verfuegbar: true,
      erlaubt: z.erlaubt === true,
      grund: z.grund || null,
      fruehesteMs: Number(z.frueheste_ms) || 0
    };
  } catch (error) {
    if (isMissingReservationRpcError(error)) return { verfuegbar: false, grund: "migration-fehlt" };
    return { verfuegbar: false, grund: String((error && error.message) || "unbekannt").slice(0, 200) };
  }
}

async function anbieterMelde({ schluessel, ok, schwelle = 5, offenMs = 60000, erholung = 2, grund = null } = {}) {
  if (!jobQueueBereit()) return { verfuegbar: false, grund: "supabase-nicht-konfiguriert" };
  try {
    const rows = await jobQueueRpc("helmut_anbieter_melde", {
      p_schluessel: schluessel,
      p_ok: Boolean(ok),
      p_schwelle: Math.max(1, Number(schwelle) || 5),
      p_offen_ms: Math.max(1000, Number(offenMs) || 60000),
      p_erholung: Math.max(1, Number(erholung) || 2),
      p_grund: grund == null ? null : String(grund).slice(0, 200)
    });
    const z = rows[0] || {};
    return { verfuegbar: true, zustand: z.zustand || null, fehlerFolge: Number(z.fehler_folge) || 0 };
  } catch (error) {
    if (isMissingReservationRpcError(error)) return { verfuegbar: false, grund: "migration-fehlt" };
    return { verfuegbar: false, grund: String((error && error.message) || "unbekannt").slice(0, 200) };
  }
}

async function jobOutboxBestaetige({ outboxId, ok, fehler = null } = {}) {
  if (!jobQueueBereit()) return { verfuegbar: false, grund: "supabase-nicht-konfiguriert" };
  try {
    const rows = await jobQueueRpc("helmut_outbox_bestaetige", {
      p_outbox_id: outboxId,
      p_ok: Boolean(ok),
      p_fehler: fehler == null ? null : String(fehler).slice(0, 300)
    });
    const z = rows[0] || {};
    return { verfuegbar: true, uebernommen: z.uebernommen === true, neuerStatus: z.neuer_status || null };
  } catch (error) {
    if (isMissingReservationRpcError(error)) return { verfuegbar: false, grund: "migration-fehlt" };
    return { verfuegbar: false, grund: String((error && error.message) || "unbekannt").slice(0, 200) };
  }
}

async function jobOutboxAbgleich({ limit = 200, mindestalterMinuten = 10 } = {}) {
  if (!jobQueueBereit()) return { verfuegbar: false, grund: "supabase-nicht-konfiguriert" };
  try {
    const rows = await jobQueueRpc("helmut_outbox_abgleich", {
      p_limit: Math.max(1, Number(limit) || 200),
      p_mindestalter_minuten: Math.max(1, Number(mindestalterMinuten) || 10)
    });
    const z = rows[0] || {};
    return {
      verfuegbar: true,
      fehlend: Number(z.fehlend) || 0,
      wiedereroeffnet: Number(z.wiedereroeffnet) || 0,
      verzichtet: Number(z.verzichtet) || 0
    };
  } catch (error) {
    if (isMissingReservationRpcError(error)) return { verfuegbar: false, grund: "migration-fehlt" };
    return { verfuegbar: false, grund: String((error && error.message) || "unbekannt").slice(0, 200) };
  }
}

async function jobOutboxKennzahlen() {
  if (!jobQueueBereit()) return { verfuegbar: false, grund: "supabase-nicht-konfiguriert" };
  try {
    const rows = await jobQueueRpc("helmut_outbox_kennzahlen", {});
    return { verfuegbar: true, kennzahlen: rows[0] || null };
  } catch (error) {
    if (isMissingReservationRpcError(error)) return { verfuegbar: false, grund: "migration-fehlt" };
    return { verfuegbar: false, grund: String((error && error.message) || "unbekannt").slice(0, 200) };
  }
}

// --- VERTEILTE ARBEITSKLASSENGRENZEN (OP-30-Zielarchitektur, Migration 20260813) -----------
// Semaphor mit ablaufenden Slots, instanzuebergreifend atomar (Row-Lock auf der
// Klassen-Ankerzeile). FAIL CLOSED gehoert dem AUFRUFER: `verfuegbar:false` und
// `erlaubt:false` muessen beide als "nicht arbeiten" behandelt werden.

async function klasseBelege({ klasse, max, ttlMs = 120000, owner } = {}) {
  if (!jobQueueBereit()) return { verfuegbar: false, grund: "supabase-nicht-konfiguriert", erlaubt: false };
  try {
    const rows = await jobQueueRpc("helmut_klasse_belege", {
      p_klasse: String(klasse || ""),
      p_max: max == null ? null : Math.max(0, Number(max) || 0),
      p_ttl_ms: Math.max(1000, Number(ttlMs) || 120000),
      p_owner: String(owner || "")
    });
    const z = rows[0] || {};
    return {
      verfuegbar: true,
      erlaubt: z.erlaubt === true,
      slot: z.slot || null,
      belegt: Number(z.belegt) || 0
    };
  } catch (error) {
    if (isMissingReservationRpcError(error)) return { verfuegbar: false, grund: "migration-fehlt", erlaubt: false };
    return { verfuegbar: false, grund: String((error && error.message) || "unbekannt").slice(0, 200), erlaubt: false };
  }
}

async function klasseGebeFrei({ slot, owner } = {}) {
  if (!jobQueueBereit()) return { verfuegbar: false, grund: "supabase-nicht-konfiguriert" };
  try {
    const rows = await jobQueueRpc("helmut_klasse_gebe_frei", {
      p_slot: slot, p_owner: String(owner || "")
    });
    const wert = rows[0];
    return { verfuegbar: true, freigegeben: wert === true || (wert && wert.helmut_klasse_gebe_frei === true) };
  } catch (error) {
    if (isMissingReservationRpcError(error)) return { verfuegbar: false, grund: "migration-fehlt" };
    return { verfuegbar: false, grund: String((error && error.message) || "unbekannt").slice(0, 200) };
  }
}

async function klassenKennzahlen() {
  if (!jobQueueBereit()) return { verfuegbar: false, grund: "supabase-nicht-konfiguriert" };
  try {
    const rows = await jobQueueRpc("helmut_klassen_kennzahlen", {});
    return { verfuegbar: true, klassen: rows };
  } catch (error) {
    if (isMissingReservationRpcError(error)) return { verfuegbar: false, grund: "migration-fehlt" };
    return { verfuegbar: false, grund: String((error && error.message) || "unbekannt").slice(0, 200) };
  }
}

// --- ATOMARER VERSTEHENSVERTRAG (OP-30 CAS, Migration 20260814180000) ----------------------
// Duenne RPC-Huellen. Die FACHLOGIK liegt vollstaendig in der Datenbank (eine Zeile je
// Vorgang, Row-Lock, monotoner Fencing-Wert) — hier wird nichts entschieden, nur gerufen.
//
// FAIL CLOSED IN BEIDE RICHTUNGEN: `verfuegbar:false` bedeutet „die Zusage ist nicht
// pruefbar" (Migration fehlt, DB-Fehler, keine Supabase-Verbindung). Jeder Aufrufer in
// verstehen-vertrag.js behandelt das als „nicht erlaubt" — es wird dann NICHT verstanden,
// nicht gespeichert und nicht aufgeloest, sondern ehrlich zurueckgestellt.
async function verstehenReserviere({ vorgangId, eingabeHash, besitzer, ttlMs = 300000 } = {}) {
  if (!jobQueueBereit()) return { verfuegbar: false, grund: "supabase-nicht-konfiguriert", erlaubt: false };
  try {
    const rows = await jobQueueRpc("helmut_verstehen_reserviere", {
      p_vorgang_id: String(vorgangId || ""),
      p_eingabe_hash: String(eingabeHash || ""),
      p_besitzer: String(besitzer || ""),
      p_ttl_ms: Math.max(1000, Number(ttlMs) || 300000)
    });
    const z = rows[0] || {};
    return {
      verfuegbar: true,
      erlaubt: z.erlaubt === true,
      fencing: Number(z.fencing) || 0,
      zustand: z.zustand || null,
      grund: z.grund || null,
      ergebnisHash: z.ergebnis_hash || null,
      versuche: Number(z.versuche) || 0
    };
  } catch (error) {
    if (isMissingReservationRpcError(error)) return { verfuegbar: false, grund: "migration-fehlt", erlaubt: false };
    return { verfuegbar: false, grund: String((error && error.message) || "unbekannt").slice(0, 200), erlaubt: false };
  }
}

// Gemeinsame Huelle der drei booleschen Vertragsschritte (Modellstart, Schreibrecht,
// Abschluss, Freigabe): PostgREST liefert bei `returns boolean` je nach Fassung den
// nackten Wert oder ein Objekt mit dem Funktionsnamen als Schluessel.
async function verstehenBoolRpc(funktion, args) {
  if (!jobQueueBereit()) return { verfuegbar: false, grund: "supabase-nicht-konfiguriert", ok: false };
  try {
    const rows = await jobQueueRpc(funktion, args);
    const wert = rows[0];
    const ok = wert === true || (wert && wert[funktion] === true);
    return { verfuegbar: true, ok: Boolean(ok) };
  } catch (error) {
    if (isMissingReservationRpcError(error)) return { verfuegbar: false, grund: "migration-fehlt", ok: false };
    return { verfuegbar: false, grund: String((error && error.message) || "unbekannt").slice(0, 200), ok: false };
  }
}

function verstehenModellstart({ vorgangId, besitzer, fencing, ttlMs = 300000 } = {}) {
  return verstehenBoolRpc("helmut_verstehen_modellstart", {
    p_vorgang_id: String(vorgangId || ""), p_besitzer: String(besitzer || ""),
    p_fencing: Number(fencing) || 0, p_ttl_ms: Math.max(1000, Number(ttlMs) || 300000)
  });
}

function verstehenSchreibrecht({ vorgangId, besitzer, fencing, ttlMs = 120000 } = {}) {
  return verstehenBoolRpc("helmut_verstehen_schreibrecht", {
    p_vorgang_id: String(vorgangId || ""), p_besitzer: String(besitzer || ""),
    p_fencing: Number(fencing) || 0, p_ttl_ms: Math.max(1000, Number(ttlMs) || 120000)
  });
}

function verstehenAbschluss({ vorgangId, besitzer, fencing, ergebnisHash } = {}) {
  return verstehenBoolRpc("helmut_verstehen_abschluss", {
    p_vorgang_id: String(vorgangId || ""), p_besitzer: String(besitzer || ""),
    p_fencing: Number(fencing) || 0, p_ergebnis_hash: ergebnisHash == null ? null : String(ergebnisHash)
  });
}

function verstehenFreigabe({ vorgangId, besitzer, fencing, grund } = {}) {
  return verstehenBoolRpc("helmut_verstehen_freigabe", {
    p_vorgang_id: String(vorgangId || ""), p_besitzer: String(besitzer || ""),
    p_fencing: Number(fencing) || 0, p_grund: grund == null ? null : String(grund).slice(0, 200)
  });
}

// Der EIGENE, eng gefasste Weg fuer den belegten Fall „es wurde nichts abgesendet"
// (Tagesbudget/Anbietergrenze vor dem HTTP-Aufruf). Bewusst NICHT derselbe Aufruf wie
// oben: der allgemeine Rueckweg bleibt nach dem Modellstart verschlossen.
function verstehenFreigabeOhneAufruf({ vorgangId, besitzer, fencing, grund } = {}) {
  return verstehenBoolRpc("helmut_verstehen_freigabe_ohne_aufruf", {
    p_vorgang_id: String(vorgangId || ""), p_besitzer: String(besitzer || ""),
    p_fencing: Number(fencing) || 0, p_grund: grund == null ? null : String(grund).slice(0, 200)
  });
}

// OP-30 CAS, Korrekturlauf 2026-08-15 (Luecke 3): DER atomare Speicherweg. Anders als
// `saveKnowledgeObject` schreibt er nicht ueber PostgREST, sondern uebergibt das
// Wissensobjekt der Datenbankfunktion, die Besitzer, aktuelle Reservierung, Fencing-Wert,
// Zustand und Lease GEMEINSAM prueft und erst dann schreibt und abschliesst.
//
// FAIL CLOSED: jeder nicht eindeutige Ausgang (DB-Fehler, fehlende Migration, keine
// Verbindung) ist `verfuegbar:false`. Der Aufrufer darf daraus NIE „gespeichert" machen —
// und, nach einem begonnenen Modellaufruf, auch nie „sicher wiederholbar".
async function verstehenSpeichere({ vorgangId, besitzer, fencing, ko, ergebnisHash } = {}) {
  if (!jobQueueBereit()) return { verfuegbar: false, grund: "supabase-nicht-konfiguriert", gespeichert: false };
  try {
    const rows = await jobQueueRpc("helmut_verstehen_speichere", {
      p_vorgang_id: String(vorgangId || ""),
      p_besitzer: String(besitzer || ""),
      p_fencing: Number(fencing) || 0,
      p_ko: baueKoSchreibProjektion(ko || {}),
      p_ergebnis_hash: ergebnisHash == null ? null : String(ergebnisHash)
    });
    const wert = rows[0];
    const ergebnis = typeof wert === "string" ? wert : (wert && wert.helmut_verstehen_speichere) || null;
    if (!ergebnis) return { verfuegbar: false, grund: "leere-antwort", gespeichert: false };
    return { verfuegbar: true, ergebnis, gespeichert: ergebnis === "gespeichert" };
  } catch (error) {
    if (isMissingReservationRpcError(error)) return { verfuegbar: false, grund: "migration-fehlt", gespeichert: false };
    return { verfuegbar: false, grund: String((error && error.message) || "unbekannt").slice(0, 200), gespeichert: false };
  }
}

// OP-30 CAS, Korrekturlauf 2026-08-15 (Luecke 1): der ehrliche Ausgang nach einem
// begonnenen Modellaufruf. Kein `offen`, kein stiller zweiter Aufruf.
async function verstehenAusgangUnbekannt({ vorgangId, besitzer, fencing, grund } = {}) {
  if (!jobQueueBereit()) return { verfuegbar: false, grund: "supabase-nicht-konfiguriert", blockiert: false };
  try {
    const rows = await jobQueueRpc("helmut_verstehen_ausgang_unbekannt", {
      p_vorgang_id: String(vorgangId || ""), p_besitzer: String(besitzer || ""),
      p_fencing: Number(fencing) || 0, p_grund: grund == null ? null : String(grund).slice(0, 200)
    });
    const wert = rows[0];
    const ergebnis = typeof wert === "string" ? wert : (wert && wert.helmut_verstehen_ausgang_unbekannt) || null;
    if (!ergebnis) return { verfuegbar: false, grund: "leere-antwort", blockiert: false };
    return { verfuegbar: true, ergebnis, blockiert: ergebnis === "blockiert" };
  } catch (error) {
    if (isMissingReservationRpcError(error)) return { verfuegbar: false, grund: "migration-fehlt", blockiert: false };
    return { verfuegbar: false, grund: String((error && error.message) || "unbekannt").slice(0, 200), blockiert: false };
  }
}

async function verstehenAusgangAufloesen({ vorgangId, entscheidung = "pruefen" } = {}) {
  if (!jobQueueBereit()) return { verfuegbar: false, grund: "supabase-nicht-konfiguriert" };
  try {
    const rows = await jobQueueRpc("helmut_verstehen_ausgang_aufloesen", {
      p_vorgang_id: String(vorgangId || ""), p_entscheidung: String(entscheidung || "pruefen")
    });
    const wert = rows[0];
    const ergebnis = typeof wert === "string" ? wert : (wert && wert.helmut_verstehen_ausgang_aufloesen) || null;
    return { verfuegbar: true, ergebnis };
  } catch (error) {
    if (isMissingReservationRpcError(error)) return { verfuegbar: false, grund: "migration-fehlt" };
    return { verfuegbar: false, grund: String((error && error.message) || "unbekannt").slice(0, 200) };
  }
}

async function verstehenVormerkungLese(vorgangIds = []) {
  if (!jobQueueBereit()) return { verfuegbar: false, grund: "supabase-nicht-konfiguriert", eintraege: {} };
  const ids = (Array.isArray(vorgangIds) ? vorgangIds : [vorgangIds]).map((v) => String(v || "")).filter(Boolean);
  if (!ids.length) return { verfuegbar: true, eintraege: {} };
  try {
    const rows = await jobQueueRpc("helmut_verstehen_vormerkung_lese", { p_vorgang_ids: ids });
    const eintraege = {};
    for (const zeile of rows || []) {
      if (zeile && zeile.vorgang_id) eintraege[zeile.vorgang_id] = Number(zeile.fehlversuche) || 0;
    }
    return { verfuegbar: true, eintraege };
  } catch (error) {
    if (isMissingReservationRpcError(error)) return { verfuegbar: false, grund: "migration-fehlt", eintraege: {} };
    return { verfuegbar: false, grund: String((error && error.message) || "unbekannt").slice(0, 200), eintraege: {} };
  }
}

async function verstehenVormerkungErhoehe({ vorgangId, delta = 1, fencing = 0 } = {}) {
  if (!jobQueueBereit()) return { verfuegbar: false, grund: "supabase-nicht-konfiguriert" };
  try {
    const rows = await jobQueueRpc("helmut_verstehen_vormerkung_erhoehe", {
      p_vorgang_id: String(vorgangId || ""),
      p_delta: Math.max(0, Number(delta) || 0),
      p_fencing: Number(fencing) || 0
    });
    const wert = rows[0];
    const zahl = typeof wert === "number" ? wert : Number(wert && wert.helmut_verstehen_vormerkung_erhoehe);
    return { verfuegbar: true, fehlversuche: Number.isFinite(zahl) ? zahl : null };
  } catch (error) {
    if (isMissingReservationRpcError(error)) return { verfuegbar: false, grund: "migration-fehlt" };
    return { verfuegbar: false, grund: String((error && error.message) || "unbekannt").slice(0, 200) };
  }
}

function verstehenVormerkungLoese({ vorgangId, fencing = 0 } = {}) {
  return verstehenBoolRpc("helmut_verstehen_vormerkung_loese", {
    p_vorgang_id: String(vorgangId || ""), p_fencing: Number(fencing) || 0
  });
}

// --- WIEDERAUFNAHME AUSDRUECKLICH FREIGEGEBENER VORGAENGE (OP-30 §30) --------------------
// BELEGTE LUECKE (2026-08-21/22): ein per `helmut_verstehen_ausgang_aufloesen(..., 'erneut')`
// freigegebener Vorgang steht danach auf `zustand='offen'`, ist aber in KEINER Liste, die ein
// regulaerer Verstehenslauf abarbeitet. Der Nachholpfad (`runPendingUnderstandingShadow`)
// liest ausschliesslich Wissensobjekte mit `status='pending'`; ein Vorgang mit bestehendem
// `complete`-KO (oder ganz ohne KO) ist dort nie enthalten. Er wurde deshalb nur dann erneut
// bearbeitet, wenn sein Cluster ZUFAELLIG durch neue Dokumente erneut gebildet wurde.
// Production-Beleg: 0caefc33 und vier weitere blieben ueber vier Slots (16:00, 20:00, 21:30,
// 04:00) unberuehrt, obwohl der 21:30-Lauf 18 Vorgaenge verarbeitete.
//
// DIESE FUNKTION SCHLIESST GENAU DIESE LUECKE — nicht mehr:
//   * Sie liefert AUSSCHLIESSLICH Zeilen mit `zustand='offen'` UND
//     `letzter_grund='erneut-freigegeben'` — exakt der Marker, den der kanonische
//     Betreiberweg schreibt. Keine pauschale Wiederverarbeitung aller offenen Vorgaenge.
//   * Sie ist REIN LESEND. Reservierung, Besitzer, Lease, Fencing, Budget und Vorgangswache
//     bleiben unveraendert dem CAS-Vertrag ueberlassen; dieser Weg verschafft dem Vorgang
//     nur die Gelegenheit, ueberhaupt reserviert zu werden.
//   * SELBSTBEGRENZEND: sobald der Vorgang irgendeinen anderen Ausgang nimmt (fertig,
//     unbekannt, aufgegeben, belegt-ohne-aufruf), wird `letzter_grund` ueberschrieben und er
//     faellt aus dieser Liste. Eine Freigabe fuehrt damit zu hoechstens einem
//     Wiederaufnahmeversuch — es gibt keinen automatischen zweiten.
//   * Keine Migration noetig: die Tabelle stammt aus 20260814180000 und wird hier nur
//     gefiltert gelesen.
async function verstehenWiederaufnahmen({ limit = 25 } = {}) {
  if (!jobQueueBereit()) return { verfuegbar: false, grund: "supabase-nicht-konfiguriert", vorgaenge: [] };
  const n = Math.max(1, Math.min(200, Number(limit) || 25));
  try {
    const rows = await supabaseRequest(
      "/rest/v1/helmut_verstehen_reservierungen"
      + "?select=vorgang_id,fencing,versuche,ki_aufrufe,updated_at"
      + "&zustand=eq.offen&letzter_grund=eq.erneut-freigegeben"
      // JUENGSTE FREIGABE ZUERST: ein Vorgang, der ohne Fortschritt endet (kein KO, keine
      // Quellen, terminal), behaelt seinen Marker und bliebe bei aufsteigender Sortierung
      // als aeltester Eintrag dauerhaft auf den Listenplaetzen — spaetere Betreiberfreigaben
      // wuerden dann nie geliefert. Absteigend bedient die Liste immer zuerst das, was der
      // Betreiber zuletzt entschieden hat.
      + `&order=updated_at.desc&limit=${n}`
    );
    const vorgaenge = (Array.isArray(rows) ? rows : [])
      .map((r) => (r && r.vorgang_id ? String(r.vorgang_id) : ""))
      .filter(Boolean);
    return { verfuegbar: true, vorgaenge };
  } catch (error) {
    // FAIL CLOSED: ein Lesefehler ist NICHT "keine Wiederaufnahmen" — der Aufrufer
    // erfaehrt das und meldet es, statt einen leeren Rueckstand zu behaupten.
    return {
      verfuegbar: false,
      grund: String((error && error.message) || "unbekannt").slice(0, 200),
      vorgaenge: []
    };
  }
}

async function verstehenKennzahlen() {
  if (!jobQueueBereit()) return { verfuegbar: false, grund: "supabase-nicht-konfiguriert" };
  try {
    const rows = await jobQueueRpc("helmut_verstehen_kennzahlen", {});
    // Gate-Arm: die geparkte Menge gehoert in denselben Kennzahlenblock, GETRENNT
    // vom normalen Rueckstand. null = nicht messbar (countGateGeparkt faengt
    // seine Fehler selbst) — der Bericht zeigt dann "?", nie eine erfundene 0.
    const gateGeparkt = await countGateGeparkt();
    return { verfuegbar: true, zustaende: rows || [], gateGeparkt };
  } catch (error) {
    if (isMissingReservationRpcError(error)) return { verfuegbar: false, grund: "migration-fehlt" };
    return { verfuegbar: false, grund: String((error && error.message) || "unbekannt").slice(0, 200) };
  }
}

// --- KI-BUDGET: idempotente Reservierung je beabsichtigtem Ergebnis (OP-30, additiv) -------
// Migration 20260808_llm_budget_fairness.sql. Der bestehende globale Deckel
// (`helmut_reserve_llm_call`) bleibt unveraendert das Notfalllimit; hier kommt die
// ERGEBNISBEZOGENE Idempotenz und der faire Mandantenanteil dazu.
async function llmReserveResult({
  resultKey, day, scope = "global", workClass = "notwendig",
  globalMax = null, scopeMax = null, ttlMs = 900000
} = {}) {
  if (!jobQueueBereit()) return { verfuegbar: false, grund: "supabase-nicht-konfiguriert" };
  try {
    const rows = await jobQueueRpc("helmut_reserve_llm_result", {
      p_result_key: resultKey, p_day: day, p_scope: scope, p_work_class: workClass,
      p_global_max: globalMax, p_scope_max: scopeMax, p_ttl_ms: ttlMs
    });
    const z = rows[0] || {};
    return {
      verfuegbar: true,
      erlaubt: Boolean(z.erlaubt),
      wiederverwendet: Boolean(z.wiederverwendet),
      grund: z.grund || null,
      globalVerbraucht: Number(z.global_verbraucht) || 0,
      scopeVerbraucht: Number(z.scope_verbraucht) || 0
    };
  } catch (error) {
    if (isMissingReservationRpcError(error)) return { verfuegbar: false, grund: "migration-fehlt" };
    return { verfuegbar: false, grund: String((error && error.message) || "unbekannt").slice(0, 200) };
  }
}

async function llmSettleResult({ resultKey, ok = true, note = null } = {}) {
  if (!jobQueueBereit()) return { verfuegbar: false, grund: "supabase-nicht-konfiguriert" };
  try {
    const rows = await jobQueueRpc("helmut_settle_llm_reservation", {
      p_result_key: resultKey, p_ok: Boolean(ok), p_note: note == null ? null : String(note).slice(0, 300)
    });
    const z = rows[0] || {};
    return { verfuegbar: true, uebernommen: Boolean(z.uebernommen), status: z.neuer_status || null };
  } catch (error) {
    if (isMissingReservationRpcError(error)) return { verfuegbar: false, grund: "migration-fehlt" };
    return { verfuegbar: false, grund: String((error && error.message) || "unbekannt").slice(0, 200) };
  }
}

// Ausdrueckliche Rueckgabe: der Aufruf fand NACHWEISLICH nicht statt (V3-Kurzschluss griff
// VOR dem Modellaufruf). Nur dafuer — niemals als Aufraeumautomatik.
async function llmReleaseResult({ resultKey, note = null } = {}) {
  if (!jobQueueBereit()) return { verfuegbar: false, grund: "supabase-nicht-konfiguriert" };
  try {
    const rows = await jobQueueRpc("helmut_release_llm_reservation", {
      p_result_key: resultKey, p_note: note == null ? null : String(note).slice(0, 300)
    });
    return { verfuegbar: true, zurueckgegeben: Boolean((rows[0] || {}).zurueckgegeben) };
  } catch (error) {
    if (isMissingReservationRpcError(error)) return { verfuegbar: false, grund: "migration-fehlt" };
    return { verfuegbar: false, grund: String((error && error.message) || "unbekannt").slice(0, 200) };
  }
}

async function llmBudgetKennzahlen(tag = null) {
  if (!jobQueueBereit()) return { verfuegbar: false, grund: "supabase-nicht-konfiguriert" };
  try {
    const rows = await jobQueueRpc("helmut_llm_budget_kennzahlen", { p_day: tag });
    return { verfuegbar: true, kennzahlen: rows[0] || null };
  } catch (error) {
    if (isMissingReservationRpcError(error)) return { verfuegbar: false, grund: "migration-fehlt" };
    return { verfuegbar: false, grund: String((error && error.message) || "unbekannt").slice(0, 200) };
  }
}

module.exports = {
  ergaenzeUnvollstaendigesBriefing,
  setTestProfileActive,
  insertRenderedBriefingV3,
  insertBriefingFachurteil,
  insertLageEntwurfsbeleg,
  getLageEntwurfsbeleg,
  mutateAuthStore,
  // OP-30 V3-Anbindung und KI-Budget (Migrationen 20260808) — reine RPC-/Lese-Huellen:
  getRawDocumentsByIds,
  jobQueueOffeneVorbedingungen,
  jobQueueDefer,
  // OP-30/O5 (Migration 20260809) — Wiedervorlage und dauerhaft blockierte Auftraege:
  jobQueueWiedervorlage,
  jobQueueBlockiert,
  jobQueueZurueckgestellteGruende,
  // OP-30-Zielarchitektur (Migration 20260813): Outbox + verteilte Klassengrenzen.
  jobQueueEnqueueMitOutbox,
  jobOutboxNaechste,
  jobOutboxBestaetige,
  jobQueueClaimById,
  jobOutboxZuruecklegen,
  jobOutboxErneutVorlegen,
  klasseErneuere,
  anbieterReserviere,
  anbieterMelde,
  jobOutboxAbgleich,
  jobOutboxKennzahlen,
  klasseBelege,
  klasseGebeFrei,
  klassenKennzahlen,
  verstehenKonkurrenzEnabled,
  vorgangsWache,
  // OP-30 CAS (Migration 20260814180000) — atomarer Verstehensvertrag, reine RPC-Huellen:
  verstehenReserviere,
  verstehenModellstart,
  verstehenSchreibrecht,
  verstehenSpeichere,
  verstehenAbschluss,
  verstehenAusgangUnbekannt,
  verstehenFreigabe,
  verstehenFreigabeOhneAufruf,
  verstehenAusgangAufloesen,
  verstehenVormerkungLese,
  verstehenVormerkungErhoehe,
  verstehenVormerkungLoese,
  verstehenWiederaufnahmen,
  verstehenKennzahlen,
  llmReserveResult,
  llmSettleResult,
  llmReleaseResult,
  llmBudgetKennzahlen,
  // OP-30 Arbeitswarteschlange (Migration 20260808) — reine RPC-Huellen:
  jobQueueBereit,
  jobQueueEnqueue,
  jobQueueClaim,
  jobQueueFinish,
  jobQueueExtendLease,
  jobQueueMetrics,
  // P0-2-Folgearbeit ("Sprint 3"): Tenant-JWT-Modus — exportiert fuer Tests
  // (scripts/tenant-jwt-test.js) und Dokumentationszwecke. Default-inert
  // (siehe tenantJwtModeEnabled), kein Verhalten geaendert ohne explizite
  // ENV-Konfiguration (HELMUT_TENANT_JWT_MODE + SUPABASE_JWT_SECRET +
  // SUPABASE_ANON_KEY).
  tenantJwtModeEnabled,
  signTenantJWT,
  verifyTenantJWT,
  diagnoseTenantJwt,
  tenantRequest,
  supabaseAuthenticatedRequest,
  deleteProfileData,
  exportProfileData,
  exportProfileDataV3,
  deleteProfileDataV3,
  deleteTenantScopedData,
  getStorageStatus,
  getStoreSummary,
  listSourceArchitectureRows,
  persistRawDocumentsDeduped,
  recordGateShadowEvents,
  // Gate-Arm (OP-18, 2026-08-31): Parkungs-Beleg + Zustand + Rueckweg + Kennzahl
  recordGateParkungBeleg,
  markUnderstandingGateGeparkt,
  releaseUnderstandingGateGeparkt,
  listGateGeparkteKnowledgeObjects,
  countGateGeparkt,
  // PR-C Drain-Bilanz (2026-08-31): fail-safe Lesegroessen (null = nicht messbar)
  zaehleGateWuerdigeAnkunft,
  zaehleVerstandene,
  zaehlePendingVerarbeitbar,
  // Blocker 3+4 (500-Mandate-Reife 2026-09-01): echter gate-wuerdiger Abfluss,
  // deterministisch paginierte Ereignislese, CAS-Trend-Schnappschuss
  zaehleGateWuerdigerAbfluss,
  leseDrainTrendZeile,
  schreibeDrainTrendSchnappschuss,
  saveSourceModeShadowRun,
  getSourceModeShadowLastRun,
  readStore,
  writeStore,
  readAuthStore,
  writeAuthStore,
  acquirePipelineLock,
  releasePipelineLock,
  // OP-25: Fairnesszustand der Mehrmandanten-Crons (eigene helmut_store-Zeile)
  readCronFairnessState,
  saveCronFairnessState,
  deleteCronFairnessTenant,
  blobFensterVollstaendig,
  LLM_USAGE_RING_MAX,
  // P0-4: atomarer Lock-Pfad (freigabepflichtig, Default aus) — fuer Tests exportiert
  acquirePipelineLockAtomic,
  atomicLockEnabled,
  acquireGlobalUnderstandingLock,
  releaseGlobalUnderstandingLock,
  understandingLockEnabled,
  saveAdminRecoveryLastRun,
  getAdminRecoveryLastRun,
  v3StoreEnabled,
  v3MatchingEnabled,
  v3LazyUnderstandingEnabled,
  saveRawDocument,
  saveKnowledgeObject,
  V3_KNOWLEDGE_OBJECT_COLUMNS,
  getKnowledgeObjectById,
  getKnowledgeObjectByVorgang,
  listKnowledgeObjectsByVorgangPrefix,
  listKoDocuments,
  listKoDocumentLinks,
  listKnowledgeObjectStates,
  listKnowledgeObjects,
  listKnowledgeObjectsByIds,
  listKnowledgeObjectsSeitenweise,
  assertTenant,
  assertTenantRows,
  TenantContextError,
  saveProfileEmbedding,
  getProfileEmbedding,
  matchKnowledgeObjectsByEmbedding,
  saveMatchingResults,
  listMatchingResults,
  // Sprint 23B-1: Auditpersistenz (Roadmap-Punkt 23), Default AUS
  matchingAuditEnabled,
  matchingRelevanzGateEnabled,
  getCompletedMatchingRun,
  saveMatchingRun,
  updateMatchingRun,
  publishMatchingRun,
  saveDecisions,
  listDecisions,
  savePendingKnowledgeObject,
  savePendingKnowledgeObjectsBulk,
  // updated_at-Vertrag (Befund 05.09.2026): exportiert, damit die Suite den Vergleich
  // ohne Netz und ohne Datenbank pruefen kann.
  kanonischerSpaltenwert,
  mandateProfileZeileGeaendert,
  listPendingKnowledgeObjects,
  // P1-4: begrenzte Recovery fehlgeschlagener Wissensobjekte (bounded Auto-Retry)
  listFailedKnowledgeObjects,
  resetUnderstandingToPending,
  markUnderstandingTerminal,
  markPendingUnderstandingTerminal,
  getUnderstandingRetries,
  saveUnderstandingRetries,
  // P29-3: Vormerkungen gescheiterter/vertagter KO-Aktualisierungen
  getUpdateRetries,
  saveUpdateRetries,
  listRecentRawDocuments,
  listRawDocuments,
  markUnderstandingFailed,
  bulkResetUnderstandingFailed,
  saveKnowledgeObjectEnrichment,
  saveRenderedBriefingV3,
  getRenderedBriefingV3,
  saveKoDocumentLinks,
  getSourcesForVorgang,
  listAktuelleLageQuellen,
  v3StoreReady,
  saveOfficeOutput,
  getOfficeOutput,
  listOfficeOutputsByUser,
  canSpendOfficeOutput,
  officeOutputId,
  recordLlmUsage,
  buildLlmUsageRecord,
  getLlmUsage,
  getLlmUsageToday,
  getLlmUsageBreakdownToday,
  getRunCostReport,
  llmPriceProvenance,
  // Additiv exportiert (OP-30 Abnahmesprint): die Skalierungsrechnung
  // (scripts/skalierungsmodell.js) darf KEINE eigene Preistabelle fuehren — sonst
  // gaebe es zwei Preiswahrheiten. Reine Lesefunktion, kein Verhalten geaendert.
  llmPriceTable,
  llmDailyCallLimit,
  llmUnderstandingReserve,
  canSpendLlm,
  leseLlmTageszaehler,
  canSpendLlmForTenant,
  reserveLlmCall,
  reserveTenantScope,
  tenantDailyCallLimit,
  tenantLlmCapEnabled,
  isSharedGlobalCallType,
  __resetLlmReservationForTests,
  getLlmCostSince,
  llmBudgetFailResult,
  estimateLlmCost,
  saveRawItems,
  getRawItemsSince,
  getSources,
  updateSourceLastCrawled,
  saveBriefing,
  getLatestBriefing,
  getTopicMemory,
  updateTopicMemoryFromBriefing,
  saveCrawlRun,
  getLatestCrawlRun,
  listCrawlRuns,
  // P0-2: pure Verdichtungs-Helfer fuer den Roundtrip-Test (compact-store-roundtrip-test.js)
  compactStore,
  compactCrawlRunForStore,
  // SR §37: Aufbewahrungsbefund und Speicherziel sind ab jetzt abfragbar — ein
  // Vorflug-Riegel kann sonst gar nicht melden, was wirksam ist.
  crawlRunAufbewahrung,
  CRAWL_RUN_LESEFENSTER,
  speicherziel,
  // P0-1: Prozess-Laufzeit-Telemetrie (Understanding/Briefing/Lage), Auth-Store, scalar-only
  // W-2 (Werkzeug-Haertung): parallel-sicher (relational, gated), idempotent, Fehler sichtbar
  llmVorrangAbzug,
  insertLlmUsageRelational,
  leseLlmUsageRelational,
  recordProcessRun,
  recordProcessRunStart,
  schreibeWarteschlangenLaufquittung,
  persistiereRohdokumenteWarteschlange,
  upsertProcessRunRelational,
  listProcessRunsRelational,
  istVorgangsbildungsLauf,
  aggregateVorgangsbildung,
  getVorgangsbildungKennzahlen,
  listProcessRuns,
  sanitizeProcessRun,
  // W-1 (Werkzeug-Haertung): typisierter Lesefehler statt stillem []
  StorageReadError,
  klassifiziereLesefehler,
  // P0-1: Pro-Quellenabruf-Telemetrie (relationale Tabelle, freigabepflichtig/default aus)
  insertSourceCrawlTelemetry,
  listSourceCrawlTelemetry,
  // P0-3: zentraler, datenschutzsicherer Pipeline-Fehler-Sammler (systemErrors, dedup)
  recordPipelineError,
  // P0-5 Stufe 1: Blob-Timeout-Robustheit (Retry+Backoff) — fuer Tests exportiert
  withStoreRetry,
  isRetryableStoreError,
  // P0-5 Stufe 2 (Vorbereitung): gated Dual-Write Crawl-Läufe relational
  insertCrawlRunRelational,
  saveLageCheck,
  getLatestLageCheck,
  getLageChecks,
  savePipelineDebugReport,
  getLatestPipelineDebugReport,
  getLatestCompleteKnowledgeObjectAt,
  saveWatchdogState,
  getLatestWatchdogState,
  saveMonitoringDeliveryState,
  getMonitoringDeliveryState,
  saveTask,
  getTasks,
  updateTaskStatus,
  saveInteraction,
  getInteractions,
  getProfile,
  listProfiles,
  listFullProfiles,
  saveProfile,
  purgeBlobProfiles,
  // Mehrmandantenfaehigkeit Phase 3 (profiles/mandate_profiles SQL-Pfad) --
  // exportiert fuer Tests (scripts/profile-db-test.js) und Admin-Diagnose.
  profileDbModeEnabled,
  profileDbExclusiveEnabled,
  getProfileTelemetry,
  getProfileFromDb,
  saveProfileToDb,
  listFullProfilesFromDb,
  toMandateProfileRow,
  fromMandateProfileRow,
  saveFeedback,
  listFeedback,
  setFeedbackDone,
  savePersonalizedRecommendations,
  savePoliticalItems,
  savePriorityChanges,
  getUserNotes,
  saveUserNote,
  savePushSubscription,
  removePushSubscription,
  getPushSubscriptions,
  getPushUebersicht,
  leseMandantenSpeicherGebuendelt,
  lageCheckAusSpeicher,
  pushUebersichtAusSpeicher,
  listRenderedBriefingsV3ForTenants,
  savePushEvent,
  getPushEventByDedupeKey,
  listPushEvents,
  getAdminStatsCosts,
  getAdminStatsCrawl,
  getAdminStatsOverview,
  getAdminStatsCrawlReport,
  getAdminCostsPerUser,
  getKnowledgeObjectCount,
  getClassificationCoverage,
  // Datenschutz: Aufbewahrung/Löschung (freigabepflichtig, Trockenlauf-Default)
  loadRetentionMetadata,
  deleteRetention,
  getAdminPeriodStats
};

// Kosten + V3-Counts (Artikel, KOs, Briefings) für einen bestimmten Zeitraum.
// Wird für "Heute" (days=1) und "30 Tage" (days=30) parallel aufgerufen;
// der Cache sorgt dafür, dass Store-Reads nicht doppelt stattfinden.
async function getAdminPeriodStats(days = 30) {
  const cutoffMs = Date.now() - days * 24 * 60 * 60 * 1000;
  const cutoffIso = new Date(cutoffMs).toISOString();

  const [perUserData, aiData] = await Promise.all([
    getAdminCostsPerUser({ days }),
    getAdminStatsCosts({ days })
  ]);

  let articles = null;
  let kos = null;
  if (v3StoreReady()) {
    try {
      const [rawDocsRes, kosRes] = await Promise.all([
        supabaseRequest(`/rest/v1/raw_documents?select=count&created_at=gte.${encodeURIComponent(cutoffIso)}`).catch(() => null),
        supabaseRequest(`/rest/v1/knowledge_objects?select=count&created_at=gte.${encodeURIComponent(cutoffIso)}`).catch(() => null)
      ]);
      articles = Array.isArray(rawDocsRes) && rawDocsRes[0] ? Number(rawDocsRes[0].count) : null;
      kos = Array.isArray(kosRes) && kosRes[0] ? Number(kosRes[0].count) : null;
    } catch {}
  }

  const store = await readStore("main");
  const briefings = (store.briefings || []).filter((b) => {
    return new Date(b.generatedAt || b.date || 0).getTime() >= cutoffMs;
  }).length;

  return {
    periodDays: days,
    totalCostUsd: perUserData.totalCostUsd,
    totalCalls: aiData.totalCalls,
    perUser: perUserData.perUser,
    perCategory: aiData.perCategory,
    articles,
    kos,
    briefings
  };
}

// P1-6: Klassifikationsabdeckung (Anteil KOs MIT politischer Ebene + Feature-Vektor).
// Grundlage der Health-Report-Achse. Fail-safe: null, wenn der relationale Store
// nicht bereit ist. Nur Zähler — keine Inhalte.
async function getClassificationCoverage() {
  if (!v3StoreReady()) return null;
  try {
    const countOf = async (query) => {
      const rows = await supabaseRequest(query).catch(() => null);
      return Array.isArray(rows) && rows[0] ? Number(rows[0].count) || 0 : null;
    };
    const [total, withLevel, withEstablishedLevel, withEmbedding, withAffectedGeography] = await Promise.all([
      countOf("/rest/v1/knowledge_objects?select=count"),
      countOf("/rest/v1/knowledge_objects?select=count&decision_level=not.is.null"),
      // SPRINT 19 — KEIN FALSCHES GRUEN: `decision_level` ist seit Sprint 2 NIE null,
      // weil der Deriver im Zweifel ehrlich 'unknown' schreibt. Die alte Zaehlung
      // "not.is.null" meldete deshalb strukturell ~100 % Abdeckung, obwohl die Ebene
      // gar nicht ermittelt war. Massgeblich ist die ERMITTELTE Ebene.
      countOf("/rest/v1/knowledge_objects?select=count&decision_level=not.is.null&decision_level=neq.unknown"),
      countOf("/rest/v1/knowledge_objects?select=count&embedding=not.is.null"),
      // SPRINT 20 — dieselbe Ehrlichkeitsregel fuer die Geografie. `affected_geographies`
      // ist ein jsonb-Array mit Default '[]' und damit NIE null; "not.is.null" waere
      // wieder strukturelles Gruen. Gezaehlt wird die NICHT-LEERE Zuordnung, und zwar
      // ueber die Array-Laenge — ein Geografie-OBJEKT ist kein Textwert und darf auch
      // nicht wie einer geprueft werden.
      countOf("/rest/v1/knowledge_objects?select=count&affected_geographies=neq.%5B%5D")
    ]);
    if (total == null) return null;
    const ratio = (n) => (total > 0 && n != null ? Math.round((n / total) * 1000) / 1000 : null);
    return {
      total,
      withLevel, withEstablishedLevel, withEmbedding, withAffectedGeography,
      levelCoverage: ratio(withLevel),
      establishedLevelCoverage: ratio(withEstablishedLevel),
      embeddingCoverage: ratio(withEmbedding),
      affectedGeographyCoverage: ratio(withAffectedGeography),
      missingLevel: withLevel != null ? Math.max(0, total - withLevel) : null,
      unknownLevel: withEstablishedLevel != null ? Math.max(0, total - withEstablishedLevel) : null,
      // Ehrlich benannt: "ohne betroffene Geografie" ist KEIN Fehler, sondern der
      // zulaessige Zustand "Region nicht ermittelt" (Regel 2 des Sprints).
      unknownGeography: withAffectedGeography != null ? Math.max(0, total - withAffectedGeography) : null
    };
  } catch (_) {
    return null;
  }
}

// --- Datenschutz: Aufbewahrung/Löschung (Retention) ---------------------------
// Lädt NUR minimierte Metadaten (id/created_at + Verknüpfungen) für die Retention-
// PLANUNG — KEIN Volltext. Fail-safe: null/leer, wenn der Store nicht bereit ist.
async function loadRetentionMetadata() {
  if (!v3StoreReady()) return { available: false, reason: "relational-store-not-ready" };
  try {
    const [raw, kos, links] = await Promise.all([
      supabaseRequest("/rest/v1/raw_documents?select=id,created_at&order=created_at.asc&limit=100000").catch(() => []),
      supabaseRequest("/rest/v1/knowledge_objects?select=id,created_at&order=created_at.asc&limit=100000").catch(() => []),
      supabaseRequest("/rest/v1/ko_document_links?select=knowledge_object_id,raw_document_id&limit=200000").catch(() => [])
    ]);
    return {
      available: true,
      rawDocuments: Array.isArray(raw) ? raw : [],
      knowledgeObjects: Array.isArray(kos) ? kos : [],
      koDocumentLinks: Array.isArray(links) ? links : []
    };
  } catch (error) {
    return { available: false, reason: error && error.message };
  }
}

// Führt den Retention-Löschplan aus. GATED (HELMUT_RETENTION_EXECUTE + v3StoreReady)
// UND freigabepflichtig. Die DB-FKs kaskadieren ko_document_links/ko_relations/
// document_findings der gelöschten Zeilen. Fail-safe pro Batch.
async function deleteRetention(plan = {}) {
  const { retentionExecuteEnabled } = require("./retention");
  if (!retentionExecuteEnabled()) return { skipped: true, reason: "disabled" };
  if (!v3StoreReady()) return { skipped: true, reason: "relational-store-not-ready" };
  if (plan.integrityOk === false) return { skipped: true, reason: "integrity-check-failed" };
  const chunk = (arr, n) => { const out = []; for (let i = 0; i < arr.length; i += n) out.push(arr.slice(i, i + n)); return out; };
  const delIn = async (table, col, ids) => {
    let deleted = 0;
    for (const batch of chunk(ids, 100)) {
      const inList = batch.map((v) => `"${String(v).replace(/"/g, "")}"`).join(",");
      await supabaseRequest(`/rest/v1/${table}?${col}=in.(${inList})`, { method: "DELETE", headers: { Prefer: "return=minimal" } });
      deleted += batch.length;
    }
    return deleted;
  };
  const koDeleted = Array.isArray(plan.koToDelete) && plan.koToDelete.length ? await delIn("knowledge_objects", "id", plan.koToDelete) : 0;
  const rawDeleted = Array.isArray(plan.rawToDelete) && plan.rawToDelete.length ? await delIn("raw_documents", "id", plan.rawToDelete) : 0;
  return { koDeleted, rawDeleted };
}

async function getKnowledgeObjectCount() {
  if (!v3StoreReady()) return null;
  try {
    const rows = await supabaseRequest("/rest/v1/knowledge_objects?select=count");
    return Array.isArray(rows) && rows[0] ? (Number(rows[0].count) || 0) : null;
  } catch {
    return null;
  }
}
